import { IDocumentAndPriority, TypesObjectId } from '@homelead-shared-api';

export interface IDocumentationAndPriorityUpdateDoc extends IDocumentAndPriority {
    _id?: TypesObjectId;
}
export interface UpdateDocument {
    document: string;
}
