import { ISetting, TypesObjectId } from '@homelead-shared-api';

export interface UpdateSetting {
    company: TypesObjectId;
    data: Partial<ISetting>;
}
