import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import DocumentAndPrioritiesService from './DocumentAndPriorityService';
import { validate } from '../../utils/validations';
import DocumentAndPrioritiesValidations from './DocumentAndPriorityValidations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.DOCUMENTS_PRIORITIES_LIST),
    DocumentAndPrioritiesService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.DOCUMENTS_PRIORITIES_ADD),
    validate(DocumentAndPrioritiesValidations.updateOrCreate),
    DocumentAndPrioritiesService.updateOrCreate as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.DOCUMENTS_PRIORITIES_VIEW),
    validate(DocumentAndPrioritiesValidations.requiredId, 'params'),
    DocumentAndPrioritiesService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.DOCUMENTS_PRIORITIES_UPDATE),
    validate(DocumentAndPrioritiesValidations.requiredId, 'params'),
    validate(DocumentAndPrioritiesValidations.create),
    DocumentAndPrioritiesService.updateById as RequestHandler
);

router.patch(
    '/:id/update-document',
    verifyToken(UserPermissions.DOCUMENTS_PRIORITIES_UPDATE_DOCUMENT),
    validate(DocumentAndPrioritiesValidations.requiredId, 'params'),
    validate(DocumentAndPrioritiesValidations.updateDocument),
    DocumentAndPrioritiesService.updateDocument as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.DOCUMENTS_PRIORITIES_UPDATE_DOCUMENT),
    validate(DocumentAndPrioritiesValidations.requiredId, 'params'),
    validate(DocumentAndPrioritiesValidations.updateStatus),
    DocumentAndPrioritiesService.updateStatus as RequestHandler
);

export { router };
