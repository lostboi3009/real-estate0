export { router } from './DocumentAndPriorityRoutes';
