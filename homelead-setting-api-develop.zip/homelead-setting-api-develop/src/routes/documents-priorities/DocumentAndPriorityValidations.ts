import {
    commonValidations,
    DocumentPaymentTerm,
    DocumentTemplateName,
    DocumentType,
    joi,
    PropertyType,
    Status,
} from '@homelead-shared-api';

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const create = joi.object().keys({
    _id: commonValidations.id.optional(),
    documentType: joi
        .string()
        .valid(...Object.values(DocumentType))
        .required(),
    templateName: joi
        .string()
        .valid(...Object.values(DocumentTemplateName))
        .required(),
    priority: joi.number().integer().min(1).required(),
    paymentTerm: joi
        .string()
        .valid(...Object.values(DocumentPaymentTerm))
        .required(),
    isMandatory: joi.boolean().required(),
    propertyType: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyType))
        .required(),
    status: joi
        .string()
        .valid(...Object.values(Status))
        .optional(),
    document: joi.string().trim().optional(),
});

const updateOrCreate = joi.array().items(create).required();

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

const updateDocument = joi.object().keys({
    document: joi.string().trim().required(),
});

export default {
    create,
    updateOrCreate,
    requiredId,
    updateStatus,
    updateDocument,
};
