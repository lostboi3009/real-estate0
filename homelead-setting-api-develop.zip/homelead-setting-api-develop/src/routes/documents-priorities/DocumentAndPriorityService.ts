import { Request, Response } from 'express';
import { CommonId, CommonStatus, CompanyId, IDocumentAndPriority } from '@homelead-shared-api';

import { UpdateDocument, IDocumentationAndPriorityUpdateDoc } from '@dto';
import DocumentsAndPriorityDao from '../../dao/DocumentsAndPriorityDao';

class DocumentAndPriorityService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const documentsAndPriorites = await DocumentsAndPriorityDao.getAll({
            company,
        });
        return res.success(documentsAndPriorites);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user as unknown as CompanyId;
        const { id } = req.params as unknown as CommonId;

        const documentsAndPriority = await DocumentsAndPriorityDao.getById({ id, company });

        if (!documentsAndPriority) {
            return res.notFound(null, req.__('DOCUMENT_NOT_FOUND'));
        }

        return res.success(documentsAndPriority);
    }

    async updateOrCreate(req: Request, res: Response) {
        const { company } = req.user;
        const data: IDocumentationAndPriorityUpdateDoc[] = req.body;
        const priorities = data.map(i => i.priority);
        const uniquePriorities = [...new Set(priorities)];

        if (priorities.length !== uniquePriorities.length) {
            return res.notFound(null, req.__('PRIORITY_ALREADY_TAKEN'));
        }

        for (const item of data) {
            if (item._id) {
                await DocumentsAndPriorityDao.updateById({ id: item._id, data: item, company });
            } else {
                await DocumentsAndPriorityDao.create({
                    ...item,
                    company,
                });
            }
        }

        return res.success(null, req.__('DOCUMENT_UPDATE_SUCCESS'));
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: IDocumentAndPriority = req.body;

        const documentsAndPriority = await DocumentsAndPriorityDao.getById({ id, company });

        if (!documentsAndPriority) {
            return res.notFound(null, req.__('DOCUMENT_NOT_FOUND'));
        }

        const existingPriority = await DocumentsAndPriorityDao.isPriorityExists({
            id,
            priority: data.priority,
            company,
        });

        if (existingPriority) {
            return res.badRequest(null, req.__('PRIORITY_ALREADY_TAKEN'));
        }

        await DocumentsAndPriorityDao.updateById({ id, data, company });

        return res.success(null, req.__('DOCUMENT_UPDATE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: CommonStatus = req.body;

        const documentsAndPriority = await DocumentsAndPriorityDao.getById({ id, company });

        if (!documentsAndPriority) {
            return res.notFound(null, req.__('DOCUMENT_NOT_FOUND'));
        }

        await DocumentsAndPriorityDao.updateById({ id, data, company });

        return res.success(null, req.__('DOCUMENT_UPDATE_SUCCESS'));
    }

    async updateDocument(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: UpdateDocument = req.body;

        const documentsAndPriority = await DocumentsAndPriorityDao.getById({ id, company });

        if (!documentsAndPriority) {
            return res.notFound(null, req.__('DOCUMENT_NOT_FOUND'));
        }

        await DocumentsAndPriorityDao.updateById({ id, data, company });

        return res.success(null, req.__('DOCUMENT_UPDATE_SUCCESS'));
    }
}

export default new DocumentAndPriorityService();
