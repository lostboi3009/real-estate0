import { RequestHandler, Router } from 'express';
import TagService from './TagService';
import TagValidations from './TagValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.TAGS_LIST), TagService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.TAGS_ADD),
    validate(TagValidations.create),
    TagService.create as RequestHandler
);

router.get('/active-tags', verifyToken(), TagService.activeTags as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.TAGS_VIEW),
    validate(TagValidations.requiredId, 'params'),
    TagService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.TAGS_UPDATE),
    validate(TagValidations.requiredId, 'params'),
    validate(TagValidations.create),
    TagService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.TAGS_DELETE),
    validate(TagValidations.requiredId, 'params'),
    TagService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.TAGS_UPDATE),
    validate(TagValidations.requiredId, 'params'),
    validate(TagValidations.updateStatus),
    TagService.updateStatus as RequestHandler
);

export { router };
