import { joi, commonValidations } from '@homelead-shared-api';

const create = joi.object().keys({
    name: joi.string().trim().min(3).max(30).required(),
    description: joi.string().trim().min(3).max(400).required(),
    icon: joi.string().trim().max(200).required(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    create,
    requiredId,
    updateStatus,
};
