export { router } from './TagRoutes';
