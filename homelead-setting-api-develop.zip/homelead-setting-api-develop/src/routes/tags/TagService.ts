import { Request, Response } from 'express';
import TagDao from '../../dao/TagDao';
import { CommonId, CommonStatus, ITag, Status } from '@homelead-shared-api';

class TagService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const tags = await TagDao.getAll({ company });

        return res.success(tags);
    }

    async activeTags(req: Request, res: Response) {
        const { company } = req.user;
        const tags = await TagDao.activeTags({ company });

        return res.success(tags);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const data: ITag = req.body;

        const tag = await TagDao.create({ ...data, company });

        return res.success(tag);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const tag = await TagDao.getById({ id, company });

        if (!tag) {
            return res.notFound(null, req.__('TAG_NOT_FOUND'));
        }

        return res.success(tag);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: ITag = req.body;

        const tag = await TagDao.getById({ id, company });

        if (!tag) {
            return res.notFound(null, req.__('TAG_NOT_FOUND'));
        }

        await TagDao.updateById({ id, company, data });

        return res.success(null, req.__('TAG_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<ITag> = {
            status: Status.ARCHIVED,
        };

        const tag = await TagDao.getById({ id, company });

        if (!tag) {
            return res.notFound(null, req.__('TAG_NOT_FOUND'));
        }

        await TagDao.updateById({ id, company, data });

        return res.success(null, req.__('TAG_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const tag = await TagDao.getById({ id, company });

        if (!tag) {
            return res.notFound(null, req.__('TAG_NOT_FOUND'));
        }

        await TagDao.updateById({ id, company, data });

        return res.success(null, req.__('TAG_STATUS_UPDATED'));
    }
}

export default new TagService();
