import { Request, Response } from 'express';
import SettingDao from '../../dao/SettingDao';
import { ISetting } from '@homelead-shared-api';

class SettingService {
    async getCompanySettings(req: Request, res: Response) {
        const { company } = req.user;

        const settings = await SettingDao.getCompanySettings({
            company,
        });

        return res.success(settings);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const data: ISetting = req.body;

        await SettingDao.updateById({
            company,
            data: {
                ...data,
                company,
            },
        });

        return res.success(null, req.__('SETTING_UPDATE_SUCCESS'));
    }
}

export default new SettingService();
