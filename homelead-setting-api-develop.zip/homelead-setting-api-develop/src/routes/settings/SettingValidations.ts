import {
    joi,
    commonValidations,
    LeadCallToTrack,
    OTPReceiver,
    OtpReceiverChannel,
    WaterMarkPosition,
} from '@homelead-shared-api';

const general = joi
    .object({
        hasInternationalSupport: joi.boolean().optional(),
        hasCallDetectionActivated: joi.boolean().optional(),
        hasCallDetectionForAllLead: joi
            .string()
            .trim()
            .valid(...Object.values(LeadCallToTrack))
            .optional(),
        currency: joi
            .array()
            .items(
                joi.object({
                    _id: commonValidations.id,
                    name: joi.string().trim().required(),
                    symbol: joi.string().trim().required(),
                    isDefault: joi.boolean().required(),
                })
            )
            .optional(),
        countryCode: commonValidations.id.optional(),
        isWaterMarksOnImagesEnabled: joi.boolean().optional(),
        waterMarkImage: joi.string().trim().optional(),
        waterMarkPosition: joi
            .string()
            .trim()
            .valid(...Object.values(WaterMarkPosition))
            .optional(),
        opacity: joi.number().positive().optional(),
        imageHeight: joi.string().trim().optional(),
        imageWidth: joi.string().trim().optional(),
        tempRentBookingPeriod: joi.number().positive().optional(),
        tempPropertyBookingPeriod: joi.number().positive().optional(),
    })
    .optional();

const security = joi
    .object({
        isTwoFactorAuthenticationEnabled: joi.boolean().optional(),
        isCopyPasteEnabled: joi.boolean().optional(),
        isScreenshotEnabled: joi.boolean().optional(),
        otpSettings: joi
            .object({
                channels: joi
                    .array()
                    .items(
                        joi
                            .string()
                            .trim()
                            .valid(...Object.values(OtpReceiverChannel))
                    )
                    .optional(),
                receiver: joi
                    .string()
                    .trim()
                    .valid(...Object.values(OTPReceiver))
                    .optional(),
                receiverUserIds: joi.array().items(commonValidations.id).optional(),
                isEnabledForAll: joi.boolean().optional(),
                userIdsToEnableMFA: joi.array().items(commonValidations.id).optional(),
            })
            .optional(),
    })
    .optional();

const attendance = joi
    .object({
        isShiftTimingFeatureEnabled: joi.boolean().optional(),
        isSelfieMandatoryForClockOut: joi.boolean().optional(),
        isSelfieMandatoryForClockIn: joi.boolean().optional(),
        isShiftTimeEnabledForAllDays: joi.boolean().optional(),
        isEnabledForAllUsers: joi.boolean().optional(),
        userIds: joi.array().items(commonValidations.id).optional(),
        shiftTimingDayWise: joi
            .array()
            .items(
                joi.object({
                    isEnabled: joi.boolean().optional(),
                    day: joi.number().min(0).max(6).optional(),
                    shiftStartTime: joi.string().trim().optional(),
                    shiftEndTime: joi.string().trim().optional(),
                })
            )
            .optional(),
    })
    .optional();

const leads = joi
    .object({
        isLeadsExportEnabled: joi.boolean().optional(),
        isLeadSourceEditable: joi.boolean().optional(),
        isDuelLeadOwnershipEnabled: joi.boolean().optional(),
        isLeadContactInfoMask: joi.boolean().optional(),
        leadNotes: joi
            .object({
                isNotesMandatoryEnabled: joi.boolean().optional(),
                isNotesMandatoryOnAddLead: joi.boolean().optional(),
                isNotesMandatoryOnUpdateLead: joi.boolean().optional(),
                isNotesMandatoryOnMeetingDone: joi.boolean().optional(),
                isNotesMandatoryOnSiteVisitDone: joi.boolean().optional(),
            })
            .optional(),
        leadRotation: joi
            .object({
                team: commonValidations.id.optional(),
                users: joi.array().items(commonValidations.id).optional(),
                teamLead: commonValidations.id.optional(),
                shiftTimeFrom: joi.string().trim().optional(),
                shiftTimeTo: joi.string().trim().optional(),
                rotationTime: joi.number().positive().optional(),
                noOfRotation: joi.number().positive().optional(),
            })
            .optional(),
        manageSubStatus: joi.object().optional(),
        assignmentSetPriority: joi
            .array()
            .items(
                joi.object({
                    priorityName: joi.string().trim().optional(),
                    priorityValue: joi.string().trim().optional(),
                })
            )
            .optional(),
    })
    .optional();

const documentAndPriorities = joi
    .array()
    .items(
        joi.object({
            docType: joi.string().trim().optional(),
            templateName: joi.string().trim().optional(),
            priority: joi.number().positive().optional(),
            paymentTerm: joi.string().trim().optional(),
            isMandatory: joi.boolean().optional(),
            documentFormat: joi.string().trim().optional(),
            isActive: joi.boolean().optional(),
        })
    )
    .optional();

const credentials = joi
    .object({
        instagram: joi
            .object({
                accountId: joi.number().optional(),
                accessToken: joi.string().trim().optional(),
            })
            .optional(),
    })
    .optional();

const update = joi.object().keys({
    general,
    security,
    attendance,
    leads,
    documentAndPriorities,
    isPropertyExportEnabled: joi.boolean().optional(),
    isProjectExportEnabled: joi.boolean().optional(),
    isLandExportEnabled: joi.boolean().optional(),
    credentials,
});

export default {
    update,
};
