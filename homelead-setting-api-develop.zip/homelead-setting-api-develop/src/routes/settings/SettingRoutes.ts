import { RequestHandler, Router } from 'express';
import SettingService from './SettingService';
import SettingValidations from './SettingValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.SETTINGS_LIST), SettingService.getCompanySettings as RequestHandler);

router.put(
    '/',
    verifyToken(UserPermissions.SETTINGS_UPDATE),
    validate(SettingValidations.update),
    SettingService.updateById as RequestHandler
);

export { router };
