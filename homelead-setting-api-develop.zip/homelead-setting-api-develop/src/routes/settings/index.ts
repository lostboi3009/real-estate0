export { router } from './SettingRoutes';
