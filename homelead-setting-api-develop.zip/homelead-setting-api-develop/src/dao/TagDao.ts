import { CommonId, ITagDoc, ITag, Tag, Status, CompanyId } from '@homelead-shared-api';

class TagDao {
    async getAll({ company }: CompanyId): Promise<ITagDoc[]> {
        return Tag.find({
            company,
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeTags({ company }: CompanyId): Promise<ITagDoc[]> {
        return Tag.find({
            company,
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(tag: ITag): Promise<ITagDoc> {
        return Tag.create(tag);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<ITagDoc | null> {
        return Tag.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, company, data }: CommonId & CompanyId & { data: Partial<ITag> }) {
        return Tag.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new TagDao();
