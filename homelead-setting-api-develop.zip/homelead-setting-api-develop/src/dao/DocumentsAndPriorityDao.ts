import {
    CompanyId,
    Status,
    CommonId,
    DocumentAndPriority,
    IDocumentAndPriorityDoc,
    IDocumentAndPriority,
    TypesObjectId,
} from '@homelead-shared-api';

class DocumentsAndPriorityDao {
    async getAll({ company }: CompanyId): Promise<IDocumentAndPriorityDoc[] | null> {
        return DocumentAndPriority.find({
            company,
            status: { $ne: Status.ARCHIVED },
        }).sort({ priority: 1 });
    }

    async create(documents: IDocumentAndPriority): Promise<IDocumentAndPriorityDoc> {
        return DocumentAndPriority.create(documents);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IDocumentAndPriorityDoc | null> {
        return DocumentAndPriority.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async isPriorityExists({
        id,
        priority,
        company,
    }: CompanyId & { priority: number; id: TypesObjectId }): Promise<IDocumentAndPriorityDoc | null> {
        return DocumentAndPriority.findOne({
            _id: { $ne: id },
            company,
            priority,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data, company }: CommonId & CompanyId & { data: Partial<IDocumentAndPriorityDoc> }) {
        return DocumentAndPriority.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new DocumentsAndPriorityDao();
