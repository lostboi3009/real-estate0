import { CompanyId, ISettingDoc, Setting } from '@homelead-shared-api';

class SettingDao {
    async getCompanySettings({ company }: CompanyId): Promise<ISettingDoc | null> {
        return Setting.findOne({
            company,
        }).sort({
            _id: -1,
        });
    }

    async updateById({ company, data }: CompanyId & { data: Partial<ISettingDoc> }) {
        return await Setting.updateOne(
            {
                company,
            },
            {
                $set: data,
            },
            {
                upsert: true,
            }
        );
    }
}

export default new SettingDao();
