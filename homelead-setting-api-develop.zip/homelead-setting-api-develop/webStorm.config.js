System.config({
    paths: {
        '@lib': 'lib',
        '@dto': 'lib/dto',
        '@homelead-shared-api': 'node_modules/homelead-shared-api/build/src',
    },
});