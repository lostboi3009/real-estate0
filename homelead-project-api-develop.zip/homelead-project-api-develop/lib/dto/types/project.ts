import {
    Status,
    CompanyId,
    CommonId,
    IProject,
    TypesObjectId,
    ClpStatus,
    PropertyType,
    DocumentPaymentTerm,
    DocumentType,
    ICompanyDoc,
    IProperty,
    IPropertyBooking,
    IPropertyPaymentDoc,
    ILeadDoc,
} from '@homelead-shared-api';

export interface ProjectInterface {
    name?: string;
    nearByLocations?: string;
}

export interface GetProject extends ProjectInterface, CompanyId {
    status: Status;
    search: string;
    projectType?: string;
    projectUnitSubType?: string;
    budgetRange?: number;
    startDate?: Date;
    endDate?: Date;
}

export interface UpdateProject extends CompanyId, CommonId {
    data: Partial<IProject>;
}

export interface GetBySlug extends CompanyId {
    slug: string;
}

export interface Microsite {
    slug: string;
    company: TypesObjectId;
}

export interface UpdateClpPhase {
    ordinal: number;
    status: ClpStatus;
}

interface BlockName {
    blockName: string;
}

interface PropertySubType {
    name: string;
}

export interface ExportProjectCsv {
    name: string;
    projectType: string[];
    projectUnitSubType: PropertySubType[];
    blocksResidential: BlockName[];
    minBudget: number;
    maxBudget: number;
}

export interface GetProjectBookings extends CompanyId {
    project: TypesObjectId;
}

export interface IPaymentTerm extends CompanyId {
    documentType: DocumentType;
    propertyType: PropertyType;
    paymentTerm: DocumentPaymentTerm;
}

export interface GenrateDocument {
    document: string;
    propertyType: PropertyType;
    documentType: DocumentType;
    company?: ICompanyDoc;
    project?: IProject;
    lead?: ILeadDoc;
    property?: IProperty;
    propertyBooking?: IPropertyBooking;
    propertyPayment?: IPropertyPaymentDoc;
    dueAmount: number;
}
