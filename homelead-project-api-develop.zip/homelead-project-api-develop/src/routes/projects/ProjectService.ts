import { Request, Response } from 'express';
import QRCode from 'qrcode';
import ProjectDao from '../../dao/ProjectDao';
import {
    CommonId,
    CommonStatus,
    IProject,
    Status,
    ProjectStatus,
    Pagination,
    jsonToCsvBuffer,
    ClpStatus,
    PropertyPaymentType,
    TransactionType,
    PaymentMode,
    PropertyPaymentStatus,
    PropertyFinanceDeptStatus,
    PropertyPaymentDueFrom,
    IPropertyPayment,
    DocumentPaymentTerm,
    ILeadDoc,
    IPropertyDoc,
    DocumentType,
    PropertyType,
    ITimeLineDocument,
    ICompanyDoc,
    sendMail,
    isDevEnv,
} from '@homelead-shared-api';
import { ExportProjectCsv, GetProject, Microsite, UpdateClpPhase } from '@dto';
import { exportPdf } from '../../utils/common';
import UserDao from '../../dao/UserDao';
import BookingDao from '../../dao/BookingDao';
import PropertyPaymentDao from '../../dao/PropertyPaymentDao';
import DocumentAndPriorityDao from '../../dao/DocumentAndPriorityDao';
import LeadDao from '../../dao/LeadDao';
import { generateDocument } from '../../utils/document';
import { __ } from '@lib/i18n';

class ProjectService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, status, search, startDate, endDate, projectType, projectUnitSubType, budgetRange } =
            req.query as unknown as GetProject & Pagination;
        const [count, projects] = await Promise.all([
            ProjectDao.countAll({
                company,
                status,
                search,
                startDate,
                endDate,
                projectType,
                projectUnitSubType,
                budgetRange,
            }),
            ProjectDao.getAll({
                company,
                page,
                perPage,
                status,
                search,
                startDate,
                endDate,
                projectType,
                projectUnitSubType,
                budgetRange,
            }),
        ]);

        return res.success({ count, projects });
    }

    async activeProjects(req: Request, res: Response) {
        const { company } = req.user;

        const projects = await ProjectDao.activeProjects({
            company,
        });

        return res.success(projects);
    }

    async microsite(req: Request, res: Response) {
        const { slug, company }: Microsite = req.body;

        const data = await ProjectDao.microsite({ slug, company });

        const microsite = data.length ? data[0] : null;

        if (!microsite) {
            return res.notFound(null, req.__('MICROSITE_NOT_FOUND'));
        }

        return res.success({
            microsite,
        });
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const project: IProject = req.body;
        const slug = project.name.toLowerCase().replace(' ', '-');
        const sumOfClpPercentage = project.clpPhases.reduce((acc, i) => acc + i.percentage, 0);
        const isAllClpPhasesCompleted = project.clpPhases.every(i => i.status === ClpStatus.COMPLETED);

        const isInvalidClpStatus = project.clpPhases.some(
            (i, index) =>
                index > 0 &&
                i.status === ClpStatus.COMPLETED &&
                project.clpPhases[index - 1]?.status !== ClpStatus.COMPLETED
        );

        if (sumOfClpPercentage !== 100) {
            return res.warn(null, req.__('SUM_OF_CLP_PERCENTAGE_SHOULD_BE_100'));
        }

        if (project.projectStatus === ProjectStatus.READY_TO_SHIFT && !isAllClpPhasesCompleted) {
            return res.warn(null, req.__('INVALID_CLP_READY_TO_SHIFT'));
        }

        if (isInvalidClpStatus) {
            return res.warn(null, req.__('INVALID_CLP_PHASES'));
        }

        const companyData = await UserDao.getCompanyById({ company });

        if (!companyData) {
            return res.notFound(null, req.__('USER_NOT_FOUND'));
        }

        const slugExists = await ProjectDao.getBySlug({ slug, company });

        if (slugExists) {
            return res.notFound(null, req.__('PROJECT_NAME_ALREADY_TAKEN'));
        }

        const land = await ProjectDao.getLandById({ id: project.land, company });

        if (!land) {
            return res.notFound(null, req.__('LAND_NOT_FOUND'));
        }

        const qrCode = await QRCode.toDataURL(`${companyData.subDomain}/projects/${slug}`);

        const response = await ProjectDao.create({
            ...project,
            company,
            slug,
            qrCode,
            clpPhases: project.clpPhases.map((i, index) => ({ ...i, ordinal: index })),
            projectStatus: isAllClpPhasesCompleted ? ProjectStatus.READY_TO_SHIFT : project.projectStatus,
        });

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const project = await ProjectDao.detailsById({ id, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        return res.success(project);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: IProject = req.body;

        const project = await ProjectDao.getById({ id, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const land = await ProjectDao.getLandById({ id: project.land, company });

        if (!land) {
            return res.notFound(null, req.__('LAND_NOT_FOUND'));
        }

        await ProjectDao.updateById({ id, company, data });

        return res.success(null, req.__('PROJECT_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IProject> = {
            status: Status.ARCHIVED,
        };

        const project = await ProjectDao.getById({ id, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        await ProjectDao.updateById({ id, company, data });

        return res.success(null, req.__('PROJECT_DELETE_SUCCESS'));
    }

    async updateClpPhase(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: UpdateClpPhase = req.body;
        const previousClpPhaseOrdinal = data.ordinal === 0 ? 0 : data.ordinal - 1;

        const companyData = await UserDao.getCompanyById({ company });

        if (!companyData) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        const project = await ProjectDao.getById({ company, id });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        let projectStatus = project.projectStatus;
        const clpPhase = project.clpPhases.find(i => i.ordinal === data.ordinal);
        const previousClpPhase = project.clpPhases.find(i => i.ordinal === previousClpPhaseOrdinal);

        if (!clpPhase || !previousClpPhase) {
            return res.success(null, req.__('CLP_PHASE_NOT_FOUND'));
        }

        if (clpPhase?.status === ClpStatus.COMPLETED) {
            return res.success(null, req.__('CAN_NOT_UPDATE_CLP_PHASE_POST_COMPLETION'));
        }

        if (data.ordinal && previousClpPhase?.status !== ClpStatus.COMPLETED) {
            return res.success(null, req.__('PREVIOUS_CLP_PHASE_SHOULD_COMPLETE_FIRST'));
        }

        const updatedClpPhases = project.clpPhases.map(i => {
            if (i.ordinal === data.ordinal) {
                i.status = data.status;
            }

            return i;
        });

        const isAllClpPhasesCompleted = updatedClpPhases.every(i => i.status === ClpStatus.COMPLETED);

        if (isAllClpPhasesCompleted) {
            projectStatus = ProjectStatus.READY_TO_SHIFT;
        }

        await ProjectDao.updateById({ id, company, data: { clpPhases: updatedClpPhases, projectStatus } });

        if (data.status === ClpStatus.COMPLETED) {
            const clpPaymentsPromises: IPropertyPayment[] = [];
            const finalBookings = await BookingDao.getAllFinalBookings({ company, project: id });
            const leadIds = [];
            const propertyIds = [];

            for (const { lead, property } of finalBookings) {
                leadIds.push(lead);
                propertyIds.push(property);
            }

            const leads = await LeadDao.getConvertedLeadsByIds({ ids: leadIds, company });
            const properties = await BookingDao.getPropertiesByIds({ ids: propertyIds, company });

            const transformedLeads = leads.reduce((acc: Record<string, ILeadDoc>, i: ILeadDoc) => {
                acc[i._id as unknown as string] = i;
                return acc;
            }, {});

            const transformedroperties = properties.reduce((acc: Record<string, IPropertyDoc>, i: IPropertyDoc) => {
                acc[i._id as unknown as string] = i;
                return acc;
            }, {});

            finalBookings.map(async booking => {
                const lead = transformedLeads[booking.lead as unknown as string];
                const property = transformedroperties[booking.property as unknown as string];
                const clpPhase = booking.clpPhases?.find(phase => {
                    return phase.ordinal === data.ordinal;
                });

                const paymentData = {
                    company,
                    project: id,
                    property: booking.property,
                    booking: booking._id,
                    paymentType: PropertyPaymentType.CLP_PAYMENT,
                    transactionType: TransactionType.CREDIT,
                    paymentStatus: PropertyPaymentStatus.DUE,
                    financeDeptStatus: PropertyFinanceDeptStatus.PENDING,
                    ordinal: clpPhase?.ordinal,
                };

                if (clpPhase?.bankAmount && clpPhase?.bankPaymentStatus === PropertyPaymentStatus.DUE) {
                    clpPaymentsPromises.push({
                        ...paymentData,
                        dueFrom: PropertyPaymentDueFrom.BANK,
                        amount: (clpPhase?.bankAmount || 0) - (clpPhase?.bankAmountReceived || 0),
                        paymentMode: PaymentMode.CHEQUE,
                    });

                    const bookingDocuments = await DocumentAndPriorityDao.getByPaymentTerm({
                        company,
                        documentType: DocumentType.BANK_DEMAND,
                        paymentTerm: DocumentPaymentTerm.ON_EACH_MILESTONE_COMPLETION,
                        propertyType: property?.propertyType as unknown as PropertyType,
                    });

                    const timelineDocuments = (await Promise.all(
                        bookingDocuments.map(async item => {
                            const documentLink = await generateDocument({
                                document: item.document || '',
                                project,
                                propertyType: item.propertyType,
                                documentType: DocumentType.BANK_DEMAND,
                                propertyBooking: booking,
                                lead: lead as unknown as ILeadDoc,
                                property: property as unknown as IPropertyDoc,
                                company: companyData as unknown as ICompanyDoc,
                                dueAmount: (clpPhase?.bankAmount || 0) - (clpPhase?.bankAmountReceived || 0),
                            });

                            return {
                                propertyType: lead?.propertyType,
                                templateName: item.templateName,
                                documentType: item.documentType,
                                priority: item.priority,
                                document: documentLink,
                            };
                        })
                    )) as unknown as ITimeLineDocument[];

                    if (!isDevEnv) {
                        for (const item of timelineDocuments) {
                            sendMail('bank-demand', req.__('BANK_DEMAND'), lead?.email as unknown as string, {
                                customerName: lead?.name,
                                companyName: companyData?.name,
                                documentLink: item.document,
                            });
                        }
                    }

                    await BookingDao.updateTimelineDocument({ id: booking._id, company, data: timelineDocuments });
                }

                if (clpPhase?.customerAmount && clpPhase?.customerPaymentStatus === PropertyPaymentStatus.DUE) {
                    clpPaymentsPromises.push({
                        ...paymentData,
                        dueFrom: PropertyPaymentDueFrom.USER,
                        amount: (clpPhase?.customerAmount || 0) - (clpPhase?.customerAmountReceived || 0),
                        paymentMode: PaymentMode.ONLINE,
                    });

                    const bookingDocuments = await DocumentAndPriorityDao.getByPaymentTerm({
                        company,
                        documentType: DocumentType.CUSTOMER_DEMAND,
                        paymentTerm: DocumentPaymentTerm.ON_EACH_MILESTONE_COMPLETION,
                        propertyType: property?.propertyType as unknown as PropertyType,
                    });

                    const timelineDocuments = (await Promise.all(
                        bookingDocuments.map(async item => {
                            const documentLink = await generateDocument({
                                document: item.document || '',
                                project,
                                propertyType: item.propertyType,
                                documentType: DocumentType.CUSTOMER_DEMAND,
                                propertyBooking: booking,
                                lead: lead as unknown as ILeadDoc,
                                property: property as unknown as IPropertyDoc,
                                company: companyData as unknown as ICompanyDoc,
                                dueAmount: (clpPhase?.customerAmount || 0) - (clpPhase?.customerAmountReceived || 0),
                            });

                            return {
                                propertyType: lead?.propertyType,
                                templateName: item.templateName,
                                documentType: item.documentType,
                                priority: item.priority,
                                document: documentLink,
                            };
                        })
                    )) as unknown as ITimeLineDocument[];

                    if (!isDevEnv) {
                        for (const item of timelineDocuments) {
                            sendMail('customer-demand', req.__('CUSTOMER_DEMAND'), lead?.email as unknown as string, {
                                customerName: lead?.name,
                                companyName: companyData?.name,
                                documentLink: item.document,
                            });
                        }
                    }

                    await BookingDao.updateTimelineDocument({ id: booking._id, company, data: timelineDocuments });
                }
            });

            await PropertyPaymentDao.bulkCreate(clpPaymentsPromises);
        }

        return res.success(null, req.__('CLP_PHASE_UPDATED'));
    }

    async updateStatus(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const project = await ProjectDao.getById({ company, id });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        await ProjectDao.updateById({ id, company, data });

        return res.success(null, req.__('PROJECT_STATUS_UPDATED'));
    }

    async exportCsv(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, status, search, startDate, endDate, projectType, projectUnitSubType, budgetRange } =
            req.query as unknown as GetProject & Pagination;

        const projects = (await ProjectDao.getAll({
            company,
            page,
            perPage,
            status,
            search,
            startDate,
            endDate,
            projectType,
            projectUnitSubType,
            budgetRange,
        })) as unknown as ExportProjectCsv[];

        if (!projects) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const filteredProjects = projects.map(project => ({
            name: project?.name,
            propertyType: project.projectType.join(', '),
            propertyUnitSubType: project?.projectUnitSubType?.map(subType => subType?.name).join(', ') || 'N/A',
            blockName: project?.blocksResidential[0]?.blockName,
            minBudget: project?.minBudget,
            maxBudget: project?.maxBudget,
        }));

        const csv = jsonToCsvBuffer(filteredProjects, {
            excelBOM: true,
        });

        res.header('Content-Type', 'text/csv');
        res.attachment('projects.csv');
        return res.send(csv);
    }

    async exportPdf(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, status, search, startDate, endDate, projectType, projectUnitSubType, budgetRange } =
            req.query as unknown as GetProject & Pagination;

        const projects = await ProjectDao.getAll({
            company,
            page,
            perPage,
            status,
            search,
            startDate,
            endDate,
            projectType,
            projectUnitSubType,
            budgetRange,
        });

        if (!projects) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const pdfBuffer = await exportPdf('export-projects.ejs', projects);

        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="lands.pdf"');
        return res.send(pdfBuffer);
    }
}

export default new ProjectService();
