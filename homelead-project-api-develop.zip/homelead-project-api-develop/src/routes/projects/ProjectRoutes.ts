import { RequestHandler, Router } from 'express';
import ProjectService from './ProjectService';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import ProjectValidations from './ProjectValidations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.PROJECTS_LIST),
    validate(ProjectValidations.getAll, 'query'),
    ProjectService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.PROJECTS_ADD),
    validate(ProjectValidations.create),
    ProjectService.create as RequestHandler
);

router.get('/active-projects', verifyToken(), ProjectService.activeProjects as RequestHandler);

router.get('/export-pdf', verifyToken(UserPermissions.PROJECTS_EXPORT_PDF), ProjectService.exportPdf as RequestHandler);

router.get('/export-csv', verifyToken(UserPermissions.PROJECTS_EXPORT_CSV), ProjectService.exportCsv as RequestHandler);

router.post(
    '/microsite',
    validate(ProjectValidations.microsite),
    ProjectService.microsite as unknown as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_VIEW),
    validate(ProjectValidations.requiredId, 'params'),
    ProjectService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_UPDATE),
    validate(ProjectValidations.requiredId, 'params'),
    validate(ProjectValidations.update),
    ProjectService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_DELETE),
    validate(ProjectValidations.requiredId, 'params'),
    ProjectService.deleteById as RequestHandler
);

router.patch(
    '/:id/clp-phase',
    verifyToken(UserPermissions.PROJECTS_CLP_PHASES_UPDATE),
    validate(ProjectValidations.requiredId, 'params'),
    validate(ProjectValidations.updateClpPhase),
    ProjectService.updateClpPhase as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.PROJECTS_UPDATE),
    validate(ProjectValidations.requiredId, 'params'),
    validate(ProjectValidations.updateStatus),
    ProjectService.updateStatus as RequestHandler
);

export { router };
