import { joi, commonValidations, BankAccountType, PropertyType, ProjectStatus, ClpStatus } from '@homelead-shared-api';

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const getAll = joi.object().keys({
    page: commonValidations.page,
    perPage: commonValidations.perPage,
    status: commonValidations.status.optional(),
    search: joi.string().trim().optional(),
    startDate: joi.date().optional(),
    endDate: joi.date().greater(joi.ref('startDate')).optional(),
    budgetRange: joi.number().positive().optional(),
    projectType: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyType))
        .optional(),
    projectUnitSubType: commonValidations.id.optional(),
});

const create = joi.object().keys({
    land: commonValidations.id,
    name: joi.string().trim().min(3).max(30).required(),
    projectType: joi
        .array()
        .items(
            joi
                .string()
                .trim()
                .valid(...Object.values(PropertyType))
                .required()
        )
        .required(),
    projectUnitSubType: joi.array().items(commonValidations.id).required(),
    category: commonValidations.id,
    projectStatus: joi
        .string()
        .trim()
        .valid(...Object.values(ProjectStatus))
        .required(),
    minBudget: joi.number().positive().required(),
    maxBudget: joi.number().min(joi.ref('minBudget')).required(),
    startDate: joi.date().required(),
    completionDate: joi.date().greater(joi.ref('startDate')).required(),
    countryCode: commonValidations.countryCode,
    phone: commonValidations.phone,
    email: commonValidations.email,
    website: joi.string().trim().uri().optional(),
    address: joi.string().trim().required(),
    country: commonValidations.id,
    state: commonValidations.id,
    city: commonValidations.id,
    zipCode: joi.string().trim().required(),
    coordinates: commonValidations.coordinates.optional(),
    reraRegistrationNumber: joi.string().trim().required(),
    projectRegistrationNumber: joi.string().trim().required(),
    layoutPlanImages: joi.array().items(joi.string().trim()).optional(),
    isGovtApproved: joi.boolean().optional(),
    govtApprovedDocuments: joi.array().items(joi.string().trim()).optional(),
    noOfPhaseResidential: joi.number().positive().optional(),
    noOfUnitsResidential: joi.number().positive().optional(),
    propertyUnitSubTypesResidential: joi.array().items(commonValidations.id).optional(),
    bhksResidential: joi.array().items(commonValidations.id).optional(),
    bhkTypesResidential: joi.array().items(commonValidations.id).optional(),
    noOfBlocksResidential: joi.number().positive().optional(),
    blocksResidential: joi
        .array()
        .items(
            joi.object().keys({
                blockName: joi.string().trim().required(),
                noOfFloors: joi.number().positive().required(),
                floors: joi
                    .array()
                    .items(
                        joi.object().keys({
                            floorName: joi.string().trim().required(),
                            series: joi.string().trim().required(),
                            unitFrom: joi.string().trim().required(),
                            unitTo: joi.string().trim().required(),
                            bhk: commonValidations.id.required(),
                        })
                    )
                    .required(),
            })
        )
        .optional(),
    noOfPhaseCommercial: joi.number().positive().optional(),
    noOfUnitsCommercial: joi.number().positive().optional(),
    propertyUnitSubTypesCommercial: joi.array().items(commonValidations.id).optional(),
    noOfBlocksCommercial: joi.number().positive().optional(),
    blocksCommercial: joi
        .array()
        .items(
            joi.object().keys({
                blockName: joi.string().trim().required(),
                noOfFloors: joi.number().positive().required(),
                floors: joi
                    .array()
                    .items(
                        joi.object().keys({
                            floorName: joi.string().trim().required(),
                            series: joi.string().trim().required(),
                            unitFrom: joi.string().trim().required(),
                            unitTo: joi.string().trim().required(),
                        })
                    )
                    .required(),
            })
        )
        .optional(),
    amenities: joi.array().items(commonValidations.id).optional(),
    nearByLocations: joi.array().items(commonValidations.id).optional(),
    images: joi.array().items(joi.string().trim()).optional(),
    videos: joi.array().items(joi.string().trim()).optional(),
    brochure: joi.array().items(joi.string().trim()).optional(),
    qrCode: joi.string().trim().optional(),
    documents: joi
        .array()
        .items(
            joi.object().keys({
                documentName: joi.string().trim().required(),
                document: joi.string().trim().required(),
            })
        )
        .optional(),
    promoterDetails: joi
        .array()
        .items(
            joi.object().keys({
                promoterName: joi.string().trim().required(),
                promoterCountryCode: joi.string().trim().required(),
                promoterPhone: joi.string().trim().required(),
            })
        )
        .optional(),
    financerBankDetails: joi
        .array()
        .items(
            joi.object().keys({
                bankNameId: commonValidations.id,
                accountNo: joi.string().trim().required(),
                accountType: joi
                    .string()
                    .trim()
                    .valid(...Object.values(BankAccountType))
                    .required(),
            })
        )
        .optional(),
    clpPhases: joi
        .array()
        .items(
            joi
                .object()
                .keys({
                    name: joi.string().trim().required(),
                    percentage: joi.number().positive().required(),
                    status: joi
                        .string()
                        .trim()
                        .valid(...Object.values(ClpStatus))
                        .required(),
                })
                .required()
        )
        .required(),
});

const update = joi.object().keys({
    land: commonValidations.id,
    name: joi.string().trim().min(3).max(30).required(),
    projectType: joi
        .array()
        .items(
            joi
                .string()
                .trim()
                .valid(...Object.values(PropertyType))
                .required()
        )
        .required(),
    projectUnitSubType: joi.array().items(commonValidations.id).required(),
    category: commonValidations.id,
    minBudget: joi.number().positive().required(),
    maxBudget: joi.number().min(joi.ref('minBudget')).required(),
    startDate: joi.date().required(),
    completionDate: joi.date().greater(joi.ref('startDate')).required(),
    countryCode: commonValidations.countryCode,
    phone: commonValidations.phone,
    email: commonValidations.email,
    website: joi.string().trim().uri().optional(),
    address: joi.string().trim().required(),
    country: commonValidations.id,
    state: commonValidations.id,
    city: commonValidations.id,
    zipCode: joi.string().trim().required(),
    coordinates: commonValidations.coordinates.optional(),
    reraRegistrationNumber: joi.string().trim().required(),
    projectRegistrationNumber: joi.string().trim().required(),
    layoutPlanImages: joi.array().items(joi.string().trim()).optional(),
    isGovtApproved: joi.boolean().optional(),
    govtApprovedDocuments: joi.array().items(joi.string().trim()).optional(),
    noOfPhaseResidential: joi.number().positive().optional(),
    noOfUnitsResidential: joi.number().positive().optional(),
    propertyUnitSubTypesResidential: joi.array().items(commonValidations.id).optional(),
    bhksResidential: joi.array().items(commonValidations.id).optional(),
    bhkTypesResidential: joi.array().items(commonValidations.id).optional(),
    noOfBlocksResidential: joi.number().positive().optional(),
    blocksResidential: joi
        .array()
        .items(
            joi.object().keys({
                blockName: joi.string().trim().required(),
                noOfFloors: joi.number().positive().required(),
                floors: joi
                    .array()
                    .items(
                        joi.object().keys({
                            floorName: joi.string().trim().required(),
                            series: joi.string().trim().required(),
                            unitFrom: joi.string().trim().required(),
                            unitTo: joi.string().trim().required(),
                            bhk: commonValidations.id.required(),
                        })
                    )
                    .required(),
            })
        )
        .optional(),
    noOfPhaseCommercial: joi.number().positive().optional(),
    noOfUnitsCommercial: joi.number().positive().optional(),
    propertyUnitSubTypesCommercial: joi.array().items(commonValidations.id).optional(),
    noOfBlocksCommercial: joi.number().positive().optional(),
    blocksCommercial: joi
        .array()
        .items(
            joi.object().keys({
                blockName: joi.string().trim().required(),
                noOfFloors: joi.number().positive().required(),
                floors: joi
                    .array()
                    .items(
                        joi.object().keys({
                            floorName: joi.string().trim().required(),
                            series: joi.string().trim().required(),
                            unitFrom: joi.string().trim().required(),
                            unitTo: joi.string().trim().required(),
                        })
                    )
                    .required(),
            })
        )
        .optional(),
    amenities: joi.array().items(commonValidations.id).optional(),
    nearByLocations: joi.array().items(commonValidations.id).optional(),
    images: joi.array().items(joi.string().trim()).optional(),
    videos: joi.array().items(joi.string().trim()).optional(),
    brochure: joi.array().items(joi.string().trim()).optional(),
    qrCode: joi.string().trim().optional(),
    documents: joi
        .array()
        .items(
            joi.object().keys({
                documentName: joi.string().trim().required(),
                document: joi.string().trim().required(),
            })
        )
        .optional(),
    promoterDetails: joi
        .array()
        .items(
            joi.object().keys({
                promoterName: joi.string().trim().required(),
                promoterCountryCode: joi.string().trim().required(),
                promoterPhone: joi.string().trim().required(),
            })
        )
        .optional(),
    financerBankDetails: joi
        .array()
        .items(
            joi.object().keys({
                bankNameId: commonValidations.id,
                accountNo: joi.string().trim().required(),
                accountType: joi
                    .string()
                    .trim()
                    .valid(...Object.values(BankAccountType))
                    .required(),
            })
        )
        .optional(),
});

const updateClpPhase = joi.object().keys({
    ordinal: joi.number().min(0).required(),
    status: joi.string().trim().valid(ClpStatus.IN_PROGRESS, ClpStatus.COMPLETED).required(),
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

const microsite = joi.object().keys({
    slug: joi.string().trim().required(),
    company: commonValidations.id,
});

export default {
    create,
    update,
    getAll,
    requiredId,
    updateClpPhase,
    updateStatus,
    microsite,
};
