import { chromium } from 'playwright';
import { GenrateDocument } from '@lib/dto';
import { DocumentExtensions, DocumentType, PropertyType, showDate } from '@homelead-shared-api';
import { uploadFile } from './fileUpload';

interface HtmlToPdfAndUploadResult {
    fileUrl: string;
}

export const htmlToPdfBuffer = async (htmlContent: string): Promise<Buffer> => {
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();

    await page.setContent(htmlContent);

    const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true,
        margin: { top: '1cm', bottom: '1cm', left: '1cm', right: '1cm' },
    });

    await browser.close();

    return pdfBuffer;
};

export const genrateDocumentData = ({
    propertyType,
    documentType,
    project,
    lead,
    property,
    dueAmount,
    company,
}: Omit<GenrateDocument, 'document'>): Record<string, string | number> => {
    let custom = {};

    const formattedDate = showDate();

    if (propertyType == PropertyType.RESIDENTIAL) {
        switch (documentType) {
            case DocumentType.CUSTOMER_DEMAND:
                custom = {
                    propertyType,
                    date: formattedDate,
                    customerName: lead?.name || '-',
                    propertyAddress: project?.address || '-',
                    flatNumber: property?.flatNo || '-',
                    dueAmount,
                    companyName: company?.name || '-',
                    companyEmail: company?.primaryEmail || '-',
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || ''),
                };
                break;

            case DocumentType.BANK_DEMAND:
                custom = {
                    propertyType,
                    date: formattedDate,
                    customerName: lead?.name || '-',
                    propertyAddress: project?.address || '-',
                    flatNumber: property?.flatNo || '-',
                    dueAmount,
                    companyName: company?.name || '-',
                    companyEmail: company?.primaryEmail || '-',
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || ''),
                };
                break;

            default:
                throw new Error('Invalid Document Type');
        }
    }

    if (propertyType == PropertyType.COMMERCIAL) {
        switch (documentType) {
            case DocumentType.CUSTOMER_DEMAND:
                custom = {
                    propertyType,
                    date: formattedDate,
                    customerName: lead?.name || '-',
                    propertyAddress: project?.address || '-',
                    flatNumber: property?.flatNo || '-',
                    dueAmount,
                    companyName: company?.name || '-',
                    companyEmail: company?.primaryEmail || '-',
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || ''),
                };
                break;

            case DocumentType.BANK_DEMAND:
                custom = {
                    propertyType,
                    date: formattedDate,
                    customerName: lead?.name || '-',
                    propertyAddress: project?.address || '-',
                    flatNumber: property?.flatNo || '-',
                    dueAmount,
                    companyName: company?.name || '-',
                    companyEmail: company?.primaryEmail || '-',
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || ''),
                };
                break;

            default:
                throw new Error('Invalid Document Type');
        }
    }

    return custom;
};

export const generateDocument = async ({
    document,
    propertyType,
    documentType,
    project,
    lead,
    property,
    dueAmount,
    company,
}: GenrateDocument) => {
    const custom = genrateDocumentData({
        propertyType,
        documentType,
        project,
        lead,
        property,
        dueAmount,
        company,
    });

    for (const key in custom) {
        document = document.replaceAll(`{{${key}}}`, custom[key] as unknown as string);
    }

    const pdfBuffer = await htmlToPdfBuffer(document);

    return uploadFile({
        buffer: pdfBuffer,
        location: 'bookings/documents',
        extension: DocumentExtensions.pdf,
    });
};
