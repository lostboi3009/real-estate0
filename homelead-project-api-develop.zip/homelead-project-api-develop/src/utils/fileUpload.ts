import { PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { DocumentExtensions, logger, randomString } from '@homelead-shared-api';

interface AWSConfig {
    region: string;
    credentials?: {
        accessKeyId: string;
        secretAccessKey: string;
    };
}

interface UploadFile {
    buffer: Buffer;
    location: string;
    extension: DocumentExtensions;
}

const accessKeyId = process.env.AWS_S3_ACCESS_KEY_ID;
const secretAccessKey = process.env.AWS_S3_SECRET_ACCESS_KEY;
const region = process.env.AWS_S3_REGION;
const bucket = process.env.AWS_S3_BUCKET;

const awsConfig: AWSConfig = {
    region,
    credentials: {
        accessKeyId,
        secretAccessKey,
    },
};

if (process.env.NODE_ENV === 'production') {
    delete awsConfig.credentials;
}

const s3Client = new S3Client(awsConfig);

const uploadFile = async ({ buffer, location, extension }: UploadFile): Promise<string> => {
    const key = `${location}/${randomString()}.${extension}`;

    try {
        const command = new PutObjectCommand({
            Bucket: bucket,
            Key: key,
            Body: buffer,
            ACL: 'public-read',
        });

        await s3Client.send(command);
    } catch (err) {
        if (err) {
            logger.error('UTILS:: uploadFile: error while reading temporary file:', err);
            throw err;
        }
    }

    return `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
};

export { uploadFile };
