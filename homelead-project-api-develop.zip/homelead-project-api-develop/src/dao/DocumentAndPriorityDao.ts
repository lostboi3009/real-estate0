import { DocumentAndPriority, IDocumentAndPriorityDoc, Status } from '@homelead-shared-api';
import { IPaymentTerm } from '@dto';

class DocumentAndPriorityDao {
    async getByPaymentTerm({
        company,
        paymentTerm,
        propertyType,
        documentType,
    }: IPaymentTerm): Promise<IDocumentAndPriorityDoc[]> {
        return DocumentAndPriority.find({
            company,
            propertyType,
            documentType,
            paymentTerm,
            status: { $ne: Status.ARCHIVED },
        });
    }
}

export default new DocumentAndPriorityDao();
