import { IPropertyPayment, IPropertyPaymentDoc, PropertyPayment } from '@homelead-shared-api';

class PropertyPaymentDao {
    async bulkCreate(propertyPayments: IPropertyPayment[]): Promise<IPropertyPaymentDoc[]> {
        return PropertyPayment.insertMany(propertyPayments);
    }
}

export default new PropertyPaymentDao();
