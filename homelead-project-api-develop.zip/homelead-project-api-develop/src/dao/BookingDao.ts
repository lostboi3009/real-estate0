import {
    CommonId,
    CompanyId,
    IPropertyBookingDoc,
    IPropertyDoc,
    ITimeLineDocument,
    Property,
    PropertyBooking,
    PropertyBookingPaymentStatus,
    PropertyBookingType,
    PropertyFinanceDeptStatus,
    Status,
    TypesObjectId,
} from '@homelead-shared-api';
import { GetProjectBookings } from '@dto';

class BookingDao {
    async getAllFinalBookings({ company, project }: GetProjectBookings): Promise<IPropertyBookingDoc[]> {
        return PropertyBooking.find({
            company,
            project,
            status: Status.ACTIVE,
            bookingType: PropertyBookingType.FINAL_BOOKING,
            bookingPaymentStatus: PropertyBookingPaymentStatus.PAID,
            financeDeptStatus: PropertyFinanceDeptStatus.ACCEPTED,
        })
            .select('_id property clpPhases lead')
            .sort({ _id: -1 });
    }

    async updateTimelineDocument({ id, data, company }: CommonId & CompanyId & { data: ITimeLineDocument[] }) {
        return PropertyBooking.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $push: {
                    timelineDocuments: data,
                },
            }
        );
    }

    async getPropertiesByIds({ ids, company }: { ids: TypesObjectId[] } & CompanyId): Promise<IPropertyDoc[]> {
        return Property.find({
            _id: { $in: ids },
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }
}

export default new BookingDao();
