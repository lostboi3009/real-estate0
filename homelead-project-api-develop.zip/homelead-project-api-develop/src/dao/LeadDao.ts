import { CompanyId, ILeadDoc, Lead, Status, LeadStatus, TypesObjectId } from '@homelead-shared-api';

class LeadDao {
    async getConvertedLeadsByIds({ ids, company }: { ids: TypesObjectId[] } & CompanyId): Promise<ILeadDoc[]> {
        return Lead.find({
            _id: { $in: ids },
            company,
            leadStatus: LeadStatus.CONVERTED,
            status: { $ne: Status.ARCHIVED },
        });
    }
}

export default new LeadDao();
