import moment from 'moment-timezone';
import { GetBySlug, GetProject, Microsite, UpdateProject } from '@dto';
import {
    CommonId,
    CompanyId,
    getSearchRegex,
    ILandDoc,
    IProject,
    IProjectDoc,
    Land,
    mongoose,
    Project,
    Status,
    Pagination,
    toObjectId,
} from '@homelead-shared-api';

type FilterQueryIProject = mongoose.FilterQuery<IProject>;

class ProjectDao {
    getAll({
        company,
        page,
        perPage,
        status,
        search,
        startDate,
        endDate,
        projectType,
        projectUnitSubType,
        budgetRange,
    }: GetProject & Pagination): Promise<IProjectDoc[]> {
        const matchCriteria: FilterQueryIProject = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { name: { $regex: searchRegex } },
                { reraRegistrationNumber: { $regex: searchRegex } },
                { address: { $regex: searchRegex } },
            ];
        }

        if (projectType) {
            matchCriteria.projectType = projectType;
        }

        if (projectUnitSubType) {
            matchCriteria.projectUnitSubType = projectUnitSubType;
        }

        if (budgetRange) {
            matchCriteria.$and = [{ minBudget: { $lte: budgetRange } }, { maxBudget: { $gte: budgetRange } }];
        }

        if (startDate && endDate) {
            matchCriteria.startDate = {
                $gte: moment(startDate).startOf('day'),
                $lte: moment(endDate).endOf('day'),
            };
        }

        return Project.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .populate([{ path: 'projectUnitSubType', select: 'name' }])
            .sort({ _id: -1 });
    }

    countAll({
        company,
        status,
        search,
        startDate,
        endDate,
        projectType,
        projectUnitSubType,
        budgetRange,
    }: GetProject): Promise<number> {
        const matchCriteria: FilterQueryIProject = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { name: { $regex: searchRegex } },
                { reraRegistrationNumber: { $regex: searchRegex } },
                { address: { $regex: searchRegex } },
            ];
        }

        if (projectType) {
            matchCriteria.projectType = projectType;
        }

        if (projectUnitSubType) {
            matchCriteria.projectUnitSubType = projectUnitSubType;
        }

        if (budgetRange) {
            matchCriteria.$and = [{ minBudget: { $lte: budgetRange } }, { maxBudget: { $gte: budgetRange } }];
        }

        if (startDate && endDate) {
            matchCriteria.startDate = {
                $gte: moment(startDate).startOf('day'),
                $lte: moment(endDate).endOf('day'),
            };
        }

        return Project.countDocuments(matchCriteria);
    }

    async create(name: IProject): Promise<IProjectDoc> {
        return Project.create(name);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IProjectDoc | null> {
        return Project.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async detailsById({ id, company }: CommonId & CompanyId): Promise<IProjectDoc | null> {
        return Project.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        }).populate([
            { path: 'land', select: 'name' },
            { path: 'amenities', select: 'name icon' },
            { path: 'bhkTypesResidential', select: 'name' },
            { path: 'bhksResidential', select: 'name' },
            { path: 'category', select: 'name' },
            { path: 'financerBankDetails.bankNameId', select: 'name emoji' },
            { path: 'nearByLocations', select: 'name' },
            { path: 'projectUnitSubType', select: 'name projectType' },
            { path: 'propertyUnitSubTypesCommercial', select: 'name projectType' },
            { path: 'propertyUnitSubTypesResidential', select: 'name projectType' },
        ]);
    }

    async getBySlug({ slug, company }: GetBySlug): Promise<IProjectDoc | null> {
        return Project.findOne({
            slug,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async activeProjects({ company }: CompanyId): Promise<IProjectDoc[]> {
        return Project.find({
            company,
            status: Status.ACTIVE,
        }).sort({ _id: -1 });
    }

    async microsite({ slug, company }: Microsite): Promise<IProjectDoc[]> {
        const matchCriteria: FilterQueryIProject = {
            slug,
            company: toObjectId(company as unknown as string),
            status: Status.ACTIVE,
        };

        return Project.aggregate([
            { $match: matchCriteria },
            {
                $lookup: {
                    from: 'companies',
                    localField: 'company',
                    foreignField: '_id',
                    as: 'company',
                },
            },
            {
                $lookup: {
                    from: 'countries',
                    localField: 'country',
                    foreignField: '_id',
                    as: 'country',
                },
            },
            {
                $unwind: {
                    path: '$country',
                    preserveNullAndEmptyArrays: true,
                },
            },
            {
                $addFields: {
                    state: {
                        $arrayElemAt: [
                            {
                                $filter: {
                                    input: '$country.states',
                                    as: 'state',
                                    cond: { $eq: ['$$state._id', '$state'] },
                                },
                            },
                            0,
                        ],
                    },
                },
            },
            {
                $addFields: {
                    city: {
                        $arrayElemAt: [
                            {
                                $filter: {
                                    input: '$state.cities',
                                    as: 'city',
                                    cond: { $eq: ['$$city._id', '$city'] },
                                },
                            },
                            0,
                        ],
                    },
                },
            },
            {
                $lookup: {
                    from: 'project-categories',
                    localField: 'category',
                    foreignField: '_id',
                    as: 'category',
                },
            },
            {
                $lookup: {
                    from: 'amenities',
                    localField: 'amenities',
                    foreignField: '_id',
                    as: 'amenities',
                },
            },
            {
                $lookup: {
                    from: 'near-by-locations',
                    localField: 'nearByLocations',
                    foreignField: '_id',
                    as: 'nearByLocations',
                },
            },
            {
                $lookup: {
                    from: 'property-unit-sub-types',
                    localField: 'projectUnitSubType',
                    foreignField: '_id',
                    as: 'projectUnitSubType',
                },
            },
            {
                $lookup: {
                    from: 'property-unit-sub-types',
                    localField: 'propertyUnitSubTypesCommercial',
                    foreignField: '_id',
                    as: 'propertyUnitSubTypesCommercial',
                },
            },
            {
                $lookup: {
                    from: 'property-unit-sub-types',
                    localField: 'propertyUnitSubTypesResidential',
                    foreignField: '_id',
                    as: 'propertyUnitSubTypesResidential',
                },
            },
            {
                $lookup: {
                    from: 'bhk',
                    localField: 'bhksResidential',
                    foreignField: '_id',
                    as: 'bhksResidential',
                },
            },
            {
                $lookup: {
                    from: 'bhk-types',
                    localField: 'bhkTypesResidential',
                    foreignField: '_id',
                    as: 'bhkTypesResidential',
                },
            },
            {
                $unwind: {
                    path: '$financerBankDetails',
                    preserveNullAndEmptyArrays: true,
                },
            },
            {
                $lookup: {
                    from: 'bank-names',
                    localField: 'financerBankDetails.bankNameId',
                    foreignField: '_id',
                    as: 'financerBankDetails',
                },
            },
            {
                $project: {
                    name: 1,
                    projectType: 1,
                    minBudget: 1,
                    maxBudget: 1,
                    qrCode: 1,
                    startDate: 1,
                    completionDate: 1,
                    projectStatus: 1,
                    noOfBlocksResidential: 1,
                    noOfBlocksCommercial: 1,
                    noOfUnitsResidential: 1,
                    noOfUnitsCommercial: 1,
                    isGovtApproved: 1,
                    videos: 1,
                    brochure: 1,
                    images: 1,
                    financerBankDetails: 1,
                    coordinates: 1,
                    noOfFloorsResidential: { $arrayElemAt: ['$blocksResidential.noOfFloors', 0] },
                    noOfFloorsCommercial: { $arrayElemAt: ['$blocksCommercial.noOfFloors', 0] },
                    company: { $arrayElemAt: ['$company', 0] },
                    country: '$country.name',
                    state: '$state.name',
                    city: '$city.name',
                    category: { $arrayElemAt: ['$category.name', 0] },
                    amenities: 1,
                    nearByLocations: { $map: { input: '$nearByLocations', as: 'location', in: '$$location.name' } },
                    projectUnitSubType: 1,
                    propertyUnitSubTypesResidential: 1,
                    propertyUnitSubTypesCommercial: 1,
                    bhksResidential: 1,
                    bhkTypesResidential: 1,
                },
            },
            { $limit: 1 },
        ]);
    }

    async updateById({ company, data, id }: UpdateProject) {
        return Project.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    getLandById({ id, company }: CommonId & CompanyId): Promise<ILandDoc | null> {
        return Land.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }
}

export default new ProjectDao();
