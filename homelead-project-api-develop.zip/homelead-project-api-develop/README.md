# HomeLead Project API

HomeLead Project API MicroService

## Getting Started

This project is built using NodeJS version 20.18.0 which connects to a nosql database, at the moment MongoDB 7.0.14
The following is a list of essential technologies:

- [NodeJS](https://nodejs.org/en/) version 20.18.0 or newer
- [MongoDB](https://www.mongodb.com/) version 7.0.14

## Recommended Technologies

- [Homebrew](https://brew.sh/) to install NVM
- NVM - Node Version Manager is used to manage and use different versions of node
- run `brew install nvm` to install on terminal
- run `nvm install <version>` where version is 20.18.0 or newer on terminal

## Setup

Prior to commencing the project, it is necessary to undertake a few preliminary steps to establish the project
environment.

1. Open a Terminal window and navigate to the project root directory:

    ```bash
    $ cd <project_directory>
    ```

2. Download project dependencies

    ```bash
    $ npm install
    ```

3. Copy the `.env.example` files to create the important `.env` file which will define all environment
   variables to be used throughout the project.

    ```bash
    $ cp .env.api.example .env.api
    ```

### Using Docker

You will need to have [Docker Desktop](https://www.docker.com/products/docker-desktop) installed before moving on.
Docker Desktop, when running, will give your machine access to the docker and docker-compose cli tools that we
will be using later. We will use Docker to run the API server.

#### To Begin

If setting up the docker containers for the first time, ensure Docker Desktop is running and you have access to the cli
tools.
Run the following command and successful output should look something like:

```bash
$ docker --version
Docker version 27.2.0
```

The project has a local `docker-compose.yml` file that will create the docker images for you. Simply run:

```bash
$ docker-compose up -d
```

This will download the docker images if needed and run the services for you. After a short time the API server
will start automatically.

**Note:**
Running the API through docker-compose is our new way of running the API server. `.env` files should be
configured correctly for a successful start

To see the the std-out from the API server the following command can be used:
`docker ps`
Find the container with a name that looks something like: `homelead-project-api`

Then run `docker logs -f ${CONTAINER_NAME}` to see and follow the logs from that container.

You can use the Docker Desktop dashboard to manage starting/stopping the docker containers from here on or use the cli.

```bash
$ docker-compose stop   # to stop all containers/services defined in the docker-compose.yml

$ docker-compose start  # to start up the containers/services where they left off
```

To destroy docker containers/services related to this project:

```bash
$ docker-compose down
```

### From Scratch

> This section will assume that you have MongoDB & NodeJS installed on your system, either directly or using `nvm` as
> well

#### Installing dependencies

Run `npm install` in project root

#### Scripts

Build: Run `npm run build` in project root to generate build files

Watch API: Run `npm run watch` in project root to run server in watch mode

Start API: Run `npm run start` in project root to run server from generated build

## Code Structure

> Folder structure options and naming conventions

### A typical top-level directory layout

    .
    ├── lib
         ├── dto
         ├── i18n
    ├── src
         ├── dao
         ├── middlewares
         ├── routes
            ├── route-name
               ├── ${route-name}Routes
               ├── ${route-name}Service
               ├── ${route-name}Validations
               ├── index.ts
            ├── index.ts
         ├── static
         ├── utils
            ├── common.ts
            ├── validations.ts
         ├── views
         ├── index.ts
    └── package.tson
    └── tsconfig.json
    └── .env.api.example
    └── .env.api
    └── README.md

> Use short lowercase names at least for the top-level files and folders except
> `LICENSE`, `README.md`

### Root folders

+ *lib* - holds the whole common libraries
+ *src* - holds the whole express code structure

### lib folder

+ *dto* - holds the common dto wrapper
+ *i18n* - holds the localization logic & language files

### src.* server folder

+ *dao* - holds database queries
+ *middlewares* - holds express middlewares for processing http requests
+ *routes* - holds express routes
+ *static* - holds static files i.e. CSS, Javascript or images
+ *utils* - contains common utils
+ *views* - contains html views developed with template engine EJS
+ *index.ts* - main entry point for server i.e. express server file