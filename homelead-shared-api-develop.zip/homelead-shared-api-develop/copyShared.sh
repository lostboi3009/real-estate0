#!/bin/bash

TARGET_DIR="/Users/mac/Girish/Projects/HomeLead/homelead-auth-api/node_modules//homelead-shared-api"
RUN_NPM_COMMANDS=true
REMOVE_EXISTING_DIR=true

FILES_TO_COPY=(
  ".eslintignore"
  ".eslintrc"
  ".gitignore"
  ".npmrc"
  ".prettierignore"
  ".prettierrc"
  "README.md"
  "package.json"
  "src"
  "tsconfig.json"
  "webStorm.config.js"
)

if [ "$REMOVE_EXISTING_DIR" = true ]; then

  if [ -d "$TARGET_DIR" ]; then
    echo "Removing existing directory: $TARGET_DIR"
    rm -rf "$TARGET_DIR"
  fi
fi

mkdir -p "$TARGET_DIR"

for item in "${FILES_TO_COPY[@]}"; do
  if [ -e "$item" ]; then
    cp -r "$item" "$TARGET_DIR"
    echo "Copied $item to $TARGET_DIR"
  else
    echo "Warning: $item does not exist and was not copied."
  fi
done

if [ "$RUN_NPM_COMMANDS" = true ]; then
  cd "$TARGET_DIR" || exit
  npm install
  npm run build
else
  echo "Skipping npm install and build as RUN_NPM_COMMANDS is set to false."
fi