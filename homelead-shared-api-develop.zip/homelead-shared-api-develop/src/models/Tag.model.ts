import { model, Schema } from 'mongoose';
import { ITagDoc, ITagModel, ObjectId } from '@schemas';
import { Status } from '@enums';

const TagSchema = new Schema<ITagDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        description: {
            type: String,
            trim: true,
            required: true,
        },
        icon: {
            type: String,
            trim: true,
            required: true,
        },
        leadCount: {
            type: Number,
            default: 0,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Tag = model<ITagDoc, ITagModel>('Tag', TagSchema, 'tags');
