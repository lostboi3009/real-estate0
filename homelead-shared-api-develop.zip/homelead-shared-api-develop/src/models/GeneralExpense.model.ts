import { model, Schema } from 'mongoose';
import { IGeneralExpenseDoc, IGeneralExpenseModel, ObjectId } from '@schemas';
import { ExpenseType, PaymentMode, Status } from '@enums';

const GeneralExpenseSchema = new Schema<IGeneralExpenseDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        payeeName: {
            type: String,
            trim: true,
            required: true,
        },
        expenseType: {
            type: String,
            enum: ExpenseType,
            required: true,
        },
        amount: {
            type: Number,
            required: true,
        },
        taxes: {
            type: Number,
            required: true,
        },
        payableAmount: {
            type: Number,
            required: true,
        },
        paymentMode: {
            type: String,
            enum: PaymentMode,
            required: true,
        },
        referenceNo: {
            type: String,
            trim: true,
        },
        remarks: {
            type: String,
            trim: true,
        },
        dateOfPayment: {
            type: Date,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const GeneralExpense = model<IGeneralExpenseDoc, IGeneralExpenseModel>(
    'GeneralExpense',
    GeneralExpenseSchema,
    'general-expenses'
);
