import { model, Schema } from 'mongoose';
import { BankAccountType, Status } from '@enums';
import { IBrokerDoc, IBrokerModel, ObjectId } from '@schemas';

const BrokerSchema = new Schema<IBrokerDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        countryCode: {
            type: String,
            trim: true,
            required: true,
        },
        phone: {
            type: String,
            trim: true,
            required: true,
        },
        country: {
            type: ObjectId,
            ref: 'Country',
            required: true,
        },
        city: {
            type: ObjectId,
            required: true,
        },
        state: {
            type: ObjectId,
            required: true,
        },
        address: {
            type: String,
            trim: true,
            required: true,
        },
        zipCode: {
            type: String,
            trim: true,
            required: true,
        },
        aadharNo: {
            type: String,
            trim: true,
            required: true,
        },
        panNo: {
            type: String,
            trim: true,
            required: true,
        },
        bankDetails: {
            bankNameId: {
                _id: {
                    type: ObjectId,
                    ref: 'BankName',
                    required: true,
                },
                name: {
                    type: String,
                    trim: true,
                    required: true,
                },
                icon: {
                    type: String,
                    trim: true,
                },
            },
            bankAccountType: {
                type: String,
                enum: Object.values(BankAccountType),
                required: true,
            },
            accountNo: {
                type: String,
                trim: true,
                required: true,
            },
            ifscCode: {
                type: String,
                trim: true,
                required: true,
            },
            swiftCode: {
                type: String,
                trim: true,
                required: true,
            },
        },
        realEstateLicenseDetails: {
            licenseNo: {
                type: String,
                trim: true,
            },
            licenseIssueDate: {
                type: Date,
            },
            licenseExpirationDate: {
                type: Date,
            },
        },
        yearStartedInRealEstate: {
            type: Number,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Broker = model<IBrokerDoc, IBrokerModel>('Broker', BrokerSchema, 'brokers');
