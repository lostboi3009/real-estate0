import { model, Schema } from 'mongoose';
import { IProjectCategoryDoc, IProjectCategoryModel } from '@schemas';
import { Status } from '@enums';

const ProjectCategorySchema = new Schema<IProjectCategoryDoc>(
    {
        name: {
            type: String,
            trim: true,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const ProjectCategory = model<IProjectCategoryDoc, IProjectCategoryModel>(
    'ProjectCategory',
    ProjectCategorySchema,
    'project-categories'
);
