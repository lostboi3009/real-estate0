import { model, Schema } from 'mongoose';
import { ICounterDoc, ICounterModel } from '@schemas';

const CounterSchema = new Schema<ICounterDoc>(
    {
        counts: {
            lead: { type: Number, required: true, default: 0 },
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Counter = model<ICounterDoc, ICounterModel>('Counter', CounterSchema, 'counters');
