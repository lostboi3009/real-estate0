import { model, Schema } from 'mongoose';
import { ILeadDoc, ILeadModel, ObjectId } from '@schemas';
import { BuyingTimeLine, LeadStatus, PropertyType, SourceType, Status } from '@enums';

const LeadSchema = new Schema<ILeadDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        leadNo: {
            type: String,
            trim: true,
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        countryCode: {
            type: String,
            trim: true,
            required: true,
        },
        phone: {
            type: String,
            trim: true,
            required: true,
        },
        secondaryCountryCode: {
            type: String,
            trim: true,
        },
        secondaryPhone: {
            type: String,
            trim: true,
        },
        email: {
            type: String,
            trim: true,
            lowercase: true,
        },
        whatsAppCountryCode: {
            type: String,
            trim: true,
        },
        whatsAppNumber: {
            type: String,
            trim: true,
        },
        sourceType: {
            type: String,
            enum: Object.values(SourceType),
            required: true,
        },
        project: {
            type: ObjectId,
            ref: 'Project',
        },
        broker: {
            type: ObjectId,
            ref: 'Broker',
        },
        commissionPercent: {
            type: Number,
        },
        propertyType: {
            type: String,
            enum: Object.values(PropertyType),
        },
        bhk: {
            type: ObjectId,
            ref: 'BHK',
        },
        bhkType: {
            type: ObjectId,
            ref: 'BhkType',
        },
        financialQualification: {
            type: String,
            trim: true,
        },
        minBudget: {
            type: Number,
            default: 0,
        },
        maxBudget: {
            type: Number,
            default: 0,
        },
        buyingTimeline: {
            type: String,
            enum: Object.values(BuyingTimeLine),
            default: BuyingTimeLine.THREE_MONTH,
        },
        otherRequirements: {
            type: String,
            trim: true,
        },
        leadStatus: {
            type: String,
            enum: Object.values(LeadStatus),
            default: LeadStatus.ON_GOING,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Lead = model<ILeadDoc, ILeadModel>('Lead', LeadSchema, 'leads');
