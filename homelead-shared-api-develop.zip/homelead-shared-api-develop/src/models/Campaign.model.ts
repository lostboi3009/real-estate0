import { model, Schema } from 'mongoose';
import { ICampaignModel, ICampaignDoc, ObjectId } from '@schemas';
import { CampaignRoute, CampaignStatus, CampaignType, CampaignService, Status } from '@enums';

const CampaignSchema = new Schema<ICampaignDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        campaignType: {
            type: String,
            enum: Object.values(CampaignType),
            required: true,
        },
        service: {
            type: String,
            enum: Object.values(CampaignService),
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        route: {
            type: String,
            enum: Object.values(CampaignRoute),
            required: true,
        },
        targets: [
            {
                type: ObjectId,
                ref: 'Contact',
                required: true,
            },
        ],
        template: {
            type: ObjectId,
            ref: 'CampaignTemplate',
            required: true,
        },
        subject: {
            type: String,
            trim: true,
        },
        message: {
            type: String,
            trim: true,
            required: true,
        },
        scheduleTime: {
            type: Date,
        },
        campaignStatus: {
            type: String,
            enum: Object.values(CampaignStatus),
            default: CampaignStatus.PENDING,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Campaign = model<ICampaignDoc, ICampaignModel>('Campaign', CampaignSchema, 'campaigns');
