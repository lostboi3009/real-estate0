import { model, Schema } from 'mongoose';
import { ISettingDoc, ISettingModel, ObjectId } from '@schemas';
import { LeadCallToTrack, OTPReceiver, OtpReceiverChannel, WaterMarkPosition } from '@enums';

const SettingSchema = new Schema<ISettingDoc>(
    {
        company: { type: ObjectId, ref: 'Company', required: true },
        general: {
            hasInternationalSupport: { type: Boolean, default: false },
            hasCallDetectionActivated: { type: Boolean, default: false },
            hasCallDetectionForAllLead: {
                type: String,
                enum: Object.values(LeadCallToTrack),
                default: LeadCallToTrack.ALL,
            },
            currency: [
                {
                    _id: { type: ObjectId, ref: 'Country', required: true },
                    name: { type: String, trim: true, required: true },
                    symbol: { type: String, trim: true, required: true },
                    isDefault: { type: Boolean, required: true },
                },
            ],
            countryCode: { type: ObjectId, ref: 'Country' },
            isWaterMarksOnImagesEnabled: { type: Boolean, default: false },
            waterMarkImage: { type: String, trim: true },
            waterMarkPosition: {
                type: String,
                enum: Object.values(WaterMarkPosition),
            },
            opacity: { type: Number },
            imageHeight: { type: String, trim: true },
            imageWidth: { type: String, trim: true },
            tempRentBookingPeriod: { type: Number },
            tempPropertyBookingPeriod: { type: Number },
        },
        security: {
            isTwoFactorAuthenticationEnabled: { type: Boolean, default: false },
            isCopyPasteEnabled: { type: Boolean, default: false },
            isScreenshotEnabled: { type: Boolean, default: false },
            otpSettings: {
                channels: [{ type: String, enum: Object.values(OtpReceiverChannel) }],
                receiver: { type: String, enum: Object.values(OTPReceiver) },
                receiverUserIds: [{ type: ObjectId, ref: 'User' }],
                isEnabledForAll: { type: Boolean },
                userIdsToEnableMFA: [{ type: ObjectId, ref: 'User' }],
            },
        },
        attendance: {
            isShiftTimingFeatureEnabled: { type: Boolean, default: false },
            isSelfieMandatoryForClockOut: { type: Boolean, default: false },
            isSelfieMandatoryForClockIn: { type: Boolean, default: false },
            isShiftTimeEnabledForAllDays: { type: Boolean, default: false },
            isEnabledForAllUsers: { type: Boolean, default: false },
            userIds: [{ type: ObjectId, ref: 'User' }],
            shiftTimingDayWise: [
                {
                    isEnabled: { type: Boolean },
                    day: { type: Number },
                    shiftStartTime: { type: String, trim: true },
                    shiftEndTime: { type: String, trim: true },
                },
            ],
        },
        leads: {
            isLeadsExportEnabled: { type: Boolean, default: false },
            isLeadSourceEditable: { type: Boolean, default: false },
            isDuelLeadOwnershipEnabled: { type: Boolean, default: false },
            isLeadContactInfoMask: { type: Boolean, default: false },
            leadNotes: {
                isNotesMandatoryEnabled: { type: Boolean, default: false },
                isNotesMandatoryOnAddLead: { type: Boolean, default: false },
                isNotesMandatoryOnUpdateLead: { type: Boolean, default: false },
                isNotesMandatoryOnMeetingDone: { type: Boolean, default: false },
                isNotesMandatoryOnSiteVisitDone: { type: Boolean, default: false },
            },
            leadRotation: {
                team: { type: ObjectId, ref: 'Team' },
                users: [{ type: ObjectId, ref: 'User' }],
                teamLead: { type: ObjectId, ref: 'User' },
                shiftTimeFrom: { type: String, trim: true },
                shiftTimeTo: { type: String, trim: true },
                rotationTime: { type: Number },
                noOfRotation: { type: Number },
            },
            manageSubStatus: { type: Object },
            assignmentSetPriority: [
                {
                    priorityName: { type: String, trim: true },
                    priorityValue: { type: String, trim: true },
                },
            ],
        },
        documentAndPriorities: [
            {
                docType: { type: String, trim: true },
                templateName: { type: String, trim: true },
                priority: { type: Number },
                paymentTerm: { type: String, trim: true },
                isMandatory: { type: Boolean },
                documentFormat: { type: String, trim: true },
                isActive: { type: Boolean },
            },
        ],
        isPropertyExportEnabled: { type: Boolean, default: false },
        isProjectExportEnabled: { type: Boolean, default: false },
        isLandExportEnabled: { type: Boolean, default: false },
        credentials: {
            instagram: {
                accountId: { type: Number },
                accessToken: { type: String, trim: true },
            },
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Setting = model<ISettingDoc, ISettingModel>('Setting', SettingSchema, 'settings');
