import { model, Schema } from 'mongoose';
import { IPermissionDoc, IPermissionModel } from '@schemas';
import { Status } from '@enums';

const PermissionSchema = new Schema<IPermissionDoc>(
    {
        name: {
            type: String,
            trim: true,
            required: true,
        },
        slug: {
            type: String,
            trim: true,
            required: true,
        },
        actions: [
            {
                name: {
                    type: String,
                    trim: true,
                    required: true,
                },
                slug: {
                    type: String,
                    trim: true,
                    required: true,
                },
            },
        ],
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Permission = model<IPermissionDoc, IPermissionModel>('Permission', PermissionSchema, 'permissions');
