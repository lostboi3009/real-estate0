import { model, Schema } from 'mongoose';
import { IBankDoc, IBankModel, ObjectId } from '@schemas';
import { Status } from '@enums';

const BankSchema = new Schema<IBankDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        bankNameId: {
            _id: {
                type: ObjectId,
                ref: 'BankName',
                required: true,
            },
            name: {
                type: String,
                trim: true,
                required: true,
            },
            icon: {
                type: String,
                trim: true,
            },
        },
        branchName: {
            type: String,
            trim: true,
            required: true,
        },
        branchAddress: {
            type: String,
            trim: true,
            required: true,
        },
        ifscCode: {
            type: String,
            trim: true,
            required: true,
        },
        swiftCode: {
            type: String,
            trim: true,
            required: true,
        },
        contactPersonDetails: {
            fullName: {
                type: String,
                trim: true,
                required: true,
            },
            countryCode: {
                type: String,
                trim: true,
                required: true,
            },
            phone: {
                type: String,
                trim: true,
                required: true,
            },
            designation: {
                type: String,
                trim: true,
                required: true,
            },
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Bank = model<IBankDoc, IBankModel>('Bank', BankSchema, 'banks');
