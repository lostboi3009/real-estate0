import { model, Schema } from 'mongoose';
import { IBhkDoc, IBhkModel } from '@schemas';
import { Status } from '@enums';

const BhkSchema = new Schema<IBhkDoc>(
    {
        name: {
            type: String,
            trim: true,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Bhk = model<IBhkDoc, IBhkModel>('Bhk', BhkSchema, 'bhk');
