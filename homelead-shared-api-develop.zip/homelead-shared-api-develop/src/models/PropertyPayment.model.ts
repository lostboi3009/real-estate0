import { model, Schema } from 'mongoose';
import { IPropertyPaymentDoc, IPropertyPaymentModel, ObjectId } from '@schemas';
import {
    PaymentMode,
    PropertyFinanceDeptStatus,
    PropertyPaymentDueFrom,
    PropertyPaymentStatus,
    PropertyPaymentType,
    TransactionType,
} from '@enums';

const PropertyPaymentSchema = new Schema<IPropertyPaymentDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        project: {
            type: ObjectId,
            ref: 'Project',
            required: true,
        },
        property: {
            type: ObjectId,
            ref: 'Property',
            required: true,
        },
        booking: {
            type: ObjectId,
            ref: 'PropertyBooking',
            required: true,
        },
        paymentType: {
            type: String,
            enum: Object.values(PropertyPaymentType),
            required: true,
        },
        transactionType: {
            type: String,
            enum: Object.values(TransactionType),
            required: true,
        },
        dueFrom: {
            type: String,
            enum: Object.values(PropertyPaymentDueFrom),
        },
        amount: {
            type: Number,
            required: true,
        },
        paymentStatus: {
            type: String,
            enum: Object.values(PropertyPaymentStatus),
            default: PropertyPaymentStatus.DUE,
        },
        financeDeptStatus: {
            type: String,
            enum: Object.values(PropertyFinanceDeptStatus),
            default: PropertyFinanceDeptStatus.PENDING,
        },
        paymentMode: {
            type: String,
            enum: Object.values(PaymentMode),
            required: true,
        },
        ordinal: {
            type: Number,
        },
        referenceNo: {
            type: String,
            trim: true,
        },
        remarks: {
            type: String,
            trim: true,
        },
        dueDate: {
            type: Date,
        },
        receivedOn: {
            type: Date,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const PropertyPayment = model<IPropertyPaymentDoc, IPropertyPaymentModel>(
    'PropertyPayment',
    PropertyPaymentSchema,
    'property-payments'
);
