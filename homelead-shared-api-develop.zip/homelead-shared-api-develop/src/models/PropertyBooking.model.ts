import { model, Schema } from 'mongoose';
import {
    PropertyBookingType,
    PropertyBookingExtraCharges,
    PropertyBookingPaymentTerm,
    Status,
    PropertyBookingPaymentStatus,
    PropertyFinanceDeptStatus,
    ClpStatus,
    ClpContributor,
    PropertyPaymentStatus,
    PropertyType,
    DocumentTemplateName,
    DocumentType,
} from '@enums';
import { IPropertyBookingDoc, IPropertyBookingModel, ObjectId } from '@schemas';

const PropertyBookingSchema = new Schema<IPropertyBookingDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        lead: {
            type: ObjectId,
            ref: 'Lead',
            required: true,
        },
        project: {
            type: ObjectId,
            ref: 'Project',
            required: true,
        },
        property: {
            type: ObjectId,
            ref: 'Property',
            required: true,
        },
        bookingDate: {
            type: Date,
            required: true,
        },
        panNumber: {
            type: String,
            trim: true,
            required: true,
        },
        aadharNumber: {
            type: String,
            trim: true,
            required: true,
        },
        documents: [
            {
                title: {
                    type: String,
                    trim: true,
                    required: true,
                },
                document: {
                    type: String,
                    trim: true,
                    required: true,
                },
            },
        ],
        bookingType: {
            type: String,
            enum: Object.values(PropertyBookingType),
            required: true,
        },
        saleablePrice: {
            type: Number,
        },
        bookingAmount: {
            type: Number,
        },
        bookingPaymentStatus: {
            type: String,
            enum: Object.values(PropertyBookingPaymentStatus),
            default: PropertyBookingPaymentStatus.DUE,
        },
        basicPrice: {
            type: Number,
        },
        taxPercent: {
            type: Number,
        },
        taxAmount: {
            type: Number,
        },
        extraCharges: [
            {
                chargeFor: {
                    type: String,
                    enum: Object.values(PropertyBookingExtraCharges),
                },
                amount: {
                    type: Number,
                },
            },
        ],
        paymentTerm: {
            type: String,
            enum: Object.values(PropertyBookingPaymentTerm),
        },
        financeDeptStatus: {
            type: String,
            enum: Object.values(PropertyFinanceDeptStatus),
            default: PropertyFinanceDeptStatus.PENDING,
        },
        refundAmount: {
            type: Number,
        },
        clpPhases: [
            {
                name: { type: String, trim: true },
                percentage: { type: Number },
                ordinal: { type: Number },
                status: {
                    type: String,
                    enum: Object.values(ClpStatus),
                },
                bankAmount: { type: Number },
                bankAmountReceived: { type: Number },
                bankPaymentStatus: {
                    type: String,
                    enum: Object.values(PropertyPaymentStatus),
                },
                customerAmount: { type: Number },
                customerAmountReceived: { type: Number },
                customerPaymentStatus: {
                    type: String,
                    enum: Object.values(PropertyPaymentStatus),
                },
            },
        ],
        contributor: {
            type: String,
            enum: Object.values(ClpContributor),
        },
        sanctionLetter: {
            type: String,
            trim: true,
        },
        timelineDocuments: [
            {
                propertyType: {
                    type: String,
                    enum: Object.values(PropertyType),
                },
                templateName: {
                    type: String,
                    enum: Object.values(DocumentTemplateName),
                },
                documentType: {
                    type: String,
                    enum: Object.values(DocumentType),
                },
                priority: {
                    type: Number,
                },
                document: {
                    type: String,
                    trim: true,
                },
            },
        ],
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const PropertyBooking = model<IPropertyBookingDoc, IPropertyBookingModel>(
    'PropertyBooking',
    PropertyBookingSchema,
    'property-bookings'
);
