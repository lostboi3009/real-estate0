import { model, Schema } from 'mongoose';
import { ITeamDoc, ITeamModel, ObjectId } from '@schemas';
import { Status } from '@enums';

const TeamSchema = new Schema<ITeamDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        groups: [{ type: ObjectId, ref: 'Group' }],
        members: [
            {
                type: ObjectId,
                ref: 'User',
                required: true,
            },
        ],
        teamLead: {
            type: ObjectId,
            ref: 'User',
            required: true,
        },
        defaultPrimary: {
            type: ObjectId,
            ref: 'User',
            required: true,
        },
        defaultSecondary: {
            type: ObjectId,
            ref: 'User',
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Team = model<ITeamDoc, ITeamModel>('Team', TeamSchema, 'teams');
