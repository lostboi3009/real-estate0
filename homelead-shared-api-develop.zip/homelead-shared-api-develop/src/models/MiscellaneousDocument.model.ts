import { model, Schema } from 'mongoose';
import { IMiscellaneousDocumentDoc, IMiscellaneousDocumentModel, ObjectId } from '@schemas';
import { Status } from '@enums';

const MiscellaneousDocumentSchema = new Schema<IMiscellaneousDocumentDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        project: {
            type: ObjectId,
            ref: 'Project',
            required: true,
        },
        property: {
            type: ObjectId,
            ref: 'Property',
            required: true,
        },
        booking: {
            type: ObjectId,
            ref: 'PropertyBooking',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        url: {
            type: String,
            trim: true,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const MiscellaneousDocument = model<IMiscellaneousDocumentDoc, IMiscellaneousDocumentModel>(
    'MiscellaneousDocument',
    MiscellaneousDocumentSchema,
    'miscellaneous-documents'
);
