import { model, Schema } from 'mongoose';
import { ISubscriptionPaymentDoc, ISubscriptionPaymentModel, ObjectId } from '@schemas';
import { PaymentMode, SubscriptionPaymentStatus } from '@enums';

const SubscriptionPaymentSchema = new Schema<ISubscriptionPaymentDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        plan: {
            type: ObjectId,
            ref: 'Plan',
            required: true,
        },
        startDate: {
            type: Date,
            required: true,
        },
        endDate: {
            type: Date,
            required: true,
        },
        amount: {
            type: Number,
            required: true,
        },
        paymentStatus: {
            type: String,
            enum: Object.values(SubscriptionPaymentStatus),
            default: SubscriptionPaymentStatus.DUE,
        },
        paymentMode: {
            type: String,
            enum: Object.values(PaymentMode),
            required: true,
        },
        referenceNo: {
            type: String,
            trim: true,
        },
        remarks: {
            type: String,
            trim: true,
        },
        dueDate: {
            type: Date,
        },
        receivedOn: {
            type: Date,
        },
        paymentInfo: [{ type: Object }],
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const SubscriptionPayment = model<ISubscriptionPaymentDoc, ISubscriptionPaymentModel>(
    'SubscriptionPayment',
    SubscriptionPaymentSchema,
    'subscription-payments'
);
