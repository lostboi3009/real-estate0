import { model, Schema } from 'mongoose';
import { IContactModel, IContactDoc, ObjectId } from '@schemas';
import { Status, CampaignUserType } from '@enums';

const ContactSchema = new Schema<IContactDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        phone: {
            type: String,
            trim: true,
        },
        address: {
            type: String,
            trim: true,
        },
        campaignUserType: {
            type: String,
            enum: Object.values(CampaignUserType),
            default: CampaignUserType.USER,
        },
        countryCode: {
            type: String,
            trim: true,
        },
        email: {
            type: String,
            trim: true,
            lowercase: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Contact = model<IContactDoc, IContactModel>('Contact', ContactSchema, 'contacts');
