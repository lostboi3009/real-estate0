import { model, Schema } from 'mongoose';
import { IEmailTrackModel, IEmailTrackDoc, ObjectId } from '@schemas';
import { EmailStatus } from '@enums';

const EmailTrackSchema = new Schema<IEmailTrackDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        campaign: {
            type: ObjectId,
            ref: 'Campaign',
            required: true,
        },
        email: {
            type: String,
            required: true,
            trim: true,
            lowercase: true,
        },
        target: {
            type: ObjectId,
            ref: 'Contact',
            required: true,
        },
        subject: {
            type: String,
            trim: true,
            required: true,
        },
        message: {
            type: String,
            trim: true,
            required: true,
        },
        emailStatus: {
            type: String,
            enum: Object.values(EmailStatus),
            default: EmailStatus.PENDING,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const EmailTrack = model<IEmailTrackDoc, IEmailTrackModel>('EmailTrack', EmailTrackSchema, 'email-track');
