import { model, Schema } from 'mongoose';
import { IBrokerPaymentDoc, IBrokerPaymentModel, ObjectId } from '@schemas';
import { PaymentMode, BrokerPaymentStatus } from '@enums';

const BrokerPaymentSchema = new Schema<IBrokerPaymentDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        project: {
            type: ObjectId,
            ref: 'Project',
            required: true,
        },
        property: {
            type: ObjectId,
            ref: 'Property',
            required: true,
        },
        booking: {
            type: ObjectId,
            ref: 'PropertyBooking',
            required: true,
        },
        broker: {
            type: ObjectId,
            ref: 'Broker',
            required: true,
        },
        amount: {
            type: Number,
            required: true,
        },
        paymentStatus: {
            type: String,
            enum: Object.values(BrokerPaymentStatus),
            default: BrokerPaymentStatus.DUE,
        },
        paymentMode: {
            type: String,
            enum: Object.values(PaymentMode),
            required: true,
        },
        referenceNo: {
            type: String,
            trim: true,
        },
        remarks: {
            type: String,
            trim: true,
        },
        dueDate: {
            type: Date,
        },
        receivedOn: {
            type: Date,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const BrokerPayment = model<IBrokerPaymentDoc, IBrokerPaymentModel>(
    'BrokerPayment',
    BrokerPaymentSchema,
    'broker-payments'
);
