import { model, Schema } from 'mongoose';
import { IBankNameDoc, IBankNameModel } from '@schemas';
import { Status } from '@enums';

const BankNameSchema = new Schema<IBankNameDoc>(
    {
        name: {
            type: String,
            trim: true,
            required: true,
        },
        icon: {
            type: String,
            trim: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const BankName = model<IBankNameDoc, IBankNameModel>('BankName', BankNameSchema, 'bank-names');
