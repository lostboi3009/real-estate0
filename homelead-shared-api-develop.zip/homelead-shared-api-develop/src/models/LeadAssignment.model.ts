import { model, Schema } from 'mongoose';
import { ILeadAssignmentDoc, ILeadAssignmentModel, ObjectId } from '@schemas';
import { Status } from '@enums';

const LeadAssignmentSchema = new Schema<ILeadAssignmentDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        lead: {
            type: ObjectId,
            ref: 'Lead',
            required: true,
        },
        team: {
            type: ObjectId,
            ref: 'Team',
        },
        assignees: [
            {
                user: {
                    type: ObjectId,
                    ref: 'User',
                    required: true,
                },
                isPrimary: {
                    type: Boolean,
                    default: false,
                },
                isSecondary: {
                    type: Boolean,
                    default: false,
                },
            },
        ],
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const LeadAssignment = model<ILeadAssignmentDoc, ILeadAssignmentModel>(
    'LeadAssignment',
    LeadAssignmentSchema,
    'lead-assignments'
);
