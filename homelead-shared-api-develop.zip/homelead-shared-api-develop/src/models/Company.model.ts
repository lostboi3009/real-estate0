import { AddOnServices, Status } from '@enums';
import { ICompanyDoc, ICompanyModel, ObjectId } from '@schemas';
import { Schema, model } from 'mongoose';

const CompanySchema = new Schema<ICompanyDoc>(
    {
        superAdmin: {
            type: ObjectId,
            ref: 'User',
        },
        clientName: {
            type: String,
            trim: true,
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        address: {
            type: String,
            trim: true,
            required: true,
        },
        country: {
            type: ObjectId,
            ref: 'Country',
            required: true,
        },
        state: {
            type: ObjectId,
            required: true,
        },
        city: {
            type: ObjectId,
            required: true,
        },
        primaryCountryCode: {
            type: String,
            trim: true,
            required: true,
        },
        primaryPhone: {
            type: String,
            trim: true,
            required: true,
        },
        secondaryCountryCode: {
            type: String,
            trim: true,
            required: true,
        },
        secondaryPhone: {
            type: String,
            trim: true,
            required: true,
        },
        primaryEmail: {
            type: String,
            trim: true,
            required: true,
            lowercase: true,
        },
        contactPersonName: {
            type: String,
            trim: true,
        },
        contactPersonCountryCode: {
            type: String,
            trim: true,
        },
        contactPersonPhone: {
            type: String,
            trim: true,
        },
        contactPersonEmail: {
            type: String,
            trim: true,
            lowercase: true,
        },
        plan: {
            type: ObjectId,
            ref: 'Plan',
            required: true,
        },
        addOnServices: [
            {
                type: String,
                enum: AddOnServices,
            },
        ],
        planStartDate: {
            type: Date,
        },
        planEndDate: {
            type: Date,
        },
        maxNoOfUsers: {
            type: Number,
        },
        amountPaid: {
            type: Number,
            required: true,
        },
        subDomain: {
            type: String,
            trim: true,
            required: true,
        },
        totalGeneralExpenes: { type: Number, default: 0 },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Company = model<ICompanyDoc, ICompanyModel>('Company', CompanySchema, 'companies');
