import { model, Schema } from 'mongoose';
import { ILeadNoteDoc, ILeadNoteModel, ObjectId } from '@schemas';
import { CommunicationType, SiteVisitStatus, Status } from '@enums';

const LeadNoteSchema = new Schema<ILeadNoteDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        lead: {
            type: ObjectId,
            ref: 'Lead',
            required: true,
        },
        communicationType: {
            type: String,
            enum: Object.values(CommunicationType),
            required: true,
        },
        meetingDateTime: {
            type: Date,
        },
        siteVisitStatus: {
            type: String,
            enum: Object.values(SiteVisitStatus),
            required: true,
        },
        siteVisitScheduledDate: {
            type: Date,
        },
        nextSiteVisitScheduledDate: {
            type: Date,
        },
        tag: {
            type: ObjectId,
            ref: 'Tag',
        },
        remarks: {
            type: String,
            trim: true,
        },
        callDuration: {
            type: String,
            trim: true,
        },
        fileLink: {
            type: String,
            trim: true,
        },
        receiverPhone: {
            type: String,
            trim: true,
        },
        virtualPhone: {
            type: String,
            trim: true,
        },
        callDate: {
            type: Date,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const LeadNote = model<ILeadNoteDoc, ILeadNoteModel>('LeadNote', LeadNoteSchema, 'lead-notes');
