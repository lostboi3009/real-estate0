import { model, Schema } from 'mongoose';
import { IPropertyDoc, IPropertyModel, ObjectId } from '@schemas';
import { AreaType, Facing, FurnishedStatus, PropertyStatus, PropertyType, Status } from '@enums';

const PropertySchema = new Schema<IPropertyDoc>(
    {
        company: {
            type: ObjectId,
            required: true,
            ref: 'Company',
        },
        project: {
            type: ObjectId,
            required: true,
            ref: 'Project',
        },
        propertyType: {
            type: String,
            enum: Object.values(PropertyType),
            required: true,
        },
        propertyUnitSubType: {
            type: ObjectId,
            ref: 'PropertyUnitSubType',
        },
        bhk: {
            type: ObjectId,
            ref: 'Bhk',
        },
        bhkType: {
            type: ObjectId,
            ref: 'BhkType',
        },
        blockName: {
            type: String,
            trim: true,
            required: true,
        },
        floorName: {
            type: String,
            trim: true,
            required: true,
        },
        series: {
            type: String,
            trim: true,
            required: true,
        },
        flatNo: {
            type: String,
            trim: true,
        },
        shopNo: {
            type: String,
            trim: true,
        },
        furnishedStatus: {
            type: String,
            enum: Object.values(FurnishedStatus),
        },
        minBudget: {
            type: Number,
            required: true,
        },
        maxBudget: {
            type: Number,
            required: true,
        },
        facing: {
            type: String,
            enum: Object.values(Facing),
        },
        vastuCompliant: {
            type: Boolean,
            default: false,
        },
        carpetArea: {
            type: Number,
        },
        builtUpArea: {
            type: Number,
        },
        superBuiltUpArea: {
            type: Number,
        },
        carpetAreaType: {
            type: String,
            enum: Object.values(AreaType),
        },
        builtUpAreaType: {
            type: String,
            enum: Object.values(AreaType),
        },
        superBuiltUpAreaType: {
            type: String,
            enum: Object.values(AreaType),
        },
        noOfBalconies: {
            type: Number,
        },
        noOfBathRooms: {
            type: Number,
        },
        noOfBedRooms: {
            type: Number,
        },
        noOfKitchens: {
            type: Number,
        },
        noOfDrawingRooms: {
            type: Number,
        },
        noOfParkingLots: {
            type: Number,
        },
        images: [
            {
                type: String,
                trim: true,
            },
        ],
        about: {
            type: String,
            trim: true,
        },
        propertyStatus: {
            type: String,
            enum: Object.values(PropertyStatus),
            default: PropertyStatus.AVAILABLE,
        },
        bookingDate: {
            type: Date,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Property = model<IPropertyDoc, IPropertyModel>('Property', PropertySchema, 'properties');
