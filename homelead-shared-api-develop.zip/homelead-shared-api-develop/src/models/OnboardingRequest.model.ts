import { AddOnServices, OnboardingStatus } from '@enums';
import { IOnboardingRequestDoc, IOnboardingRequestModel, ObjectId } from '@schemas';
import { Schema, model } from 'mongoose';

const OnboardingRequestSchema = new Schema<IOnboardingRequestDoc>(
    {
        clientName: {
            type: String,
            trim: true,
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        address: {
            type: String,
            trim: true,
            required: true,
        },
        country: {
            type: ObjectId,
            ref: 'Country',
            required: true,
        },
        state: {
            type: ObjectId,
            required: true,
        },
        city: {
            type: ObjectId,
            required: true,
        },
        primaryCountryCode: {
            type: String,
            trim: true,
            required: true,
        },
        primaryPhone: {
            type: String,
            trim: true,
            required: true,
        },
        secondaryCountryCode: {
            type: String,
            trim: true,
            required: true,
        },
        secondaryPhone: {
            type: String,
            trim: true,
            required: true,
        },
        primaryEmail: {
            type: String,
            trim: true,
            required: true,
            lowercase: true,
        },
        contactPersonName: {
            type: String,
            trim: true,
        },
        contactPersonCountryCode: {
            type: String,
            trim: true,
        },
        contactPersonPhone: {
            type: String,
            trim: true,
        },
        contactPersonEmail: {
            type: String,
            trim: true,
            lowercase: true,
        },
        plan: {
            type: ObjectId,
            ref: 'Plan',
        },
        addOnServices: [
            {
                type: String,
                enum: AddOnServices,
            },
        ],
        maxNoOfUsers: {
            type: Number,
        },
        subDomain: {
            type: String,
            trim: true,
            required: true,
        },
        onboardingStatus: {
            type: String,
            enum: Object.values(OnboardingStatus),
            default: OnboardingStatus.PENDING,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const OnboardingRequest = model<IOnboardingRequestDoc, IOnboardingRequestModel>(
    'OnboardingRequest',
    OnboardingRequestSchema,
    'onboarding-requests'
);
