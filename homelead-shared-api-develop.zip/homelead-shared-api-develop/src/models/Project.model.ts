import { model, Schema } from 'mongoose';
import { BankAccountType, ClpStatus, PropertyType, Status } from '@enums';
import { ProjectStatus } from '@enums';
import { IProjectDoc, IProjectModel, ObjectId } from '@schemas';

const ProjectSchema = new Schema<IProjectDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        land: {
            type: ObjectId,
            ref: 'Land',
            required: true,
        },
        name: { type: String, trim: true, required: true },
        slug: { type: String, trim: true, required: true },
        projectType: [
            {
                type: String,
                enum: Object.values(PropertyType),
                required: true,
            },
        ],
        projectUnitSubType: [
            {
                type: ObjectId,
                ref: 'PropertyUnitSubType',
                required: true,
            },
        ],
        category: { type: ObjectId, ref: 'ProjectCategory', required: true },
        projectStatus: {
            type: String,
            enum: Object.values(ProjectStatus),
            required: true,
        },
        minBudget: { type: Number, required: true },
        maxBudget: { type: Number, required: true },
        startDate: { type: Date, required: true },
        completionDate: { type: Date, required: true },
        countryCode: { type: String, trim: true, required: true },
        phone: { type: String, trim: true, required: true },
        email: { type: String, trim: true, required: true, lowercase: true },
        website: { type: String, trim: true },
        address: { type: String, trim: true, required: true },
        country: { type: ObjectId, ref: 'Country', required: true },
        state: { type: ObjectId, required: true },
        city: { type: ObjectId, required: true },
        zipCode: { type: String, trim: true, required: true },
        coordinates: {
            type: [Number],
        },
        reraRegistrationNumber: { type: String, trim: true, required: true },
        projectRegistrationNumber: { type: String, trim: true, required: true },
        layoutPlanImages: [{ type: String, trim: true }],
        isGovtApproved: { type: Boolean, default: false },
        govtApprovedDocuments: [{ type: String, trim: true }],
        noOfPhaseResidential: { type: Number },
        noOfUnitsResidential: { type: Number },
        propertyUnitSubTypesResidential: [
            {
                type: ObjectId,
                ref: 'PropertyUnitSubType',
            },
        ],
        bhksResidential: [
            {
                type: ObjectId,
                ref: 'Bhk',
            },
        ],
        bhkTypesResidential: [
            {
                type: ObjectId,
                ref: 'BhkType',
            },
        ],
        noOfBlocksResidential: { type: Number },
        blocksResidential: [
            {
                blockName: { type: String, trim: true },
                noOfFloors: { type: Number },
                floors: [
                    {
                        floorName: { type: String, trim: true },
                        series: { type: String, trim: true },
                        unitFrom: { type: String, trim: true },
                        unitTo: { type: String, trim: true },
                        bhk: { type: ObjectId, ref: 'Bhk' },
                    },
                ],
            },
        ],
        noOfPhaseCommercial: { type: Number },
        noOfUnitsCommercial: { type: Number },
        propertyUnitSubTypesCommercial: [
            {
                type: ObjectId,
                ref: 'PropertyUnitSubType',
            },
        ],
        noOfBlocksCommercial: { type: Number },
        blocksCommercial: [
            {
                blockName: { type: String, trim: true },
                noOfFloors: { type: Number },
                floors: [
                    {
                        floorName: { type: String, trim: true },
                        series: { type: String, trim: true },
                        unitFrom: { type: String, trim: true },
                        unitTo: { type: String, trim: true },
                    },
                ],
            },
        ],
        amenities: [
            {
                type: ObjectId,
                ref: 'Amenity',
            },
        ],
        nearByLocations: [
            {
                type: ObjectId,
                ref: 'NearByLocation',
            },
        ],
        images: [{ type: String, trim: true }],
        videos: [{ type: String, trim: true }],
        brochure: [{ type: String, trim: true }],
        qrCode: { type: String, trim: true },
        documents: [
            {
                documentName: { type: String, trim: true },
                document: { type: String, trim: true },
            },
        ],
        promoterDetails: [
            {
                promoterName: { type: String, trim: true },
                promoterCountryCode: { type: String, trim: true },
                promoterPhone: { type: String, trim: true },
            },
        ],
        financerBankDetails: [
            {
                bankNameId: {
                    type: ObjectId,
                    ref: 'BankName',
                },
                accountNo: { type: String, trim: true },
                accountType: { type: String, enum: Object.values(BankAccountType) },
            },
        ],
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
        clpPhases: [
            {
                name: { type: String, trim: true, required: true },
                percentage: { type: Number, required: true },
                ordinal: { type: Number, required: true },
                status: {
                    type: String,
                    enum: Object.values(ClpStatus),
                    default: ClpStatus.PENDING,
                },
            },
        ],
        totalRentRevenue: { type: Number, default: 0 },
        totalRentAmountRequired: { type: Number, default: 0 },
        totalRentedUnits: { type: Number, default: 0 },
        totalSaleRevenue: { type: Number, default: 0 },
        totalSaleAmountRequired: { type: Number, default: 0 },
        totalBookedUnits: { type: Number, default: 0 },
        totalSoldUnits: { type: Number, default: 0 },
        totalBookingCancelled: { type: Number, default: 0 },
        totalRefundedAmount: { type: Number, default: 0 },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Project = model<IProjectDoc, IProjectModel>('Project', ProjectSchema, 'projects');
