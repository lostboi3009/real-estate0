import { model, Schema } from 'mongoose';
import { IDesignationDoc, IDesignationModel } from '@schemas';
import { Status } from '@enums';

const DesignationSchema = new Schema<IDesignationDoc>(
    {
        name: {
            type: String,
            trim: true,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Designation = model<IDesignationDoc, IDesignationModel>('Designation', DesignationSchema, 'designations');
