import { model, Schema } from 'mongoose';
import { ISmsTrackModel, ISmsTrackDoc, ObjectId } from '@schemas';
import { SmsStatus } from '@enums';

const SmsTrackSchema = new Schema<ISmsTrackDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        campaign: {
            type: ObjectId,
            ref: 'Campaign',
            required: true,
        },
        countryCode: {
            type: String,
            required: true,
            trim: true,
        },
        phone: {
            type: String,
            required: true,
            trim: true,
        },
        target: {
            type: ObjectId,
            ref: 'Contact',
            required: true,
        },
        message: {
            type: String,
            trim: true,
            required: true,
        },
        smsStatus: {
            type: String,
            enum: Object.values(SmsStatus),
            default: SmsStatus.PENDING,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const SmsTrack = model<ISmsTrackDoc, ISmsTrackModel>('SmsTrack', SmsTrackSchema, 'sms-track');
