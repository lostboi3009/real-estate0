import { model, Schema } from 'mongoose';
import { ICampaignTemplateModel, ObjectId, ICampaignTemplateDoc } from '@schemas';
import { TemplateType, Status } from '@enums';

const CampaignTemplateSchema = new Schema<ICampaignTemplateDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        templateType: {
            type: String,
            enum: Object.values(TemplateType),
            required: true,
        },
        content: {
            type: String,
            trim: true,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const CampaignTemplate = model<ICampaignTemplateDoc, ICampaignTemplateModel>(
    'CampaignTemplate',
    CampaignTemplateSchema,
    'campaign-templates'
);
