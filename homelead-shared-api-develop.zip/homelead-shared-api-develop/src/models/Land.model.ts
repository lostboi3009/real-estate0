import { model, Schema } from 'mongoose';
import { ILandDoc, ILandModel, ObjectId } from '@schemas';
import { AreaType, OccupancyStatus, PropertyType, Status } from '@enums';

const LandSchema = new Schema<ILandDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        propertyType: [
            {
                type: String,
                enum: Object.values(PropertyType),
                required: true,
            },
        ],
        address: {
            type: String,
            trim: true,
            required: true,
        },
        country: {
            type: ObjectId,
            ref: 'Country',
            required: true,
        },
        state: {
            type: ObjectId,
            required: true,
        },
        city: {
            type: ObjectId,
            required: true,
        },
        zipCode: {
            type: String,
            trim: true,
            required: true,
        },
        coordinates: [
            {
                type: Number,
            },
        ],
        nearByArea: {
            type: String,
            trim: true,
        },
        purchasePrice: {
            type: Number,
            required: true,
        },
        currentMarketValue: {
            type: Number,
            required: true,
        },
        propertyTaxRefNo: {
            type: String,
            trim: true,
        },
        isOnLease: {
            type: Boolean,
            default: false,
        },
        rentalIncome: {
            type: Number,
        },
        occupancyStatus: {
            type: String,
            enum: Object.values(OccupancyStatus),
            default: OccupancyStatus.VACANT,
        },
        leaseAgreementDocs: [
            {
                type: String,
                trim: true,
            },
        ],
        isAnyConstructionExists: {
            type: Boolean,
            default: false,
        },
        plotSize: {
            type: Number,
        },
        sizeType: {
            type: String,
            enum: Object.values(AreaType),
        },
        geoGraphicalDetails: {
            type: String,
            trim: true,
        },
        amenities: [
            {
                type: ObjectId,
                ref: 'Amenity',
            },
        ],
        ownerName: {
            type: String,
            required: true,
        },
        ownerEmail: {
            type: String,
            trim: true,
            lowercase: true,
        },
        ownerCountryCode: {
            type: String,
            trim: true,
            required: true,
        },
        ownerPhone: {
            type: String,
            trim: true,
            required: true,
        },
        pastOwnerName: {
            type: String,
            trim: true,
        },
        pastOwnerCountryCode: {
            type: String,
            trim: true,
        },
        pastOwnerPhone: {
            type: String,
            trim: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Land = model<ILandDoc, ILandModel>('Land', LandSchema, 'lands');
