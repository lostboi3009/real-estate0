import { DocumentType, DocumentPaymentTerm, Status, DocumentTemplateName, PropertyType } from '@enums';
import { IDocumentAndPriorityDoc, IDocumentAndPriorityModel, ObjectId } from '@schemas';

import { model, Schema } from 'mongoose';

const DocumentAndPrioritySchema = new Schema<IDocumentAndPriorityDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        documentType: {
            type: String,
            enum: Object.values(DocumentType),
            required: true,
        },
        templateName: {
            type: String,
            enum: Object.values(DocumentTemplateName),
            required: true,
        },
        priority: {
            type: Number,
            required: true,
        },
        paymentTerm: {
            type: String,
            enum: Object.values(DocumentPaymentTerm),
            required: true,
        },
        isMandatory: {
            type: Boolean,
            required: true,
        },
        document: {
            type: String,
            trim: true,
        },
        propertyType: {
            type: String,
            enum: Object.values(PropertyType),
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const DocumentAndPriority = model<IDocumentAndPriorityDoc, IDocumentAndPriorityModel>(
    'DocumentationAndPriority',
    DocumentAndPrioritySchema,
    'documents-and-priorities'
);
