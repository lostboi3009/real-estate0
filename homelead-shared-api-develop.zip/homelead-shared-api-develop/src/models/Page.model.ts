import { model, Schema } from 'mongoose';
import { IPageDoc, IPageModel } from '@schemas';
import { Status } from '@enums';

const PageSchema = new Schema<IPageDoc>(
    {
        title: {
            type: String,
            trim: true,
            required: true,
        },
        description: {
            type: String,
            trim: true,
            required: true,
        },
        slug: {
            type: String,
            trim: true,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Page = model<IPageDoc, IPageModel>('Page', PageSchema, 'pages');
