import { model, Schema, UpdateQuery } from 'mongoose';
import { compare, hash } from 'bcryptjs';
import { IUserDoc, IUserModel, ObjectId } from '@schemas';
import { Status, UserAccountType } from '@enums';
import { logger } from '@utils';

const UserSchema = new Schema<IUserDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        firstName: {
            type: String,
            trim: true,
            required: true,
        },
        lastName: {
            type: String,
            trim: true,
        },
        fullName: {
            type: String,
            trim: true,
        },
        email: {
            type: String,
            trim: true,
            lowercase: true,
            required: true,
        },
        countryCode: {
            type: String,
            trim: true,
            required: true,
        },
        phone: {
            type: String,
            trim: true,
            required: true,
        },
        formattedPhone: {
            type: String,
            trim: true,
        },
        secondaryCountryCode: {
            type: String,
            trim: true,
        },
        secondaryPhone: {
            type: String,
            trim: true,
        },
        password: {
            type: String,
            trim: true,
            required: true,
        },
        groups: [
            {
                type: ObjectId,
                ref: 'Group',
            },
        ],
        permissions: Object,
        designation: {
            type: ObjectId,
            ref: 'Designation',
        },
        isReportingManager: {
            type: Boolean,
            default: false,
        },
        reportsTo: {
            type: ObjectId,
            ref: 'User',
        },
        accountType: {
            type: String,
            enum: Object.values(UserAccountType),
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
        avatar: {
            type: String,
            trim: true,
        },
        description: {
            type: String,
            trim: true,
        },
        facebookToken: {
            type: String,
            trim: true,
        },
        instagramToken: {
            type: String,
            trim: true,
        },
        failedLoginAttempts: {
            type: Number,
            default: 0,
        },
        preventLoginTill: {
            type: Number,
            default: 0,
        },
        authTokenIssuedAt: {
            type: Number,
            default: 0,
        },
        askForPasswordReset: {
            type: Boolean,
            default: false,
        },
        isFake: {
            type: Boolean,
            default: false,
        },
        MFAToken: {
            type: String,
            trim: true,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

UserSchema.pre<IUserDoc>('save', async function (next) {
    try {
        if (this.isModified('firstName') || this.isModified('lastName')) {
            const getLastName = (lastName: string | undefined): string => (lastName ? ` ${lastName}` : '');
            this.fullName = `${this.firstName}${getLastName(this.lastName)}`;
        }
        if (this.isModified('countryCode') && this.isModified('phone')) {
            this.formattedPhone = `${this.countryCode}-${this.phone}`;
        }
        if (this.password && this.isModified('password')) {
            const saltRounds = Number(process.env.BCRYPT_ITERATIONS || 10);
            this.password = await hash(this.password, saltRounds);
        }
        return next();
    } catch (e) {
        logger.error('User model error in pre save hook', e);
        return next();
    }
});

UserSchema.pre<IUserDoc>('updateOne', async function (next) {
    try {
        const self = this as UpdateQuery<IUserDoc>;
        const firstName = self.getUpdate().$set.firstName;
        const lastName = self.getUpdate().$set.lastName;
        const countryCode = self.getUpdate().$set.countryCode;
        const phone = self.getUpdate().$set.phone;
        const password = self.getUpdate().$set.password;

        if (firstName || lastName) {
            const getLastName = () => (lastName ? ` ${lastName}` : '');
            this.set('fullName', `${firstName}${getLastName()}`);
        }
        if (countryCode && phone) {
            this.set('formattedPhone', `${countryCode}-${phone}`);
        }
        if (password) {
            const saltRounds = Number(process.env.BCRYPT_ITERATIONS || 10);
            const hashedPassword = await hash(password, saltRounds);
            this.set('password', hashedPassword);
        }
        return next();
    } catch (e) {
        logger.error('User model error in pre update hook', e);
        return next();
    }
});

UserSchema.method('comparePassword', async function comparePassword(password: string) {
    try {
        if (!this.password) {
            return false;
        }
        return await compare(password, this.password);
    } catch (e) {
        return false;
    }
});

export const User = model<IUserDoc, IUserModel>('User', UserSchema, 'users');
