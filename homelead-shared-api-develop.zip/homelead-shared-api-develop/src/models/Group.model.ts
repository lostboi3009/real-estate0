import { model, Schema } from 'mongoose';
import { IGroupDoc, IGroupModel, ObjectId } from '@schemas';
import { Status } from '@enums';

const GroupSchema = new Schema<IGroupDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        members: [
            {
                type: ObjectId,
                ref: 'User',
            },
        ],
        permissions: Object,
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Group = model<IGroupDoc, IGroupModel>('Group', GroupSchema, 'groups');
