import { model, Schema } from 'mongoose';
import { IBhkTypeDoc, IBhkTypeModel } from '@schemas';
import { Status } from '@enums';

const BhkTypeSchema = new Schema<IBhkTypeDoc>(
    {
        name: {
            type: String,
            trim: true,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const BhkType = model<IBhkTypeDoc, IBhkTypeModel>('BhkType', BhkTypeSchema, 'bhk-types');
