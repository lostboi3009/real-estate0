import { model, Schema } from 'mongoose';
import { IRentPaymentDoc, IRentPaymentModel, ObjectId } from '@schemas';
import { PaymentMode, RentPaymentStatus } from '@enums';

const RentPaymentSchema = new Schema<IRentPaymentDoc>(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        project: {
            type: ObjectId,
            ref: 'Project',
            required: true,
        },
        property: {
            type: ObjectId,
            ref: 'Property',
            required: true,
        },
        tenant: {
            type: ObjectId,
            ref: 'Tenant',
            required: true,
        },
        startDate: {
            type: Date,
            required: true,
        },
        endDate: {
            type: Date,
            required: true,
        },
        amount: {
            type: Number,
            required: true,
        },
        amountPaid: {
            type: Number,
            default: 0,
        },
        paymentStatus: {
            type: String,
            enum: Object.values(RentPaymentStatus),
            default: RentPaymentStatus.DUE,
        },
        paymentMode: {
            type: String,
            enum: Object.values(PaymentMode),
            required: true,
        },
        referenceNo: {
            type: String,
            trim: true,
        },
        remarks: {
            type: String,
            trim: true,
        },
        receivedOn: {
            type: Date,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const RentPayment = model<IRentPaymentDoc, IRentPaymentModel>('RentPayment', RentPaymentSchema, 'rent-payments');
