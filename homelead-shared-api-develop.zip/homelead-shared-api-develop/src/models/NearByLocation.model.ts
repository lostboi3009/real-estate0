import { Schema, model } from 'mongoose';
import { INearByLocationDoc, INearByLocationModel } from '@schemas';
import { Status } from '@enums';

const NearByLocationSchema = new Schema(
    {
        name: {
            type: String,
            trim: true,
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const NearByLocation = model<INearByLocationDoc, INearByLocationModel>(
    'NearByLocation',
    NearByLocationSchema,
    'near-by-locations'
);
