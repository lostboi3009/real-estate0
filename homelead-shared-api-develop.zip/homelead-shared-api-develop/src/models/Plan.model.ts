import { PaymentDuration, Status } from '@enums';
import { IPlanDoc, IPlanModel } from '@schemas';
import { model, Schema } from 'mongoose';

const PlanModel = new Schema<IPlanDoc>({
    name: {
        type: String,
        required: true,
        trim: true,
    },
    slug: {
        type: String,
        required: true,
        trim: true,
    },
    paymentDuration: {
        type: String,
        enum: Object.values(PaymentDuration),
        required: true,
    },
    price: {
        type: Number,
        required: true,
    },
    description: {
        type: String,
        required: true,
        trim: true,
    },
    features: [
        {
            type: String,
            required: true,
            trim: true,
        },
    ],
    permissions: {
        type: Object,
        required: true,
    },
    status: {
        type: String,
        enum: Object.values(Status),
        default: Status.ACTIVE,
    },
});

export const Plan = model<IPlanDoc, IPlanModel>('Plan', PlanModel, 'plans');
