import { Schema, model } from 'mongoose';
import { ITenantDoc, ITenantModel, ObjectId } from '@schemas';
import { RentBookingType, PaymentMode, Relation, Status, TenantStatus } from '@enums';

const TenantSchema = new Schema(
    {
        company: {
            type: ObjectId,
            ref: 'Company',
            required: true,
        },
        project: {
            type: ObjectId,
            ref: 'Project',
            required: true,
        },
        property: {
            type: ObjectId,
            ref: 'Property',
            required: true,
        },
        name: {
            type: String,
            trim: true,
            required: true,
        },
        countryCode: {
            type: String,
            trim: true,
            required: true,
        },
        phone: {
            type: String,
            trim: true,
            required: true,
        },
        email: {
            type: String,
            trim: true,
            lowercase: true,
        },
        aadharNo: {
            type: String,
            trim: true,
            required: true,
        },
        panNo: {
            type: String,
            trim: true,
            required: true,
        },
        avatar: {
            type: String,
            trim: true,
        },
        totalMember: {
            type: Number,
            required: true,
        },
        members: [
            {
                name: {
                    type: String,
                    trim: true,
                    required: true,
                },
                age: {
                    type: Number,
                    required: true,
                },
                relation: {
                    type: String,
                    enum: Object.values(Relation),
                    required: true,
                },
            },
        ],
        isPets: {
            type: Boolean,
            default: false,
        },
        bookingDate: {
            type: Date,
            required: true,
        },
        bookingType: {
            type: String,
            enum: Object.values(RentBookingType),
            required: true,
        },
        rentAmount: {
            type: Number,
        },
        rentIncrement: {
            type: Number,
        },
        depositAmount: {
            type: Number,
        },
        adjustedDepositAmount: {
            type: Number,
        },
        payableDepositAmount: {
            type: Number,
        },
        isMaintenanceIncluded: {
            type: Boolean,
            default: false,
        },
        isPoliceVerificationDone: {
            type: Boolean,
            default: false,
        },
        rentStartDate: {
            type: Date,
        },
        leavingDate: {
            type: Date,
        },
        rentAgreementStartDate: {
            type: Date,
        },
        rentAgreementEndDate: {
            type: Date,
        },
        rentAgreements: [
            {
                type: String,
                trim: true,
            },
        ],
        dueRentAmount: {
            type: Number,
            default: 0,
        },
        rentPaymentGeneratedOn: {
            type: Date,
        },
        tenantStatus: {
            type: String,
            enum: Object.values(TenantStatus),
            default: TenantStatus.STAYING,
        },
        depositPaymentMode: {
            type: String,
            enum: Object.values(PaymentMode),
        },
        depositReferenceNo: {
            type: String,
            trim: true,
        },
        depositRemarks: {
            type: String,
            trim: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const Tenant = model<ITenantDoc, ITenantModel>('Tenant', TenantSchema, 'tenants');
