import { model, Schema } from 'mongoose';
import { IPropertyUnitSubTypeDoc, IPropertyUnitSubTypeModel } from '@schemas';
import { Status, PropertyType } from '@enums';

const PropertyUnitSubTypeSchema = new Schema<IPropertyUnitSubTypeDoc>(
    {
        name: {
            type: String,
            trim: true,
            required: true,
        },
        projectType: {
            type: String,
            enum: Object.values(PropertyType),
            required: true,
        },
        status: {
            type: String,
            enum: Object.values(Status),
            default: Status.ACTIVE,
        },
    },
    {
        id: false,
        timestamps: true,
        toJSON: {
            getters: true,
        },
        toObject: {
            getters: true,
        },
    }
);

export const PropertyUnitSubType = model<IPropertyUnitSubTypeDoc, IPropertyUnitSubTypeModel>(
    'PropertyUnitSubType',
    PropertyUnitSubTypeSchema,
    'property-unit-sub-types'
);
