export enum CampaignService {
    TWILIO = 'twilio',
}
