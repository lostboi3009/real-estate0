export enum RentPaymentStatus {
    DUE = 'Due',
    PAID = 'Paid',
}
