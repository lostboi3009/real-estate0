export enum AddOnServices {
    SMS = 'Sms',
    EMAIL = 'Email',
    IVR = 'IVR',
}
