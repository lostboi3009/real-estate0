export enum PropertyPaymentType {
    BOOKING_AMOUNT = 'Booking Amount',
    BOOKING_AMOUNT_REFUND = 'Booking Amount Refund',
    CLP_PAYMENT = 'Clp Payment',
}
