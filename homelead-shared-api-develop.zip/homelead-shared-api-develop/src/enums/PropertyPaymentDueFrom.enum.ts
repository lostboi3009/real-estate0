export enum PropertyPaymentDueFrom {
    BANK = 'Bank',
    USER = 'User',
}
