export enum AreaType {
    SQUARE_FEET = 'Square Feet',
    SQUARE_METERS = 'Square Meters',
    ACRES = 'Acres',
    HECTARES = 'Hectares',
    GAJ = 'Gaj',
    SQUARE_YARDS = 'Square Yards',
}
