export enum BuyingTimeLine {
    THREE_MONTH = '0 TO 3 months',
    ZERO_SIX = '0 TO 6 months',
}
