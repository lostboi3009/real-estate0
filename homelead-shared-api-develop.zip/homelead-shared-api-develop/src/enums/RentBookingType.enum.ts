export enum RentBookingType {
    TEMPORARY_BOOKING = 'Temporary Booking',
    FINAL_BOOKING = 'Final Booking',
}
