export enum DocumentType {
    RECEIPT = 'Receipt',
    WELCOME_LETTER = 'Welcome Letter',
    ALLOTMENT_LETTER = 'Allotment Letter',
    AGREEMENT = 'Agreement',
    CUSTOMER_DEMAND = 'Customer Demand',
    BANK_DEMAND = 'Bank Demand',
    CUSTOMER_PAYMENT_RECEIPT = 'Customer Payment Receipt',
    BANK_PAYMENT_RECEIPT = 'Bank Payment Receipt',
    FULL_AND_FINAL = 'Full & Final',
    POSSESSION_LETTER = 'Possession Letter',
    SALE_DEED = 'Sale Deed',
    KEY_HANDOVER = 'Key Handover',
}
