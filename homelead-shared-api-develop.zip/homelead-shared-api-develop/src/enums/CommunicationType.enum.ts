export enum CommunicationType {
    CALL = 'Call',
    WHATSAPP = 'WhatsApp',
    IN_PERSON = 'In Person',
}
