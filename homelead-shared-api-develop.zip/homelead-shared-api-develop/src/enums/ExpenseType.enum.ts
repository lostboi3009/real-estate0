export enum ExpenseType {
    AGAINST_SALARY = 'Against Salary',
}
