export enum Platform {
    android = 'android',
    ios = 'ios',
    web = 'web',
}
