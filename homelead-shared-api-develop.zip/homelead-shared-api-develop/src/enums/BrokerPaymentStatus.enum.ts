export enum BrokerPaymentStatus {
    DUE = 'Due',
    PAID = 'Paid',
}
