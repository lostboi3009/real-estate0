export enum CampaignStatus {
    PENDING = 'Pending',
    IN_PROGRESS = 'In Progress',
    DELIVERED = 'Delivered',
    FAILED = 'Failed',
}
