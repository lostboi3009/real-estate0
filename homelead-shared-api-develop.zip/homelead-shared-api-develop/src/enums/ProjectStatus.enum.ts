export enum ProjectStatus {
    CONSTRUCTION_STARTED = 'Construction started',
    UNDER_CONSTRUCTION = 'Under construction',
    READY_TO_SHIFT = 'Ready to shift',
}
