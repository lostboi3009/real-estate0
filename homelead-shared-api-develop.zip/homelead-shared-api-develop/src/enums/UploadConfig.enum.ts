enum ImageExtensions {
    png = 'png',
    jpeg = 'jpeg',
    jpg = 'jpg',
    svg = 'svg',
    webp = 'webp',
}

enum VideoExtensions {
    mp4 = 'mp4',
    mov = 'mov',
}

enum DocumentExtensions {
    pdf = 'pdf',
    doc = 'doc',
    docx = 'docx',
    csv = 'csv',
}

enum AcceptHeader {
    ImageJPEG = 'image/jpeg',
    ImageJPG = 'image/jpg',
    ImagePNG = 'image/png',
    ImageSVG = 'image/svg',
    ImageWebP = 'image/webp',
    PDF = 'application/pdf',
    Doc = 'application/msword',
    Docx = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    CSV = 'text/csv',
    VideoMP4 = 'video/mp4',
    VideoWebM = 'video/webm',
    VideoAVI = 'video/avi',
    VideoMOV = 'video/mov',
    VideoXM4 = 'video/x-m4v',
}

type FileProperties = {
    LOCATION: string;
    EXTENSIONS: (ImageExtensions | VideoExtensions | DocumentExtensions)[];
    MAX_FILES: number;
    MAX_SIZE: number;
};

const defaultImgSize = 10485760;

const UploadConfig: Record<string, FileProperties> = Object.freeze({
    LAND_IMAGES: {
        LOCATION: 'lands/images',
        EXTENSIONS: [ImageExtensions.png, ImageExtensions.jpeg, ImageExtensions.jpg],
        ACCEPT: [AcceptHeader.ImagePNG, AcceptHeader.ImageJPEG, AcceptHeader.ImageJPG],
        MAX_FILES: 10,
        MAX_SIZE: Number(process.env.MAX_LAND_IMAGES_SIZE || defaultImgSize),
    },
    LAND_LEASE_AGREEMENTS: {
        LOCATION: 'lands/lease-agreements',
        EXTENSIONS: [DocumentExtensions.pdf, ImageExtensions.png, ImageExtensions.jpeg, ImageExtensions.jpg],
        ACCEPT: [AcceptHeader.PDF, AcceptHeader.ImagePNG, AcceptHeader.ImageJPEG, AcceptHeader.ImageJPG],
        MAX_FILES: 10,
        MAX_SIZE: Number(process.env.MAX_LAND_LEASE_AGREEMENTS_SIZE || defaultImgSize),
    },
    AMENITIES_ICONS: {
        LOCATION: 'masters/amenities-icons',
        EXTENSIONS: [ImageExtensions.png, ImageExtensions.jpeg, ImageExtensions.jpg, ImageExtensions.svg],
        ACCEPT: [AcceptHeader.ImagePNG, AcceptHeader.ImageJPEG, AcceptHeader.ImageJPG, AcceptHeader.ImageSVG],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_AMENITIES_ICONS_SIZE || defaultImgSize),
    },
    PROJECT_LAYOUT_PLANS: {
        LOCATION: 'projects/layout-plans',
        EXTENSIONS: [
            ImageExtensions.png,
            ImageExtensions.jpeg,
            ImageExtensions.jpg,
            ImageExtensions.svg,
            DocumentExtensions.pdf,
        ],
        ACCEPT: [
            AcceptHeader.ImagePNG,
            AcceptHeader.ImageJPEG,
            AcceptHeader.ImageJPG,
            AcceptHeader.ImageSVG,
            AcceptHeader.PDF,
        ],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_PROJECT_LAYOUT_PLANS_SIZE || defaultImgSize),
    },
    PROJECT_GOVT_APPROVAL_LETTERS: {
        LOCATION: 'projects/govt-approval-letters',
        EXTENSIONS: [
            ImageExtensions.png,
            ImageExtensions.jpeg,
            ImageExtensions.jpg,
            ImageExtensions.svg,
            DocumentExtensions.pdf,
        ],
        ACCEPT: [
            AcceptHeader.ImagePNG,
            AcceptHeader.ImageJPEG,
            AcceptHeader.ImageJPG,
            AcceptHeader.ImageSVG,
            AcceptHeader.PDF,
        ],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_PROJECT_GOVT_APPROVAL_LETTERS_SIZE || defaultImgSize),
    },
    PROJECT_IMAGES: {
        LOCATION: 'projects/images',
        EXTENSIONS: [ImageExtensions.png, ImageExtensions.jpeg, ImageExtensions.jpg, ImageExtensions.svg],
        ACCEPT: [AcceptHeader.ImagePNG, AcceptHeader.ImageJPEG, AcceptHeader.ImageJPG, AcceptHeader.ImageSVG],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_PROJECT_IMAGES_SIZE || defaultImgSize),
    },
    PROJECT_VIDEOS: {
        LOCATION: 'projects/videos',
        EXTENSIONS: [VideoExtensions.mov, VideoExtensions.mp4],
        ACCEPT: [AcceptHeader.VideoMOV, AcceptHeader.VideoMP4],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_PROJECT_VIDEOS_SIZE || defaultImgSize),
    },
    PROJECT_BROCHURES: {
        LOCATION: 'projects/brochures',
        EXTENSIONS: [
            ImageExtensions.png,
            ImageExtensions.jpeg,
            ImageExtensions.jpg,
            ImageExtensions.svg,
            DocumentExtensions.pdf,
        ],
        ACCEPT: [
            AcceptHeader.ImagePNG,
            AcceptHeader.ImageJPEG,
            AcceptHeader.ImageJPG,
            AcceptHeader.ImageSVG,
            AcceptHeader.PDF,
        ],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_PROJECT_BROCHURES_SIZE || defaultImgSize),
    },
    PROPERTY_IMAGES: {
        LOCATION: 'properties/images',
        EXTENSIONS: [ImageExtensions.png, ImageExtensions.jpeg, ImageExtensions.jpg, ImageExtensions.svg],
        ACCEPT: [AcceptHeader.ImagePNG, AcceptHeader.ImageJPEG, AcceptHeader.ImageJPG, AcceptHeader.ImageSVG],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_PROPERTY_IMAGES_SIZE || defaultImgSize),
    },
    WATERMARK_IMAGE: {
        LOCATION: 'settings/watermarks',
        EXTENSIONS: [ImageExtensions.png, ImageExtensions.jpeg, ImageExtensions.jpg, ImageExtensions.svg],
        ACCEPT: [AcceptHeader.ImagePNG, AcceptHeader.ImageJPEG, AcceptHeader.ImageJPG, AcceptHeader.ImageSVG],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_WATERMARK_IMAGE_SIZE || defaultImgSize),
    },
    BOOKING_DOC: {
        LOCATION: 'property-booking/documents',
        EXTENSIONS: [ImageExtensions.png, ImageExtensions.jpeg, ImageExtensions.jpg, DocumentExtensions.pdf],
        ACCEPT: [AcceptHeader.ImagePNG, AcceptHeader.ImageJPEG, AcceptHeader.ImageJPG, AcceptHeader.PDF],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_BOOKING_DOC_SIZE || defaultImgSize),
    },
    PROFILE_IMAGE: {
        LOCATION: 'profile/images',
        EXTENSIONS: [ImageExtensions.png, ImageExtensions.jpeg, ImageExtensions.jpg],
        ACCEPT: [AcceptHeader.ImagePNG, AcceptHeader.ImageJPEG, AcceptHeader.ImageJPG],
        MAX_FILES: 1,
        MAX_SIZE: Number(process.env.MAX_PROFILE_IMAGE_SIZE || defaultImgSize),
    },
});

export { ImageExtensions, VideoExtensions, DocumentExtensions, FileProperties, defaultImgSize, UploadConfig };
