export enum SmsStatus {
    PENDING = 'Pending',
    DELIVERED = 'Delivered',
    FAILED = 'Failed',
}
