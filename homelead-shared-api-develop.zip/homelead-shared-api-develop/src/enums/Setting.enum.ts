export enum OTPReceiver {
    ADMIN = 'Admin',
    REPORTING_MANAGER = 'Reporting Manager',
    SELF = 'Self',
}

export enum LeadCallToTrack {
    ALL = 'All',
    ASSIGNED = 'Assigned',
}

export enum OtpReceiverChannel {
    EMAIL = 'Email',
    SMS = 'Sms',
    WHATSAPP = 'WhatsApp',
}

export enum WaterMarkPosition {
    CENTER = 'Center',
    LEFT_TOP = 'Left Top',
    CENTER_TOP = 'Center Top',
    RIGHT_TOP = 'Right Top',
    CENTER_LEFT = 'Center Left',
    CENTER_RIGHT = 'Center Right',
    BOTTOM_LEFT = 'Bottom Left',
    BOTTOM_CENTER = 'Bottom Center',
    BOTTOM_RIGHT = 'Bottom Right',
}
