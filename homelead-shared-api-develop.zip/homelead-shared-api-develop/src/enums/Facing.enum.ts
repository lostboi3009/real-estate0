export enum Facing {
    EAST = 'East',
    WEST = 'West',
    SOUTH = 'South',
    NORTH = 'North',
    EAST_NORTH = 'East-North',
    WEST_SOUTH = 'West-South',
}
