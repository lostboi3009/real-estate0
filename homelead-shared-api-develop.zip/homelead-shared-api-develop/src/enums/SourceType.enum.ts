export enum SourceType {
    DIRECT = 'Direct',
    BROKER = 'Broker',
    NINETY_NINE_ACRES = '99 Acres',
    MAGIC_BRICKS = 'Magic Bricks',
    HOUSING_COM = 'Housing.com',
    PROPTIGER = 'Proptiger',
    SQUARE_YARD = 'Square Yard',
    IVR = 'IVR',
}
