export enum TenantStatus {
    STAYING = 'Staying',
    TEMP_STAYING = 'Temporary Staying',
    LEFT = 'Left',
}
