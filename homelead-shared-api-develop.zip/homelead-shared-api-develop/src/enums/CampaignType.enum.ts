export enum CampaignType {
    SMS = 'sms',
    EMAIL = 'email',
    WHATSAPP = 'whatsapp',
}
