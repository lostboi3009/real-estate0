export enum OnboardingStatus {
    PENDING = 'Pending',
    ONBOARDED = 'Onboarded',
    REJECT = 'Reject',
}
