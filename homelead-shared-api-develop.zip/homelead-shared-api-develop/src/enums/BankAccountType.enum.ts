export enum BankAccountType {
    CURRENT = 'Current',
    SAVING = 'Saving',
    SALARIED = 'Salaried',
}
