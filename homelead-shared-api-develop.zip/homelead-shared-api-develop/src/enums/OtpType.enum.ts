export enum VerifyType {
    EMAIL = 'EMAIL',
    PHONE = 'PHONE',
    BOTH = 'BOTH',
}

export enum OtpType {
    FORGOT_PASSWORD = 'FORGOT_PASSWORD',
    CHANGE_PHONE = 'CHANGE_PHONE',
    CHANGE_EMAIL = 'CHANGE_EMAIL',
}
