export enum PropertyPaymentStatus {
    DUE = 'Due',
    PAID = 'Paid',
}
