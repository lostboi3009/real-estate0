export enum SiteVisitStatus {
    PENDING = 'Pending',
    SCHEDULED = 'Scheduled',
    VISITED = 'Visited',
}
