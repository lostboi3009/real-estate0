export enum DocumentTemplateName {
    BOOKING_RECEIPT = 'Booking Receipt',
    ALLOTMENT_LETTER = 'Allotment Letter',
    WELCOME_LETTER = 'Welcome Letter',
    AGREEMENT_TO_SALE = 'Agreement to Sale',
    DEMAND_NOTE_UNDER_CONSTRUCTION = 'Demand Note - Under Construction',
    DEMAND_NOTE_READY_TO_SHIFT = 'Demand Note - Ready to Shift',
    PAYMENT_RECEIPT = 'Payment Receipt',
    FULL_AND_FINAL_SETTLEMENT_NOC = 'Full & Final Settlement - NOC',
    OFFER_OF_POSSESSION = 'Offer of Possession',
    REGISTRY_OR_SALE_DEED = 'Registry or Sale Deed',
    FINAL_POSSESSION_LETTER = 'Final Possession Letter',
    OCCUPANCY_CERTIFICATE = 'Occupancy Certificate',
}
