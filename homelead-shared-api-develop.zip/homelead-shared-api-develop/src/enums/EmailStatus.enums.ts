export enum EmailStatus {
    PENDING = 'Pending',
    DELIVERED = 'Delivered',
    FAILED = 'Failed',
}
