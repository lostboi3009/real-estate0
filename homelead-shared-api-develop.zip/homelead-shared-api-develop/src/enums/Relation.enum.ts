export enum Relation {
    MOTHER = 'Mother',
    FATHER = 'Father',
    SISTER = 'Sister',
    BROTHER = 'Brother',
    GRAND_MOTHER = 'Grand Mother',
    GRAND_FAHTER = 'Grand Father',
    AUNT = 'Aunt',
    UNCLE = 'Uncle',
    COUSIN = 'Cousin',
    CHILD = 'Child',
    SPOUSE = 'Spouse',
    SELF = 'Self',
}
