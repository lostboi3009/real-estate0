export enum PaymentMode {
    CASH = 'Cash',
    ONLINE = 'Online',
    CHEQUE = 'Cheque',
}
