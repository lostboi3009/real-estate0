export enum TransactionType {
    CREDIT = 'Credit',
    DEBIT = 'Debit',
}
