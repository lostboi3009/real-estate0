export enum CampaignRoute {
    PROMOTIONAL = 'Promotional',
    TRANSACTIONAL = 'Transactional',
}
