export enum ClpContributor {
    CUSTOMER = 'Customer',
    BANK = 'Bank',
    BOTH = 'Both',
}
