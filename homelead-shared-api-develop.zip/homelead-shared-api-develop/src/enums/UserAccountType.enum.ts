export enum UserAccountType {
    SUPER_ADMIN = 'Super Admin',
    SUB_ADMIN = 'Sub Admin',
    COMPANY_SUPER_ADMIN = 'Company Super Admin',
    COMPANY_SUB_ADMIN = 'Company Sub Admin',
}
