export enum PropertyBookingPaymentTerm {
    LOAN = 'Loan',
    CLP = 'CLP',
    LOAN_AND_CLP = 'Loan & CLP Both',
}
