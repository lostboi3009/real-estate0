export enum PropertyType {
    RESIDENTIAL = 'Residential',
    COMMERCIAL = 'Commercial',
}
