export enum CampaignUserType {
    BROKER = 'Broker',
    USER = 'User',
    AGENT = 'Agent',
}
