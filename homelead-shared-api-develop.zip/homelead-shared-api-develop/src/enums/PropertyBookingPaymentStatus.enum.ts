export enum PropertyBookingPaymentStatus {
    DUE = 'Due',
    PAID = 'Paid',
    REFUNDED = 'Refunded',
}
