export enum OccupancyStatus {
    VACANT = 'Vacant',
    OCCUPIED = 'Occupied',
}
