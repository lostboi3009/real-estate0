export enum FurnishedStatus {
    FURNISHED = 'Furnished',
    SEMI_FURNISHED = 'Semi-Furnished',
    UNFURNISHED = 'Unfurnished',
}
