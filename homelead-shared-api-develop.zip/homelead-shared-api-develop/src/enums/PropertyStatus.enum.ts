export enum PropertyStatus {
    AVAILABLE = 'Available',
    TEMPORARY_BOOKED_FOR_RENT = 'Temporary Booked for Rent',
    ON_RENT = 'On Rent',
    ON_RENT_TEMPORARY_BOOKED = 'On Rent and Temporary Booked',
    TEMPORARY_BOOKED = 'Temporary Booked',
    BOOKED = 'Booked',
    SOLD = 'Sold',
}
