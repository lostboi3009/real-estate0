export enum DocumentPaymentTerm {
    ON_THE_TIME_OF_BOOKING = 'On the time of Booking',
    ONCE_BOOKING_AMOUNT_RECEIVED = 'Once Booking Amount Received',
    ON_EACH_MILESTONE_COMPLETION = 'On Each Milestone Completion',
    ON_PAYMENT_RECEIVED = 'On Payment Received',
    AFTER_FULL_PAYMENT_RECEIVED = 'After Full Payment Received',
}
