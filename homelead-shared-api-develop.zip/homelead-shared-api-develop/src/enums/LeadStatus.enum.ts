export enum LeadStatus {
    ON_GOING = 'On going',
    TEMPORARY_CONVERTED = 'Temporary Converted',
    CONVERTED = 'Converted',
}
