export enum TemplateType {
    SMS = 'Sms',
    EMAIL = 'Email',
}
