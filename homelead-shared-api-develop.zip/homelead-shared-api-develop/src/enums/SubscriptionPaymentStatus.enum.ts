export enum SubscriptionPaymentStatus {
    DUE = 'Due',
    PAID = 'Paid',
}
