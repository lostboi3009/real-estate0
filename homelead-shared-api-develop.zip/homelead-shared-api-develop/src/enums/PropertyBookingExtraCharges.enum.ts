export enum PropertyBookingExtraCharges {
    PARKING = 'Parking',
    COMMON_EXPENSES = 'Common Expenses',
}
