import { Document, Model } from 'mongoose';
import { PaymentMode, SubscriptionPaymentStatus } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ISubscriptionPayment {
    company: TypesObjectId;
    plan: TypesObjectId;
    startDate: Date;
    endDate: Date;
    amount: number;
    paymentStatus: SubscriptionPaymentStatus;
    paymentMode: PaymentMode;
    referenceNo?: string;
    remarks?: string;
    dueDate?: Date;
    receivedOn?: Date;
    paymentInfo?: [];
}

export interface ISubscriptionPaymentDoc extends ISubscriptionPayment, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ISubscriptionPaymentModel = Model<ISubscriptionPaymentDoc>;
