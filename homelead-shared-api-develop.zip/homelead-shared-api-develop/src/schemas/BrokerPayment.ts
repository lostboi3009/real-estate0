import { Document, Model } from 'mongoose';
import { PaymentMode, BrokerPaymentStatus } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IBrokerPayment {
    company: TypesObjectId;
    project: TypesObjectId;
    property: TypesObjectId;
    booking: TypesObjectId;
    broker: TypesObjectId;
    amount: number;
    paymentStatus: BrokerPaymentStatus;
    paymentMode: PaymentMode;
    referenceNo?: string;
    remarks?: string;
    dueDate?: Date;
    receivedOn?: Date;
}

export interface IBrokerPaymentDoc extends IBrokerPayment, Document {
    _id: TypesObjectId;
    createdAt?: Date;
    updatedAt?: Date;
}

export type IBrokerPaymentModel = Model<IBrokerPaymentDoc>;
