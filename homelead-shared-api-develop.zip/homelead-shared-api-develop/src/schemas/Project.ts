import { BankAccountType, Status, PropertyType, ProjectStatus } from '@enums';
import { Document, Model } from 'mongoose';
import { TypesObjectId } from '@schemas';
import { ClpStatus } from '@enums';

export interface IFloor {
    floorName?: string;
    series?: string;
    unitFrom?: string;
    unitTo?: string;
    bhk?: TypesObjectId;
}

export interface IBlockResidential {
    blockName?: string;
    noOfFloors?: number;
    floors?: IFloor[];
}

export interface IBlockCommercial {
    blockName?: string;
    noOfFloors?: number;
    floors?: Omit<IFloor, 'bhk'>[];
}

export interface IPromoters {
    promoterName?: string;
    promoterCountryCode?: string;
    promoterPhone?: string;
}

export interface IDocuments {
    documentName?: string;
    document?: string;
}

export interface IFinancerBankDetails {
    bankNameId?: TypesObjectId;
    accountNo?: string;
    accountType?: BankAccountType;
}
export interface IClpPhases {
    name: string;
    percentage: number;
    ordinal: number;
    status: ClpStatus;
}

export interface IProject {
    company: TypesObjectId;
    land: TypesObjectId;
    name: string;
    slug: string;
    projectType: PropertyType;
    projectUnitSubType: TypesObjectId[];
    category: TypesObjectId;
    projectStatus: ProjectStatus;
    minBudget: number;
    maxBudget: number;
    startDate: Date;
    completionDate: Date;
    countryCode: string;
    phone: string;
    email: string;
    website?: string;
    address: string;
    country: TypesObjectId;
    state: TypesObjectId;
    city: TypesObjectId;
    zipCode: string;
    coordinates?: number[];
    reraRegistrationNumber: string;
    projectRegistrationNumber: string;
    layoutPlanImages?: string[];
    isGovtApproved?: boolean;
    govtApprovedDocuments?: string[];
    noOfPhaseResidential?: number;
    noOfUnitsResidential?: number;
    propertyUnitSubTypesResidential?: TypesObjectId[];
    bhksResidential?: TypesObjectId[];
    bhkTypesResidential?: TypesObjectId[];
    noOfBlocksResidential?: number;
    blocksResidential?: IBlockResidential[];
    noOfPhaseCommercial?: number;
    noOfUnitsCommercial?: number;
    propertyUnitSubTypesCommercial?: TypesObjectId[];
    noOfBlocksCommercial?: number;
    blocksCommercial?: IBlockCommercial[];
    amenities?: TypesObjectId[];
    nearByLocations?: TypesObjectId[];
    images?: string[];
    videos?: string[];
    brochure?: string[];
    qrCode?: string;
    documents?: IDocuments[];
    promoterDetails?: IPromoters[];
    financerBankDetails?: IFinancerBankDetails[];
    status: Status;
    clpPhases: IClpPhases[];
    totalRentRevenue: number;
    totalRentAmountRequired: number;
    totalRentedUnits: number;
    totalSaleRevenue: number;
    totalSaleAmountRequired: number;
    totalBookedUnits: number;
    totalSoldUnits: number;
    totalBookingCancelled: number;
    totalRefundedAmount: number;
}

export interface IProjectDoc extends IProject, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IProjectModel = Model<IProjectDoc>;
