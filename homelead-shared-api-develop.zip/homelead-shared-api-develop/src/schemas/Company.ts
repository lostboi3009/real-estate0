import { AddOnServices, Status } from '@enums';
import { Document, Model } from 'mongoose';
import { TypesObjectId } from '@schemas';

export interface ICompany {
    superAdmin?: TypesObjectId;
    clientName: string;
    name: string;
    address: string;
    country: TypesObjectId;
    state: TypesObjectId;
    city: TypesObjectId;
    primaryCountryCode: string;
    primaryPhone: string;
    secondaryCountryCode: string;
    secondaryPhone: string;
    primaryEmail: string;
    contactPersonName?: string;
    contactPersonCountryCode?: string;
    contactPersonPhone?: string;
    contactPersonEmail?: string;
    plan: TypesObjectId;
    addOnServices?: AddOnServices[];
    planStartDate?: Date;
    planEndDate?: Date;
    maxNoOfUsers?: number;
    amountPaid: number;
    subDomain: string;
    totalGeneralExpenes: number;
    status: Status;
}

export interface ICompanyDoc extends ICompany, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ICompanyModel = Model<ICompanyDoc>;
