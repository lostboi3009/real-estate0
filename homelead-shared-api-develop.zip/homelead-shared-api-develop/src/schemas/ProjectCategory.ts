import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IProjectCategory {
    name: string;
    status: Status;
}

export interface IProjectCategoryDoc extends IProjectCategory, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IProjectCategoryModel = Model<IProjectCategoryDoc>;
