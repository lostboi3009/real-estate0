import { Document, Model } from 'mongoose';
import { Status, UserAccountType } from '@enums';
import { TypesObjectId } from '@schemas';
import { IPermissionData } from './Permission';

export interface IUser {
    company: TypesObjectId;
    firstName: string;
    lastName?: string;
    fullName: string;
    email: string;
    countryCode: string;
    phone: string;
    formattedPhone: string;
    secondaryCountryCode?: string;
    secondaryPhone?: string;
    password: string;
    groups?: TypesObjectId[];
    permissions: IPermissionData;
    designation?: TypesObjectId;
    isReportingManager: boolean;
    reportsTo?: TypesObjectId;
    accountType: UserAccountType;
    status: Status;
    avatar?: string;
    description?: string;
    facebookToken?: string;
    instagramToken?: string;
    failedLoginAttempts: number;
    preventLoginTill: number;
    authTokenIssuedAt: number;
    isFake: boolean;
    askForPasswordReset: boolean;
    MFAToken?: string;
}

export interface IUserDoc extends IUser, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
    comparePassword(password: string): Promise<boolean>;
}

export type IUserModel = Model<IUserDoc>;
