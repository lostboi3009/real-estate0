import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IBhkType {
    name: string;
    status: Status;
}

export interface IBhkTypeDoc extends IBhkType, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IBhkTypeModel = Model<IBhkTypeDoc>;
