import { Document, Model } from 'mongoose';
import { TypesObjectId } from '@schemas';
import {
    PropertyPaymentType,
    PropertyPaymentStatus,
    TransactionType,
    PropertyPaymentDueFrom,
    PaymentMode,
    PropertyFinanceDeptStatus,
} from '@enums';

export interface IPropertyPayment {
    company: TypesObjectId;
    project: TypesObjectId;
    property: TypesObjectId;
    booking: TypesObjectId;
    paymentType: PropertyPaymentType;
    transactionType: TransactionType;
    dueFrom?: PropertyPaymentDueFrom;
    amount: number;
    paymentStatus: PropertyPaymentStatus;
    financeDeptStatus: PropertyFinanceDeptStatus;
    paymentMode: PaymentMode;
    ordinal?: number;
    referenceNo?: string;
    remarks?: string;
    dueDate?: Date;
    receivedOn?: Date;
}

export interface IPropertyPaymentDoc extends IPropertyPayment, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IPropertyPaymentModel = Model<IPropertyPaymentDoc>;
