import { Document, Model } from 'mongoose';
import { EmailStatus } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IEmailTrack {
    company: TypesObjectId;
    campaign: TypesObjectId;
    email: string;
    target: TypesObjectId;
    subject: string;
    message: string;
    emailStatus: EmailStatus;
}

export interface IEmailTrackDoc extends IEmailTrack, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IEmailTrackModel = Model<IEmailTrackDoc>;
