import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IBhk {
    name: string;
    status: Status;
}

export interface IBhkDoc extends IBhk, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IBhkModel = Model<IBhkDoc>;
