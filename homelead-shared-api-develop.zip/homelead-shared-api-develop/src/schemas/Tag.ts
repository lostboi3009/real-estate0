import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ITag {
    company: TypesObjectId;
    name: string;
    description: string;
    icon: string;
    leadCount?: number;
    status: Status;
}

export interface ITagDoc extends ITag, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ITagModel = Model<ITagDoc>;
