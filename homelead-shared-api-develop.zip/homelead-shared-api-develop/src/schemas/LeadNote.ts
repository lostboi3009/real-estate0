import { Document, Model } from 'mongoose';
import { CommunicationType, SiteVisitStatus, Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ILeadNote {
    company: TypesObjectId;
    lead: TypesObjectId;
    communicationType: CommunicationType;
    meetingDateTime?: Date;
    siteVisitStatus: SiteVisitStatus;
    siteVisitScheduledDate?: Date;
    nextSiteVisitScheduledDate?: Date;
    tag?: TypesObjectId;
    remarks?: string;
    callDuration?: string;
    fileLink?: string;
    receiverPhone?: string;
    virtualPhone?: string;
    callDate?: Date;
    status: Status;
}

export interface ILeadNoteDoc extends ILeadNote, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ILeadNoteModel = Model<ILeadNoteDoc>;
