import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IPermissionAction {
    name: string;
    slug: string;
}

export interface IPermission {
    name: string;
    slug: string;
    actions: IPermissionAction[];
    status: Status;
}

export interface IPermissionDoc extends IPermission, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export interface IPermissionData {
    [key: string]: string[];
}

export type IPermissionModel = Model<IPermissionDoc>;
