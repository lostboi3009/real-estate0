import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ILeadAssignee {
    user: TypesObjectId;
    isPrimary: boolean;
    isSecondary: boolean;
}

export interface ILeadAssignment {
    company: TypesObjectId;
    lead: TypesObjectId;
    team?: TypesObjectId;
    assignees: ILeadAssignee[];
    status: Status;
}

export interface ILeadAssignmentDoc extends ILeadAssignment, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ILeadAssignmentModel = Model<ILeadAssignmentDoc>;
