import { Document, Model } from 'mongoose';
import { ExpenseType, PaymentMode, Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IGeneralExpense {
    company: TypesObjectId;
    payeeName: string;
    expenseType: ExpenseType;
    amount: number;
    taxes: number;
    payableAmount: number;
    paymentMode: PaymentMode;
    referenceNo?: string;
    remarks?: string;
    dateOfPayment: Date;
    status: Status;
}

export interface IGeneralExpenseDoc extends IGeneralExpense, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
    comparePassword(password: string): Promise<boolean>;
}

export type IGeneralExpenseModel = Model<IGeneralExpenseDoc>;
