import { Document, Model } from 'mongoose';
import { TypesObjectId } from '@schemas';
import { Status } from '@enums';

export interface IMiscellaneousDocument {
    company: TypesObjectId;
    project: TypesObjectId;
    property: TypesObjectId;
    booking: TypesObjectId;
    name: string;
    url: string;
    status: Status;
}

export interface IMiscellaneousDocumentDoc extends IMiscellaneousDocument, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IMiscellaneousDocumentModel = Model<IMiscellaneousDocumentDoc>;
