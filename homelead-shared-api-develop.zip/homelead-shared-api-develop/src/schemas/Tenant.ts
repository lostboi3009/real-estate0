import { Document, Model } from 'mongoose';
import { RentBookingType, PaymentMode, Status, TenantStatus } from '@enums';
import { TypesObjectId } from '@schemas';
import { Relation } from '@enums/Relation.enum';

export interface ITenantMember {
    name: string;
    age: number;
    relation: Relation;
}

export interface ITenant {
    company: TypesObjectId;
    project: TypesObjectId;
    property: TypesObjectId;
    name: string;
    countryCode: string;
    phone: string;
    email?: string;
    aadharNo: string;
    panNo: string;
    avatar?: string;
    totalMember: number;
    members: ITenantMember[];
    isPets: boolean;
    bookingDate: Date;
    bookingType: RentBookingType;
    rentAmount?: number;
    rentIncrement?: number;
    depositAmount?: number;
    adjustedDepositAmount?: number;
    payableDepositAmount?: number;
    isMaintenanceIncluded: boolean;
    isPoliceVerificationDone: boolean;
    rentStartDate?: Date;
    leavingDate?: Date;
    rentAgreementStartDate?: Date;
    rentAgreementEndDate?: Date;
    rentAgreements?: string[];
    dueRentAmount: number;
    rentPaymentGeneratedOn?: Date;
    tenantStatus: TenantStatus;
    depositPaymentMode?: PaymentMode;
    depositReferenceNo?: string;
    depositRemarks?: string;
    status: Status;
}

export interface ITenantDoc extends ITenant, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ITenantModel = Model<ITenantDoc>;
