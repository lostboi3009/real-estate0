import { Status, PaymentDuration } from '@enums';
import { Document, Model } from 'mongoose';
import { IPermissionData, TypesObjectId } from '@schemas';

export interface IPlan {
    name: string;
    slug: string;
    paymentDuration: PaymentDuration;
    price: number;
    description: string;
    features: string[];
    permissions: IPermissionData;
    status: Status;
}

export interface IPlanDoc extends IPlan, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IPlanModel = Model<IPlanDoc>;
