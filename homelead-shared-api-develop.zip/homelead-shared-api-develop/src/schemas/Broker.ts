import { Document, Model } from 'mongoose';
import { BankAccountType, Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IBroker {
    company: TypesObjectId;
    name: string;
    countryCode: string;
    phone: string;
    country: TypesObjectId;
    city: TypesObjectId;
    state: TypesObjectId;
    address: string;
    zipCode: string;
    aadharNo: string;
    panNo: string;
    bankDetails: {
        bankNameId: {
            _id: TypesObjectId;
            name: string;
            icon?: string;
        };
        bankAccountType: BankAccountType;
        accountNo: number;
        ifscCode: string;
        swiftCode: string;
    };
    realEstateLicenseDetails?: {
        licenseNo?: string;
        licenseIssueDate?: Date;
        licenseExpirationDate?: Date;
    };
    yearStartedInRealEstate?: number;
    status: Status;
}

export interface IBrokerDoc extends IBroker, Document {
    _id: TypesObjectId;
    createdAt?: Date;
    updatedAt?: Date;
}

export type IBrokerModel = Model<IBrokerDoc>;
