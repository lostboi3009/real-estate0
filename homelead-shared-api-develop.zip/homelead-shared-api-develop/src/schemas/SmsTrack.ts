import { Document, Model } from 'mongoose';
import { SmsStatus } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ISmsTrack {
    company: TypesObjectId;
    campaign: TypesObjectId;
    countryCode: string;
    phone: string;
    target: TypesObjectId;
    message: string;
    smsStatus: SmsStatus;
}

export interface ISmsTrackDoc extends ISmsTrack, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ISmsTrackModel = Model<ISmsTrackDoc>;
