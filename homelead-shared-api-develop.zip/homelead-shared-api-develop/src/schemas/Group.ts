import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';
import { IPermissionData } from './Permission';

export interface IGroup {
    company: TypesObjectId;
    name: string;
    members: TypesObjectId[];
    permissions: IPermissionData;
    status: Status;
}

export interface IGroupDoc extends IGroup, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IGroupModel = Model<IGroupDoc>;
