import { Document, Model } from 'mongoose';
import { BuyingTimeLine, LeadStatus, PropertyType, SourceType, Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ILead {
    company: TypesObjectId;
    leadNo: string;
    name: string;
    countryCode: string;
    phone: string;
    secondaryCountryCode?: string;
    secondaryPhone?: string;
    email?: string;
    whatsAppCountryCode?: string;
    whatsAppNumber?: number;
    sourceType: SourceType;
    project?: TypesObjectId;
    broker?: TypesObjectId;
    commissionPercent?: number;
    propertyType?: PropertyType;
    bhk?: TypesObjectId;
    bhkType?: TypesObjectId;
    financialQualification?: string;
    minBudget: number;
    maxBudget: number;
    buyingTimeline: BuyingTimeLine;
    otherRequirements?: string;
    leadStatus: LeadStatus;
    status: Status;
}

export interface ILeadDoc extends ILead, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ILeadModel = Model<ILeadDoc>;
