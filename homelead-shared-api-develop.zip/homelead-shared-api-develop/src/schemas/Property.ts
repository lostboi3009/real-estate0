import { Document, Model } from 'mongoose';
import { AreaType, Facing, FurnishedStatus, PropertyType, PropertyStatus, Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IProperty {
    company: TypesObjectId;
    project: TypesObjectId;
    propertyType: PropertyType;
    propertyUnitSubType?: TypesObjectId;
    bhk?: TypesObjectId;
    bhkType?: TypesObjectId;
    blockName: string;
    floorName: string;
    series: string;
    flatNo?: string;
    shopNo?: string;
    furnishedStatus?: FurnishedStatus;
    minBudget: number;
    maxBudget: number;
    facing?: Facing;
    vastuCompliant: boolean;
    carpetArea?: number;
    builtUpArea?: number;
    superBuiltUpArea?: number;
    carpetAreaType?: AreaType;
    builtUpAreaType?: AreaType;
    superBuiltUpAreaType?: AreaType;
    noOfBalconies?: number;
    noOfBathRooms?: number;
    noOfBedRooms?: number;
    noOfKitchens?: number;
    noOfDrawingRooms?: number;
    noOfParkingLots?: number;
    images?: string[];
    about?: string;
    propertyStatus: PropertyStatus;
    bookingDate?: Date;
    status: Status;
}

export interface IPropertyDoc extends IProperty, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IPropertyModel = Model<IPropertyDoc>;
