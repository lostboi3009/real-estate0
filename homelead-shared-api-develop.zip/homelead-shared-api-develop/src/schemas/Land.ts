import { Document, Model } from 'mongoose';
import { PropertyType, Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ILand {
    company: TypesObjectId;
    name: string;
    propertyType: PropertyType[];
    address: string;
    city: TypesObjectId;
    state: TypesObjectId;
    country: TypesObjectId;
    zipCode: string;
    coordinates?: number[];
    nearByArea?: string;
    purchasePrice: number;
    currentMarketValue: number;
    propertyTaxRefNo?: string;
    isOnLease: boolean;
    rentalIncome?: number;
    occupancyStatus: string;
    leaseAgreementDocs?: string[];
    isAnyConstructionExists: boolean;
    plotSize?: number;
    sizeType?: string;
    geoGraphicalDetails?: string;
    amenities?: TypesObjectId[];
    ownerName: string;
    ownerEmail?: string;
    ownerCountryCode: string;
    ownerPhone: string;
    pastOwnerName?: string;
    pastOwnerCountryCode?: string;
    pastOwnerPhone?: string;
    status: Status;
}

export interface ILandDoc extends ILand, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ILandModel = Model<ILandDoc>;
