import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IDesignation {
    name: string;
    status: Status;
}

export interface IDesignationDoc extends IDesignation, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IDesignationModel = Model<IDesignationDoc>;
