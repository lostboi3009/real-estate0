import { Document, Model } from 'mongoose';
import { CampaignUserType, Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IContact {
    company: TypesObjectId;
    name: string;
    phone?: string;
    address?: string;
    campaignUserType: CampaignUserType;
    countryCode?: string;
    email?: string;
    status: Status;
}

export interface IContactDoc extends IContact, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IContactModel = Model<IContactDoc>;
