import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IBank {
    bankNameId: {
        _id: TypesObjectId;
        name: string;
        icon?: string;
    };
    branchName: string;
    branchAddress: string;
    company: TypesObjectId;
    ifscCode: string;
    swiftCode: string;
    contactPersonDetails: {
        fullName: string;
        countryCode: string;
        phone: string;
        designation: string;
    };
    status: Status;
}

export interface IBankDoc extends IBank, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IBankModel = Model<IBankDoc>;
