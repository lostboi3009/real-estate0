import { Document, Model } from 'mongoose';
import { OtpType, VerifyType } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IOtp {
    company: TypesObjectId;
    otpType: OtpType;
    verifyType: VerifyType;
    countryCode?: string;
    phone?: string;
    email?: string;
    token: string;
    isVerified: boolean;
    validTill: Date;
}

export interface IOtpDoc extends IOtp, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IOtpModel = Model<IOtpDoc>;
