import { LeadCallToTrack, OTPReceiver, OtpReceiverChannel, WaterMarkPosition } from '@enums/Setting.enum';
import { Document, Model } from 'mongoose';
import { TypesObjectId } from '@schemas';

export interface ICurrency {
    _id: TypesObjectId;
    name: string;
    symbol: string;
    isDefault: boolean;
}

export interface IGeneralSettings {
    hasInternationalSupport: boolean;
    hasCallDetectionActivated: boolean;
    hasCallDetectionForAllLead: LeadCallToTrack;
    currency: ICurrency[];
    countryCode?: TypesObjectId;
    isWaterMarksOnImagesEnabled: boolean;
    waterMarkImage?: string;
    waterMarkPosition?: WaterMarkPosition;
    opacity?: number;
    imageHeight?: string;
    imageWidth?: string;
    tempRentBookingPeriod?: number;
    tempPropertyBookingPeriod?: number;
}

export interface IOtpSettings {
    channels?: OtpReceiverChannel[];
    receiver?: OTPReceiver;
    receiverUserIds?: TypesObjectId[];
    isEnabledForAll?: boolean;
    userIdsToEnableMFA?: TypesObjectId[];
}

export interface ISecuritySettings {
    isTwoFactorAuthenticationEnabled: boolean;
    isCopyPasteEnabled: boolean;
    isScreenshotEnabled: boolean;
    otpSettings: IOtpSettings;
}

export interface IShiftTimeDayWise {
    day?: number;
    isEnabled?: boolean;
    shiftStartTime?: string;
    shiftEndTime?: string;
}

export interface IAttendanceSettings {
    isShiftTimingFeatureEnabled: boolean;
    isSelfieMandatoryForClockOut: boolean;
    isSelfieMandatoryForClockIn: boolean;
    isShiftTimeEnabledForAllDays: boolean;
    isEnabledForAllUsers: boolean;
    userIds?: TypesObjectId[];
    shiftTimingDayWise?: IShiftTimeDayWise[];
}

export interface ILeadNotesSetting {
    isNotesMandatoryEnabled: boolean;
    isNotesMandatoryOnAddLead: boolean;
    isNotesMandatoryOnUpdateLead: boolean;
    isNotesMandatoryOnMeetingDone: boolean;
    isNotesMandatoryOnSiteVisitDone: boolean;
}

export interface ILeadRotationSetting {
    team?: TypesObjectId;
    users?: TypesObjectId[];
    teamLead?: TypesObjectId;
    shiftTimeFrom?: string;
    shiftTimeTo?: string;
    rotationTime?: number;
    noOfRotation?: number;
}

export interface IManageSubStatus {}
export interface IAssignmentPriority {
    priorityName?: string;
    priorityValue?: string;
}

export interface ILeadSettings {
    isLeadsExportEnabled: boolean;
    isLeadSourceEditable: boolean;
    isDuelLeadOwnershipEnabled: boolean;
    isLeadContactInfoMask: boolean;
    leadNotes: ILeadNotesSetting;
    leadRotation: ILeadRotationSetting;
    manageSubStatus?: IManageSubStatus;
    assignmentSetPriority?: IAssignmentPriority[];
}

export interface IDocumentAndPriorities {
    docType?: string;
    templateName?: string;
    priority?: number;
    paymentTerm?: string;
    isMandatory?: boolean;
    documentFormat?: string;
    isActive?: boolean;
}

export interface IInstagram {
    instagram?: {
        accountId?: number;
        accessToken?: string;
    };
}

export interface ISetting {
    company: TypesObjectId;
    general: IGeneralSettings;
    security: ISecuritySettings;
    attendance: IAttendanceSettings;
    isPropertyExportEnabled: boolean;
    isProjectExportEnabled: boolean;
    isLandExportEnabled: boolean;
    leads: ILeadSettings;
    documentAndPriorities: IDocumentAndPriorities[];
    credentials: IInstagram;
}

export interface ISettingDoc extends ISetting, Document {}

export type ISettingModel = Model<ISettingDoc>;
