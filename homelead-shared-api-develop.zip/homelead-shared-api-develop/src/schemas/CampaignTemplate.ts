import { Document, Model } from 'mongoose';
import { Status, TemplateType } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ICampaignTemplate {
    company: TypesObjectId;
    name: string;
    templateType: TemplateType;
    content: string;
    status: Status;
}

export interface ICampaignTemplateDoc extends ICampaignTemplate, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ICampaignTemplateModel = Model<ICampaignTemplateDoc>;
