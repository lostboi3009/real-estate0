import { Document, Model } from 'mongoose';
import { TypesObjectId } from '@schemas';
import { Status } from '@enums';

export interface ITeam {
    company: TypesObjectId;
    name: string;
    groups?: TypesObjectId[];
    members: TypesObjectId[];
    teamLead: TypesObjectId;
    defaultPrimary: TypesObjectId;
    defaultSecondary: TypesObjectId;
    status: Status;
}

export interface ITeamDoc extends ITeam, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ITeamModel = Model<ITeamDoc>;
