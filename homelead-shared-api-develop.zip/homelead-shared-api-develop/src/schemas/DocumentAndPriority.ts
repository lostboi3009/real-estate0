import { Document, Model } from 'mongoose';
import { DocumentPaymentTerm, Status, DocumentType, DocumentTemplateName, PropertyType } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IDocumentAndPriority {
    company: TypesObjectId;
    documentType: DocumentType;
    templateName: DocumentTemplateName;
    priority: number;
    paymentTerm: DocumentPaymentTerm;
    isMandatory: boolean;
    document?: string;
    propertyType: PropertyType;
    status: Status;
}

export interface IDocumentAndPriorityDoc extends IDocumentAndPriority, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IDocumentAndPriorityModel = Model<IDocumentAndPriorityDoc>;
