import { Schema, Types } from 'mongoose';
import { Status, UserAccountType } from '@enums';

export type TypesObjectId = Types.ObjectId;
export const ObjectId = Schema.Types.ObjectId;

export interface CommonSchemaProps {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export interface CommonId {
    id: TypesObjectId;
}

export interface CommonStatus {
    status: Status;
}

export interface Pagination {
    page: number;
    perPage: number;
}

export interface AccountType {
    accountType: UserAccountType[];
}

export interface CompanyId {
    company: TypesObjectId;
}

export * from './Amenity';
export * from './Bank';
export * from './BankName';
export * from './Bhk';
export * from './BhkType';
export * from './Broker';
export * from './BrokerPayment';
export * from './Campaign';
export * from './CampaignTemplate';
export * from './Company';
export * from './Contact';
export * from './Counter';
export * from './Country';
export * from './Designation';
export * from './DocumentAndPriority';
export * from './EmailTrack';
export * from './GeneralExpense';
export * from './Group';
export * from './Land';
export * from './Lead';
export * from './LeadAssignment';
export * from './LeadNote';
export * from './MiscellaneousDocument';
export * from './NearByLocation';
export * from './OnboardingRequest';
export * from './Otp';
export * from './Page';
export * from './Project';
export * from './Permission';
export * from './Plan';
export * from './ProjectCategory';
export * from './Property';
export * from './PropertyBooking';
export * from './PropertyPayment';
export * from './PropertyUnitSubType';
export * from './RentPayment';
export * from './Setting';
export * from './SmsTrack';
export * from './SubscriptionPayment';
export * from './Tag';
export * from './Team';
export * from './Tenant';
export * from './User';
