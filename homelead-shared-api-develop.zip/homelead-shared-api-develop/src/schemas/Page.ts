import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IPage {
    title: string;
    description: string;
    slug: string;
    status: Status;
}

export interface IPageDoc extends IPage, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IPageModel = Model<IPageDoc>;
