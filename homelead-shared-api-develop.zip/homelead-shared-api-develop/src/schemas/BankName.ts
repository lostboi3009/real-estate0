import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IBankName {
    name: string;
    icon: string;
    status: Status;
}

export interface IBankNameDoc extends IBankName, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IBankNameModel = Model<IBankNameDoc>;
