import { Document, Model } from 'mongoose';
import { PaymentMode, RentPaymentStatus } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IRentPayment {
    company: TypesObjectId;
    project: TypesObjectId;
    property: TypesObjectId;
    tenant: TypesObjectId;
    startDate: Date;
    endDate: Date;
    amount: number;
    amountPaid: number;
    paymentStatus: RentPaymentStatus;
    paymentMode: PaymentMode;
    referenceNo?: string;
    remarks?: string;
    receivedOn?: Date;
}

export interface IRentPaymentDoc extends IRentPayment, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IRentPaymentModel = Model<IRentPaymentDoc>;
