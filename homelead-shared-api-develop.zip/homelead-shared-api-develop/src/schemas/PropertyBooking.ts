import {
    PropertyBookingType,
    PropertyBookingExtraCharges,
    PropertyBookingPaymentTerm,
    Status,
    PropertyBookingPaymentStatus,
    PropertyFinanceDeptStatus,
    ClpStatus,
    ClpContributor,
    PropertyPaymentStatus,
    DocumentType,
    DocumentTemplateName,
    PropertyType,
} from '@enums';
import { TypesObjectId } from '@schemas';
import { Document, Model } from 'mongoose';

export interface IExtraCharge {
    chargeFor: PropertyBookingExtraCharges;
    amount: number;
}

export interface IDocument {
    title: string;
    document: string;
}
export interface ITimeLineDocument {
    propertyType: PropertyType;
    templateName: DocumentTemplateName;
    documentType: DocumentType;
    priority: number;
    document: string;
}

export interface IBookingClpPhase {
    name?: string;
    percentage?: number;
    ordinal?: number;
    status?: ClpStatus;
    bankAmount?: number;
    bankAmountReceived?: number;
    bankPaymentStatus?: PropertyPaymentStatus;
    customerAmount?: number;
    customerAmountReceived?: number;
    customerPaymentStatus?: PropertyPaymentStatus;
}

export interface IPropertyBooking {
    company: TypesObjectId;
    lead: TypesObjectId;
    project: TypesObjectId;
    property: TypesObjectId;
    bookingDate: Date;
    panNumber: string;
    aadharNumber: string;
    documents?: IDocument[];
    bookingType: PropertyBookingType;
    saleablePrice?: number;
    bookingAmount?: number;
    bookingPaymentStatus: PropertyBookingPaymentStatus;
    basicPrice?: number;
    taxPercent?: number;
    taxAmount?: number;
    extraCharges?: IExtraCharge[];
    paymentTerm?: PropertyBookingPaymentTerm;
    financeDeptStatus: PropertyFinanceDeptStatus;
    refundAmount?: number;
    clpPhases?: IBookingClpPhase[];
    contributor?: ClpContributor;
    sanctionLetter?: string;
    timelineDocuments?: ITimeLineDocument[];
    status: Status;
}

export interface IPropertyBookingDoc extends IPropertyBooking, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IPropertyBookingModel = Model<IPropertyBookingDoc>;
