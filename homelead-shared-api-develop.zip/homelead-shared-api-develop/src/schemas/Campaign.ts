import { Document, Model } from 'mongoose';
import { Status, CampaignRoute, CampaignStatus, CampaignType, CampaignService } from '@enums';
import { TypesObjectId } from '@schemas';

export interface ICampaign {
    company: TypesObjectId;
    campaignType: CampaignType;
    service: CampaignService;
    name: string;
    route: CampaignRoute;
    targets: TypesObjectId[];
    template: TypesObjectId;
    subject?: string;
    message: string;
    scheduleTime?: Date;
    campaignStatus: CampaignStatus;
    status: Status;
}

export interface ICampaignDoc extends ICampaign, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ICampaignModel = Model<ICampaignDoc>;
