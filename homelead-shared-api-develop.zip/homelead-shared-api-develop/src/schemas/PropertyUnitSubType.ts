import { Document, Model } from 'mongoose';
import { Status, PropertyType } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IPropertyUnitSubType {
    name: string;
    projectType: PropertyType;
    status: Status;
}

export interface IPropertyUnitSubTypeDoc extends IPropertyUnitSubType, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IPropertyUnitSubTypeModel = Model<IPropertyUnitSubTypeDoc>;
