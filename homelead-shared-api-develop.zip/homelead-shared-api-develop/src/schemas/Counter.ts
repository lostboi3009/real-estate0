import { Document, Model } from 'mongoose';
import { TypesObjectId } from '@schemas';

export interface ICounter {
    counts: {
        lead: number;
    };
}

export interface ICounterDoc extends ICounter, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type ICounterModel = Model<ICounterDoc>;
