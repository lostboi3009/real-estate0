import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface INearByLocation {
    name: string;
    status: Status;
}

export interface INearByLocationDoc extends INearByLocation, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type INearByLocationModel = Model<INearByLocationDoc>;
