import { Document, Model } from 'mongoose';
import { Status } from '@enums';
import { TypesObjectId } from '@schemas';

export interface IAmenity {
    name: string;
    icon: string;
    status: Status;
}

export interface IAmenityDoc extends IAmenity, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IAmenityModel = Model<IAmenityDoc>;
