import { AddOnServices, OnboardingStatus } from '@enums';
import { Document, Model } from 'mongoose';
import { TypesObjectId } from '@schemas';

export interface IOnboardingRequest {
    clientName: string;
    name: string;
    address: string;
    country: TypesObjectId;
    state: TypesObjectId;
    city: TypesObjectId;
    primaryCountryCode: string;
    primaryPhone: string;
    secondaryCountryCode: string;
    secondaryPhone: string;
    primaryEmail: string;
    contactPersonName?: string;
    contactPersonCountryCode?: string;
    contactPersonPhone?: string;
    contactPersonEmail?: string;
    plan?: TypesObjectId;
    addOnServices?: AddOnServices[];
    maxNoOfUsers?: number;
    subDomain: string;
    onboardingStatus: OnboardingStatus;
}

export interface IOnboardingRequestDoc extends IOnboardingRequest, Document {
    _id: TypesObjectId;
    createdAt: Date;
    updatedAt: Date;
}

export type IOnboardingRequestModel = Model<IOnboardingRequestDoc>;
