import { RequestHandler, Router } from 'express';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import OnboardingRequestValidations from './OnboardingRequestValidations';
import OnboardingRequestService from './OnboardingRequestService';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.ONBOARDINGS_REQUEST_LIST),
    validate(OnboardingRequestValidations.getAll, 'query'),
    OnboardingRequestService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.ONBOARDINGS_REQUEST_ADD),
    validate(OnboardingRequestValidations.create),
    OnboardingRequestService.create as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.ONBOARDINGS_REQUEST_VIEW),
    validate(OnboardingRequestValidations.requiredId, 'params'),
    OnboardingRequestService.getById as RequestHandler
);

router.patch(
    '/:id/reject-request',
    verifyToken(UserPermissions.ONBOARDINGS_REQUEST_REJECT),
    validate(OnboardingRequestValidations.requiredId, 'params'),
    OnboardingRequestService.rejectRequest as RequestHandler
);

export { router };
