import { Request, Response } from 'express';
import { CommonId, IOnboardingRequest, Pagination, OnboardingStatus } from '@homelead-shared-api';
import { GetOnboardingRequests, IOnboardingStatus } from '@dto';
import OnboardingRequestDao from '../../dao/OnboardingRequestDao';

class OnboardingRequestService {
    async getAll(req: Request, res: Response) {
        const { search, onboardingStatus, page, perPage } = req.query as unknown as GetOnboardingRequests & Pagination;

        const [count, onboardingRequests] = await Promise.all([
            OnboardingRequestDao.countAll({ search, onboardingStatus }),
            OnboardingRequestDao.getAll({ search, onboardingStatus, page, perPage }),
        ]);

        return res.success({ count, onboardingRequests });
    }

    async create(req: Request, res: Response) {
        const data: IOnboardingRequest = req.body;

        const onboardingRequest = await OnboardingRequestDao.create(data);

        return res.success(onboardingRequest);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const onboardingRequest = await OnboardingRequestDao.detailsById({ id });

        if (!onboardingRequest) {
            return res.notFound(null, req.__('ONBOARDING_REQUEST_NOT_FOUND'));
        }

        return res.success(onboardingRequest);
    }

    async rejectRequest(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IOnboardingStatus = { onboardingStatus: OnboardingStatus.REJECT };

        const onboardingRequest = await OnboardingRequestDao.getById({ id });

        if (!onboardingRequest) {
            return res.notFound(null, req.__('ONBOARDING_REQUEST_NOT_FOUND'));
        }

        await OnboardingRequestDao.updateById({ id, data });

        return res.success(null, req.__('ONBOARDING_REQUEST_UPDATED'));
    }
}

export default new OnboardingRequestService();
