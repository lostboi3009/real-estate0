import { joi, commonValidations, AddOnServices, OnboardingStatus } from '@homelead-shared-api';

const getAll = joi.object().keys({
    search: joi.string().trim().optional(),
    onboardingStatus: joi
        .string()
        .trim()
        .valid(...Object.values(OnboardingStatus))
        .optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const create = joi.object().keys({
    clientName: joi.string().trim().min(3).max(30).required(),
    name: joi.string().trim().min(3).max(30).required(),
    address: joi.string().trim().max(200).required(),
    country: commonValidations.id,
    state: commonValidations.id,
    city: commonValidations.id,
    primaryCountryCode: commonValidations.countryCode,
    primaryPhone: commonValidations.phone,
    secondaryCountryCode: commonValidations.countryCode,
    secondaryPhone: commonValidations.phone,
    primaryEmail: commonValidations.email,
    contactPersonName: joi.string().trim().min(3).max(30).optional(),
    contactPersonCountryCode: commonValidations.countryCode.optional(),
    contactPersonPhone: commonValidations.phone.optional(),
    contactPersonEmail: commonValidations.email.optional(),
    plan: commonValidations.id.optional(),
    addOnServices: joi
        .array()
        .items(
            joi
                .string()
                .trim()
                .valid(...Object.values(AddOnServices))
        )
        .optional(),
    maxNoOfUsers: joi.number().integer().positive().optional(),
    subDomain: joi.string().trim().required(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

export default {
    getAll,
    create,
    requiredId,
};
