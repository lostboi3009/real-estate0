export { router } from './OnboardingRequestRoutes';
