import { Request, Response } from 'express';
import { Pagination } from '@homelead-shared-api';
import { GetSubscriptionPayment } from '@dto';
import SubscriptionPaymentDao from '../../dao/SubscriptionPaymentDao';

class SubscriptionPaymentsService {
    async getAll(req: Request, res: Response) {
        const { company, search, paymentStatus, paymentMode, page, perPage } =
            req.query as unknown as GetSubscriptionPayment & Pagination;

        const [count, payments] = await Promise.all([
            SubscriptionPaymentDao.countAll({
                company,
                search,
                paymentStatus,
                paymentMode,
            }),

            SubscriptionPaymentDao.getAll({
                company,
                search,
                paymentStatus,
                paymentMode,
                page,
                perPage,
            }),
        ]);

        return res.success({ count, payments });
    }

    async myPayments(req: Request, res: Response) {
        const { company } = req.user;
        const { search, paymentStatus, paymentMode, page, perPage } = req.query as unknown as GetSubscriptionPayment &
            Pagination;

        const [count, payments] = await Promise.all([
            SubscriptionPaymentDao.countAll({
                company,
                search,
                paymentStatus,
                paymentMode,
            }),
            SubscriptionPaymentDao.getAll({
                company,
                search,
                paymentStatus,
                paymentMode,
                page,
                perPage,
            }),
        ]);

        return res.success({ count, payments });
    }
}

export default new SubscriptionPaymentsService();
