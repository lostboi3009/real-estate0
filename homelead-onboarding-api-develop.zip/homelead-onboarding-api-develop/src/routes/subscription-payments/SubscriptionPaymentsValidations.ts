import { joi, commonValidations, PaymentMode, SubscriptionPaymentStatus } from '@homelead-shared-api';

const getAll = joi.object().keys({
    company: commonValidations.id.optional(),
    search: joi.string().trim().optional(),
    paymentStatus: joi
        .string()
        .trim()
        .valid(...Object.values(SubscriptionPaymentStatus))
        .optional(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode)),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const myPayments = joi.object().keys({
    search: joi.string().trim().optional(),
    paymentStatus: joi
        .string()
        .trim()
        .valid(...Object.values(SubscriptionPaymentStatus))
        .optional(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode)),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

export default {
    getAll,
    myPayments,
};
