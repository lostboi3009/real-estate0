import { RequestHandler, Router } from 'express';
import SubscriptionPaymentsService from './SubscriptionPaymentsService';
import SubscriptionPaymentsValidations from './SubscriptionPaymentsValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.SUBSCRIPTIONS_PAYMENTS_LIST),
    validate(SubscriptionPaymentsValidations.getAll, 'query'),
    SubscriptionPaymentsService.getAll as RequestHandler
);

router.get(
    '/my-payments',
    verifyToken(UserPermissions.SUBSCRIPTIONS_MY_PAYMENTS_LIST),
    validate(SubscriptionPaymentsValidations.myPayments, 'query'),
    SubscriptionPaymentsService.myPayments as RequestHandler
);

export { router };
