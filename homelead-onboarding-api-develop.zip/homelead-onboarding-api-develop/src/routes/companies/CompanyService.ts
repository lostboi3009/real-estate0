import { Request, Response } from 'express';
import moment from 'moment-timezone';
import CompanyDao from '../../dao/CompanyDao';
import UserDao from '../../dao/UserDao';
import {
    ICompany,
    IUser,
    Status,
    CommonStatus,
    CommonId,
    Pagination,
    UserAccountType,
    randomString,
    TypesObjectId,
    OnboardingStatus,
    ISubscriptionPayment,
    SubscriptionPaymentStatus,
    isDevEnv,
    sendMail,
    logger,
    Platform,
} from '@homelead-shared-api';
import { GetCompanies, GetCompanyBySubDomain, ICreateCompany, IUpGradePlan } from '@dto';
import OnboardingRequestDao from '../../dao/OnboardingRequestDao';
import PlanDao from '../../dao/PlanDao';
import SubscriptionPaymentDao from '../../dao/SubscriptionPaymentDao';
import { calculatePlanEndDate } from '../../utils/common';
import { signToken } from '../../utils/auth';

class CompanyService {
    async getAll(req: Request, res: Response) {
        const { search, status, page, perPage } = req.query as unknown as GetCompanies & Pagination;

        const [count, companies] = await Promise.all([
            CompanyDao.countAll({
                search,
                status,
            }),
            CompanyDao.getAll({
                search,
                status,
                page,
                perPage,
            }),
        ]);

        return res.success({ count, companies });
    }

    async activeCompanies(req: Request, res: Response) {
        const companies = await CompanyDao.activeCompanies();

        return res.success(companies);
    }

    async create(req: Request, res: Response) {
        const data: ICreateCompany = req.body;

        const isSubDomainExists = await CompanyDao.getCompanyBySubDomain({
            subDomain: data.subDomain,
        });

        if (isSubDomainExists) {
            return res.badRequest(null, req.__('SUB_DOMAIN_ALREADY_FOUND'));
        }

        const plan = await CompanyDao.getPlanById({ id: data.plan });

        if (!plan) {
            return res.notFound(null, req.__('PLAN_NOT_FOUND'));
        }

        if (data.subscriptionPaymentStatus === SubscriptionPaymentStatus.PAID) {
            try {
                data.planEndDate = calculatePlanEndDate(data.planStartDate, plan.paymentDuration) as unknown as Date;
            } catch (e: unknown) {
                const errorMessage = e instanceof Error ? e.message : 'GENERAL_ERROR';
                return res.warn(null, req.__(errorMessage));
            }
        }

        const company = await CompanyDao.create(data);
        const companyId = company._id;

        const user: Partial<IUser> = {
            company: companyId,
            firstName: data.name,
            email: data.primaryEmail,
            permissions: plan.permissions,
            countryCode: data.primaryCountryCode,
            phone: data.primaryPhone,
            secondaryCountryCode: data.secondaryCountryCode,
            secondaryPhone: data.secondaryPhone,
            password: randomString(8),
            isReportingManager: true,
            accountType: UserAccountType.COMPANY_SUPER_ADMIN,
            askForPasswordReset: true,
        };

        const superAdmin = await UserDao.create(user);

        await CompanyDao.updateById({
            id: companyId,
            data: {
                superAdmin: superAdmin._id,
            },
        });

        if (data.subscriptionPaymentStatus === SubscriptionPaymentStatus.DUE) {
            try {
                data.planEndDate = calculatePlanEndDate(data.planStartDate, plan.paymentDuration) as unknown as Date;
            } catch (e: unknown) {
                const errorMessage = e instanceof Error ? e.message : 'GENERAL_ERROR';
                return res.warn(null, req.__(errorMessage));
            }
        }

        const subscriptionPayment: ISubscriptionPayment = {
            company: companyId,
            plan: data.plan,
            startDate: data.planStartDate as unknown as Date,
            endDate: data.planEndDate as unknown as Date,
            amount: data.amountPaid,
            paymentStatus: data.subscriptionPaymentStatus,
            paymentMode: data.paymentMode,
            referenceNo: data.transactionRefNo,
            remarks: data.remarks,
        };

        await SubscriptionPaymentDao.create(subscriptionPayment);

        if (data.onboardingRequest) {
            await OnboardingRequestDao.updateById({
                id: data.onboardingRequest,
                data: { onboardingStatus: OnboardingStatus.ONBOARDED },
            });
        }

        if (!isDevEnv) {
            sendMail('onboarding-temp-password', req.__('TEMPORARY_PASSWORD_FOR_LOGIN'), data.primaryEmail, {
                password: user.password,
                loginPage: `${data.subDomain}/en/login`,
            }).catch(error => {
                logger.error(
                    `CompanyService:: create -> failed to send onboarding-temp-password email to ${data.primaryEmail}`,
                    error
                );
                throw error;
            });
        }

        return res.success(company);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const company = await CompanyDao.getById({ id });

        if (!company) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        return res.success(company);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: ICompany = req.body;

        const company = await CompanyDao.getById({ id });

        if (!company) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        const isSubDomainExists = await CompanyDao.getCompanyBySubDomain({
            id,
            subDomain: data.subDomain,
        });

        if (isSubDomainExists) {
            return res.badRequest(null, req.__('SUB_DOMAIN_ALREADY_FOUND'));
        }

        const superAdminId = company.superAdmin as unknown as TypesObjectId;

        const emailExists = await UserDao.getUserByEmail({
            id: superAdminId,
            company: id,
            email: data.primaryEmail,
        });

        if (emailExists) {
            return res.badRequest(null, req.__('EMAIL_ALREADY_FOUND'));
        }

        const phoneExists = await UserDao.getUserByPhone({
            id: superAdminId,
            company: id,
            countryCode: data.primaryCountryCode,
            phone: data.primaryPhone,
        });

        if (phoneExists) {
            return res.badRequest(null, req.__('PHONE_ALREADY_FOUND'));
        }

        await CompanyDao.updateById({ id, data });

        await UserDao.updateUser({
            id: superAdminId,
            company: id,
            data: {
                firstName: data.name,
                email: data.primaryEmail,
                countryCode: data.primaryCountryCode,
                phone: data.primaryPhone,
                secondaryCountryCode: data.secondaryCountryCode,
                secondaryPhone: data.secondaryPhone,
            },
        });

        return res.success(null, req.__('COMPANY_UPDATE_SUCCESS'));
    }

    async upgradePlan(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IUpGradePlan = req.body;

        const company = await CompanyDao.getById({ id });

        if (!company) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        const plan = await PlanDao.getById({
            id: data.plan,
        });

        if (!plan) {
            return res.notFound(null, req.__('PLAN_NOT_FOUND'));
        }

        if (data.subscriptionPaymentStatus === SubscriptionPaymentStatus.PAID) {
            data.planStartDate = new Date();
            try {
                data.planEndDate = calculatePlanEndDate(data.planStartDate, plan.paymentDuration) as unknown as Date;
            } catch (e: unknown) {
                const errorMessage = e instanceof Error ? e.message : 'GENERAL_ERROR';
                return res.warn(null, req.__(errorMessage));
            }
        }

        await CompanyDao.updateById({ id, data });

        if (data.subscriptionPaymentStatus === SubscriptionPaymentStatus.DUE) {
            data.planStartDate = new Date();
            try {
                data.planEndDate = calculatePlanEndDate(data.planStartDate, plan.paymentDuration) as unknown as Date;
            } catch (e: unknown) {
                const errorMessage = e instanceof Error ? e.message : 'GENERAL_ERROR';
                return res.warn(null, req.__(errorMessage));
            }
        }

        const superAdminId = company.superAdmin as unknown as TypesObjectId;

        await UserDao.updateUser({
            id: superAdminId,
            company: id,
            data: {
                permissions: plan.permissions,
            },
        });

        const subscriptionPayment: ISubscriptionPayment = {
            company: id,
            plan: data.plan,
            startDate: data.planStartDate as unknown as Date,
            endDate: data.planEndDate as unknown as Date,
            amount: data.amountPaid,
            paymentStatus: data.subscriptionPaymentStatus,
            paymentMode: data.paymentMode,
            referenceNo: data.transactionRefNo,
            remarks: data.remarks,
        };

        await SubscriptionPaymentDao.create(subscriptionPayment);

        return res.success(null, req.__('PLAN_UPGRADE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<ICompany> = {
            status: Status.ARCHIVED,
        };

        const company = await CompanyDao.getById({ id });

        if (!company) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        await CompanyDao.updateById({ id, data });

        return res.success(null, req.__('COMPANY_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const company = await CompanyDao.getById({ id });

        if (!company) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        await CompanyDao.updateById({ id, data });

        return res.success(null, req.__('COMPANY_STATUS_UPDATED'));
    }

    async isSubDomainExists(req: Request, res: Response) {
        const { subDomain, id }: GetCompanyBySubDomain = req.body;

        const isSubDomainExists = await CompanyDao.getCompanyBySubDomain({
            subDomain,
            id,
        });

        return res.success({
            isSubDomainExists: isSubDomainExists !== null,
        });
    }

    async sso(req: Request, res: Response) {
        const { id } = req.query as unknown as CommonId;

        const company = await CompanyDao.getById({ id });

        if (!company || !company.superAdmin) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        const companySuperAdmin = await UserDao.getUserByIdForSSO({
            company: company._id,
            id: company.superAdmin,
        });

        if (!companySuperAdmin || !companySuperAdmin?.company) {
            return res.warn(null, req.__('USER_NOT_FOUND'));
        }

        const authTokenIssuedAt = companySuperAdmin.authTokenIssuedAt || moment().valueOf();
        const token = signToken({
            sub: `${companySuperAdmin._id}-${company._id}`,
            iat: authTokenIssuedAt,
            aud: Platform.web,
            sessionID: req.sessionID,
        });

        await UserDao.updateUser({
            id: companySuperAdmin._id,
            company: company._id,
            data: {
                authTokenIssuedAt,
            },
        });

        res.cookie(
            'homeleadAuth',
            JSON.stringify({
                authToken: token,
                user: companySuperAdmin._id,
                company: company._id,
            }),
            {
                path: '/',
                httpOnly: true,
                secure: true,
                sameSite: 'strict',
            }
        );

        return res.redirect(company.subDomain);
    }
}

export default new CompanyService();
