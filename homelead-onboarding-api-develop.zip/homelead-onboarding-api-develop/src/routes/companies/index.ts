export { router } from './CompanyRoutes';
