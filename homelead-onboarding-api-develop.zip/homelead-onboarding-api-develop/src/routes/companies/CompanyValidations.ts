import { joi, commonValidations, AddOnServices, PaymentMode, SubscriptionPaymentStatus } from '@homelead-shared-api';

const getAll = joi.object().keys({
    search: joi.string().trim().optional(),
    status: commonValidations.status.optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const create = joi.object().keys({
    onboardingRequest: commonValidations.id.optional(),
    clientName: joi.string().trim().min(3).max(30).required(),
    name: joi.string().trim().min(3).max(30).required(),
    address: joi.string().trim().max(200).required(),
    country: commonValidations.id,
    state: commonValidations.id,
    city: commonValidations.id,
    primaryCountryCode: commonValidations.countryCode,
    primaryPhone: commonValidations.phone,
    secondaryCountryCode: commonValidations.countryCode,
    secondaryPhone: commonValidations.phone,
    primaryEmail: commonValidations.email,
    contactPersonName: joi.string().trim().min(3).max(30).optional(),
    contactPersonCountryCode: commonValidations.countryCode.optional(),
    contactPersonPhone: commonValidations.phone.optional(),
    contactPersonEmail: commonValidations.email.optional(),
    plan: commonValidations.id,
    addOnServices: joi
        .array()
        .items(
            joi
                .string()
                .trim()
                .valid(...Object.values(AddOnServices))
        )
        .optional(),
    planStartDate: joi.date().required(),
    maxNoOfUsers: joi.number().integer().positive().optional(),
    amountPaid: joi.number().positive().required(),
    subscriptionPaymentStatus: joi
        .string()
        .trim()
        .valid(...Object.values(SubscriptionPaymentStatus))
        .optional(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .required(),
    transactionRefNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
    subDomain: joi.string().trim().required(),
});

const update = joi.object().keys({
    clientName: joi.string().trim().min(3).max(30).required(),
    name: joi.string().trim().min(3).max(30).required(),
    address: joi.string().trim().max(200).required(),
    country: commonValidations.id,
    state: commonValidations.id,
    city: commonValidations.id,
    primaryCountryCode: commonValidations.countryCode,
    primaryPhone: commonValidations.phone,
    secondaryCountryCode: commonValidations.countryCode,
    secondaryPhone: commonValidations.phone,
    primaryEmail: commonValidations.email,
    contactPersonName: joi.string().trim().min(3).max(30).optional(),
    contactPersonCountryCode: commonValidations.countryCode.optional(),
    contactPersonPhone: commonValidations.phone.optional(),
    contactPersonEmail: commonValidations.email.optional(),
    subDomain: joi.string().trim().required(),
});

const upgradePlan = joi.object().keys({
    plan: commonValidations.id,
    maxNoOfUsers: joi.number().integer().positive().required(),
    addOnServices: joi
        .array()
        .items(
            joi
                .string()
                .trim()
                .valid(...Object.values(AddOnServices))
        )
        .optional(),
    amountPaid: joi.number().positive().required(),
    subscriptionPaymentStatus: joi
        .string()
        .trim()
        .valid(...Object.values(SubscriptionPaymentStatus))
        .optional(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .required(),
    transactionRefNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
});

const isSubDomainExists = joi.object().keys({
    subDomain: joi.string().trim().required(),
    id: commonValidations.id.optional(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

const sso = joi.object().keys({
    id: commonValidations.id,
    state: joi.string().trim().required(),
});

export default {
    getAll,
    create,
    update,
    requiredId,
    updateStatus,
    isSubDomainExists,
    upgradePlan,
    sso,
};
