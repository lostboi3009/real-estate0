import { RequestHandler, Router } from 'express';
import CompanyService from './CompanyService';
import CompanyValidations from './CompanyValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.ONBOARDINGS_COMPANIES_LIST),
    validate(CompanyValidations.getAll, 'query'),
    CompanyService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.ONBOARDINGS_COMPANIES_ADD),
    validate(CompanyValidations.create),
    CompanyService.create as RequestHandler
);

router.get('/active-companies', verifyToken(), CompanyService.activeCompanies as RequestHandler);

router.post(
    '/is-subdomain-exists',
    verifyToken(),
    validate(CompanyValidations.isSubDomainExists),
    CompanyService.isSubDomainExists as RequestHandler
);

router.get(
    '/sso',
    verifyToken(UserPermissions.ONBOARDINGS_COMPANIES_SSO),
    validate(CompanyValidations.sso, 'query'),
    CompanyService.sso as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.ONBOARDINGS_COMPANIES_VIEW),
    validate(CompanyValidations.requiredId, 'params'),
    CompanyService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.ONBOARDINGS_COMPANIES_UPDATE),
    validate(CompanyValidations.requiredId, 'params'),
    validate(CompanyValidations.update),
    CompanyService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.ONBOARDINGS_COMPANIES_DELETE),
    validate(CompanyValidations.requiredId, 'params'),
    CompanyService.deleteById as RequestHandler
);

router.put(
    '/:id/upgrade-plan',
    verifyToken(UserPermissions.ONBOARDINGS_COMPANIES_UPGRADE_PLAN),
    validate(CompanyValidations.requiredId, 'params'),
    validate(CompanyValidations.upgradePlan),
    CompanyService.upgradePlan as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.ONBOARDINGS_COMPANIES_UPDATE),
    validate(CompanyValidations.requiredId, 'params'),
    validate(CompanyValidations.updateStatus),
    CompanyService.updateStatus as RequestHandler
);

export { router };
