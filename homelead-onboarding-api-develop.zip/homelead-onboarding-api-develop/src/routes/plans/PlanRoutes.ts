import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import PlanService from './PlanService';
import PlanValidations from './PlanValidations';
import { UserPermissions } from '@homelead-shared-api';
import { validate } from '../../utils/validations';

const router = Router();

router.get('/', verifyToken(UserPermissions.ONBOARDINGS_PLANS_LIST), PlanService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.ONBOARDINGS_PLANS_ADD),
    validate(PlanValidations.create),
    PlanService.create as RequestHandler
);

router.get('/active-plans', verifyToken(), PlanService.getActivePlans as RequestHandler);

router.get('/permissions', verifyToken(), PlanService.getAllPermissions as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.ONBOARDINGS_PLANS_VIEW),
    validate(PlanValidations.requiredId, 'params'),
    PlanService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.ONBOARDINGS_PLANS_UPDATE),
    validate(PlanValidations.requiredId, 'params'),
    validate(PlanValidations.create),
    PlanService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.ONBOARDINGS_PLANS_DELETE),
    validate(PlanValidations.requiredId, 'params'),
    PlanService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.ONBOARDINGS_PLANS_UPDATE),
    validate(PlanValidations.requiredId, 'params'),
    validate(PlanValidations.updateStatus),
    PlanService.updateStatus as RequestHandler
);

export { router };
