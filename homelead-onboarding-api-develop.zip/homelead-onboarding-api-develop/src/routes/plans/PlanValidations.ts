import { joi, commonValidations, PaymentDuration } from '@homelead-shared-api';

const create = joi.object().keys({
    name: joi.string().trim().min(3).max(50).required(),
    paymentDuration: joi
        .string()
        .valid(...Object.values(PaymentDuration))
        .required(),
    price: joi.number().positive().required(),
    description: joi.string().trim().max(400).required(),
    features: joi.array().items(joi.string().trim().required()).required(),
    permissions: joi.object().pattern(joi.string(), joi.array().items(joi.string())).required(),
});

const getAll = joi.object().keys({
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    create,
    getAll,
    requiredId,
    updateStatus,
};
