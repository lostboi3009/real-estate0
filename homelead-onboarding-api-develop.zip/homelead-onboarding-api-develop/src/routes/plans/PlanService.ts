import { Request, Response } from 'express';
import PlanDao from '../../dao/PlanDao';
import UserDao from '../../dao/UserDao';
import { GetPlans } from '@dto';
import { CommonId, CommonStatus, IPlan, Pagination, Status } from '@homelead-shared-api';

class PlanService {
    async getAll(req: Request, res: Response) {
        const { page, perPage, search, status } = req.query as unknown as GetPlans & Pagination;

        const [count, plans] = await Promise.all([
            PlanDao.countAll({ search, status }),
            PlanDao.getAll({ page, perPage, search, status }),
        ]);

        return res.success({
            count,
            plans,
        });
    }

    async getActivePlans(req: Request, res: Response) {
        const plans = await PlanDao.getActivePlans();

        return res.success(plans);
    }

    async getAllPermissions(req: Request, res: Response) {
        const permissions = await UserDao.getAllPermissions();

        return res.success(permissions);
    }

    async create(req: Request, res: Response) {
        const plan: IPlan = req.body;
        const slug = plan.name.toLowerCase().replace(' ', '-');

        const slugExists = await PlanDao.getBySlug({ slug });

        if (slugExists) {
            return res.notFound(null, req.__('PLAN_NAME_ALREADY_TAKEN'));
        }

        const response = await PlanDao.create({
            ...plan,
            slug,
        });

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const plan = await PlanDao.getById({ id });

        if (!plan) {
            return res.notFound(null, req.__('PLAN__NOT_FOUND'));
        }

        return res.success(plan);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IPlan = req.body;

        const plan = await PlanDao.getById({ id });

        if (!plan) {
            return res.notFound(null, req.__('PLAN_NOT_FOUND'));
        }

        await PlanDao.updateById({ id, data });

        return res.success(null, req.__('PLAN_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IPlan> = {
            status: Status.ARCHIVED,
        };

        const plan = await PlanDao.getById({ id });

        if (!plan) {
            return res.notFound(null, req.__('PLAN_NOT_FOUND'));
        }

        await PlanDao.updateById({ id, data });

        return res.success(null, req.__('PLAN_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const plan = await PlanDao.getById({ id });

        if (!plan) {
            return res.notFound(null, req.__('PLAN_NOT_FOUND'));
        }

        await PlanDao.updateById({ id, data });

        return res.success(null, req.__('PLAN_STATUS_UPDATED'));
    }
}

export default new PlanService();
