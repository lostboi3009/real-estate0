import {
    Pagination,
    mongoose,
    getSearchRegex,
    IOnboardingRequest,
    IOnboardingRequestDoc,
    OnboardingStatus,
    OnboardingRequest,
    CommonId,
} from '@homelead-shared-api';
import { GetOnboardingRequests } from '@dto';

type FilterQueryIOnboardingRequest = mongoose.FilterQuery<IOnboardingRequest>;

class OnboardingRequestDao {
    async getAll({
        search,
        onboardingStatus,
        page,
        perPage,
    }: GetOnboardingRequests & Pagination): Promise<IOnboardingRequestDoc[]> {
        const matchCriteria: FilterQueryIOnboardingRequest = {
            onboardingStatus: OnboardingStatus.PENDING,
        };

        if (onboardingStatus) {
            matchCriteria.onboardingStatus = onboardingStatus;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { clientName: { $regex: searchRegex } },
                { name: { $regex: searchRegex } },
                { address: { $regex: searchRegex } },
                { primaryEmail: { $regex: searchRegex } },
                { contactPersonName: { $regex: searchRegex } },
                { contactPersonEmail: { $regex: searchRegex } },
            ];
        }

        return OnboardingRequest.find(matchCriteria)
            .populate('plan')
            .skip((page - 1) * perPage)
            .limit(perPage)
            .sort({ _id: -1 });
    }

    async countAll({ search, onboardingStatus }: GetOnboardingRequests): Promise<number> {
        const matchCriteria: FilterQueryIOnboardingRequest = {
            onboardingStatus: OnboardingStatus.PENDING,
        };

        if (onboardingStatus) {
            matchCriteria.onboardingStatus = onboardingStatus;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { clientName: { $regex: searchRegex } },
                { name: { $regex: searchRegex } },
                { address: { $regex: searchRegex } },
                { primaryEmail: { $regex: searchRegex } },
                { contactPersonName: { $regex: searchRegex } },
                { contactPersonEmail: { $regex: searchRegex } },
            ];
        }

        return OnboardingRequest.countDocuments(matchCriteria);
    }

    async create(onboardingRequest: IOnboardingRequest): Promise<IOnboardingRequestDoc> {
        return OnboardingRequest.create(onboardingRequest);
    }

    async getById({ id }: CommonId): Promise<IOnboardingRequestDoc | null> {
        return OnboardingRequest.findOne({
            _id: id,
            onboardingStatus: OnboardingStatus.PENDING,
        });
    }

    async detailsById({ id }: CommonId): Promise<IOnboardingRequestDoc | null> {
        return OnboardingRequest.findOne({
            _id: id,
            onboardingStatus: OnboardingStatus.PENDING,
        }).populate('plan');
    }

    async updateById({ id, data }: CommonId & { data: Partial<IOnboardingRequestDoc> }) {
        return OnboardingRequest.updateOne(
            {
                _id: id,
                onboardingStatus: OnboardingStatus.PENDING,
            },
            {
                $set: data,
            }
        );
    }
}

export default new OnboardingRequestDao();
