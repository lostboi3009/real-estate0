import {
    User,
    CommonId,
    CompanyId,
    IUser,
    IUserDoc,
    Status,
    AccountType,
    mongoose,
    UserAccountType,
    Permission,
    IPermissionDoc,
} from '@homelead-shared-api';
import { GetUserByEmail, GetUserByPhone, UpdateUser } from '@dto';

type FilterQueryIUser = mongoose.FilterQuery<IUser>;

class UserDao {
    getUserById({ id, company, accountType }: CommonId & CompanyId & AccountType): Promise<IUserDoc | null> {
        return User.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: {
                $in: accountType,
            },
        }).populate({
            path: 'company',
            match: {
                status: Status.ACTIVE,
            },
        });
    }

    getUserByIdForSSO({ company, id }: CommonId & CompanyId): Promise<IUserDoc | null> {
        return User.findOne({
            company,
            _id: id,
            accountType: UserAccountType.COMPANY_SUPER_ADMIN,
            status: { $ne: Status.ARCHIVED },
        }).populate({
            path: 'company',
            match: {
                status: { $ne: Status.ARCHIVED },
            },
        });
    }

    async create(user: Partial<IUser>): Promise<IUserDoc> {
        return User.create(user);
    }

    async getUserByEmail({ id, company, email }: GetUserByEmail): Promise<IUserDoc | null> {
        const matchCriteria: FilterQueryIUser = {
            company,
            email,
            status: { $ne: Status.ARCHIVED },
        };

        if (id) {
            matchCriteria._id = {
                $ne: id,
            };
        }

        return User.findOne(matchCriteria);
    }

    async getUserByPhone({ id, company, countryCode, phone }: GetUserByPhone): Promise<IUserDoc | null> {
        const matchCriteria: FilterQueryIUser = {
            company,
            countryCode,
            phone,
            status: { $ne: Status.ARCHIVED },
        };

        if (id) {
            matchCriteria._id = {
                $ne: id,
            };
        }

        return User.findOne(matchCriteria);
    }

    async updateUser({ id, company, data }: UpdateUser) {
        return User.updateOne(
            {
                company,
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    async getAllPermissions(): Promise<IPermissionDoc[]> {
        return Permission.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ name: 1 });
    }
}

export default new UserDao();
