import {
    ISubscriptionPayment,
    ISubscriptionPaymentDoc,
    SubscriptionPayment,
    Status,
    Pagination,
    mongoose,
    getSearchRegex,
} from '@homelead-shared-api';
import { GetSubscriptionPayment } from '@dto';

type FilterQueryISubscriptionPayment = mongoose.FilterQuery<ISubscriptionPayment>;

class SubscriptionPaymentDao {
    async getAll({
        company,
        search,
        paymentStatus,
        paymentMode,
        page,
        perPage,
    }: GetSubscriptionPayment & Pagination): Promise<ISubscriptionPaymentDoc[]> {
        const matchCriteria: FilterQueryISubscriptionPayment = {
            status: { $ne: Status.ARCHIVED },
        };

        if (company) {
            matchCriteria.company = company;
        }

        if (paymentStatus) {
            matchCriteria.paymentStatus = paymentStatus;
        }

        if (paymentMode) {
            matchCriteria.paymentMode = paymentMode;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ referenceNo: { $regex: searchRegex } }, { remarks: { $regex: searchRegex } }];
        }

        return SubscriptionPayment.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .populate('company')
            .populate('plan')
            .sort({ _id: -1 });
    }

    async countAll({ company, search, paymentStatus, paymentMode }: GetSubscriptionPayment): Promise<number> {
        const matchCriteria: FilterQueryISubscriptionPayment = {
            status: { $ne: Status.ARCHIVED },
        };

        if (company) {
            matchCriteria.company = company;
        }

        if (paymentStatus) {
            matchCriteria.paymentStatus = paymentStatus;
        }

        if (paymentMode) {
            matchCriteria.paymentMode = paymentMode;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ referenceNo: { $regex: searchRegex } }, { remarks: { $regex: searchRegex } }];
        }

        return SubscriptionPayment.countDocuments(matchCriteria);
    }

    async create(subscriptionPayment: ISubscriptionPayment): Promise<ISubscriptionPaymentDoc> {
        return SubscriptionPayment.create(subscriptionPayment);
    }

    async bulkCreate(subscriptionPayments: ISubscriptionPayment[]): Promise<ISubscriptionPaymentDoc[]> {
        return SubscriptionPayment.insertMany(subscriptionPayments);
    }
}

export default new SubscriptionPaymentDao();
