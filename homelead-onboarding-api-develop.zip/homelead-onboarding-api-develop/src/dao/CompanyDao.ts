import {
    Company,
    Plan,
    ICompany,
    ICompanyDoc,
    IPlanDoc,
    Status,
    CommonId,
    Pagination,
    mongoose,
    getSearchRegex,
} from '@homelead-shared-api';
import { GetCompanies, GetCompanyBySubDomain, GetPlanExpiredCompanies } from '@dto';

type FilterQueryICompany = mongoose.FilterQuery<ICompany>;

class CompanyDao {
    async getAll({ search, status, page, perPage }: GetCompanies & Pagination): Promise<ICompanyDoc[]> {
        const matchCriteria: FilterQueryICompany = {
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { clientName: { $regex: searchRegex } },
                { name: { $regex: searchRegex } },
                { address: { $regex: searchRegex } },
                { primaryEmail: { $regex: searchRegex } },
                { contactPersonName: { $regex: searchRegex } },
                { contactPersonEmail: { $regex: searchRegex } },
            ];
        }

        return Company.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .populate({
                path: 'plan',
                select: 'name',
            })
            .sort({ _id: -1 });
    }

    async countAll({ search, status }: GetCompanies): Promise<number> {
        const matchCriteria: FilterQueryICompany = {
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { clientName: { $regex: searchRegex } },
                { name: { $regex: searchRegex } },
                { address: { $regex: searchRegex } },
                { primaryEmail: { $regex: searchRegex } },
                { contactPersonName: { $regex: searchRegex } },
                { contactPersonEmail: { $regex: searchRegex } },
            ];
        }

        return Company.countDocuments(matchCriteria);
    }

    async activeCompanies(): Promise<ICompanyDoc[]> {
        return Company.find({
            status: Status.ACTIVE,
        })
            .select('name clientName plan planStartDate planEndDate maxNoOfUsers')
            .sort({ _id: -1 });
    }

    async getCompanyBySubDomain({ id, subDomain }: GetCompanyBySubDomain): Promise<ICompanyDoc | null> {
        const matchCriteria: FilterQueryICompany = {
            subDomain,
            status: { $ne: Status.ARCHIVED },
        };

        if (id) {
            matchCriteria._id = {
                $ne: id,
            };
        }

        return Company.findOne(matchCriteria);
    }

    async create(company: ICompany): Promise<ICompanyDoc> {
        return Company.create(company);
    }

    async getById({ id }: CommonId): Promise<ICompanyDoc | null> {
        return Company.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<ICompany> }) {
        return Company.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    async getPlanById({ id }: CommonId): Promise<IPlanDoc | null> {
        return Plan.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getPlanExpiredCompanies({ startDate, endDate }: GetPlanExpiredCompanies): Promise<ICompanyDoc[]> {
        return Company.find({
            planEndDate: {
                $gte: startDate,
                $lte: endDate,
            },
            status: Status.ACTIVE,
        });
    }
}

export default new CompanyDao();
