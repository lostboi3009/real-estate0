import { IPlanDoc, Plan, Status, CommonId, getSearchRegex, Pagination, mongoose, IPlan } from '@homelead-shared-api';
import { GetBySlug, GetPlans } from '@dto';

type FilterQueryIPlan = mongoose.FilterQuery<IPlan>;
class PlanDao {
    async getAll({ page, perPage, search, status }: GetPlans & Pagination): Promise<IPlanDoc[]> {
        const matchCriteria: FilterQueryIPlan = {
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }];
        }

        return Plan.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .sort({ name: 1 });
    }

    async countAll({ search, status }: GetPlans): Promise<number> {
        const matchCriteria: FilterQueryIPlan = {
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }];
        }

        return Plan.countDocuments(matchCriteria);
    }

    async getActivePlans(): Promise<IPlanDoc[]> {
        return Plan.find({
            status: Status.ACTIVE,
        }).sort({ name: 1 });
    }

    async create(plan: IPlan): Promise<IPlanDoc> {
        return Plan.create(plan);
    }

    async getById({ id }: CommonId): Promise<IPlanDoc | null> {
        return Plan.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getBySlug({ slug }: GetBySlug): Promise<IPlanDoc | null> {
        return Plan.findOne({
            slug,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<IPlan> }) {
        return Plan.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new PlanDao();
