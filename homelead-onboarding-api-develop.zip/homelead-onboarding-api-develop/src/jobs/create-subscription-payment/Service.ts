import moment from 'moment-timezone';
import {
    isDevEnv,
    ISubscriptionPayment,
    logger,
    mongoose,
    PaymentMode,
    sendMail,
    SubscriptionPaymentStatus,
} from '@homelead-shared-api';
import SubscriptionPaymentDao from '../../dao/SubscriptionPaymentDao';
import CompanyDao from '../../dao/CompanyDao';
import { calculatePlanEndDate } from '../../utils/common';
import PlanDao from '../../dao/PlanDao';
import { ISubscriptionPayments } from '@dto';
import { __ } from '@lib/i18n';

const SUBSCRIPTION_PAYMENT_BASE_URL = process.env.SUBSCRIPTION_PAYMENT_BASE_URL;

class Service {
    async createSubscriptionPayments() {
        const startDate = moment().startOf('day').toDate();
        const endDate = moment().endOf('day').toDate();
        const subscriptionPayments: ISubscriptionPayment[] = [];

        const companies = await CompanyDao.getPlanExpiredCompanies({ startDate, endDate });
        const plans = await PlanDao.getActivePlans();

        for (const company of companies) {
            const { _id, plan: planId, amountPaid, primaryEmail, clientName } = company;

            const plan = plans.find(i => i._id.toString() === planId.toString());

            if (!plan) {
                continue;
            }

            const planEndDate = calculatePlanEndDate(startDate, plan.paymentDuration);
            const paymentId = new mongoose.Types.ObjectId();

            const payment: ISubscriptionPayments = {
                _id: paymentId,
                company: _id,
                plan: planId,
                startDate,
                endDate: planEndDate as unknown as Date,
                amount: amountPaid,
                paymentStatus: SubscriptionPaymentStatus.DUE,
                paymentMode: PaymentMode.ONLINE,
            };

            subscriptionPayments.push(payment);

            if (!isDevEnv) {
                sendMail('subscription-payment-due', __('en', 'SUBSCRIPTION_PAYMENT_DUE'), primaryEmail, {
                    clientName,
                    paymentLink: `${SUBSCRIPTION_PAYMENT_BASE_URL}/${paymentId}`,
                }).catch(error => {
                    logger.error(`createSubscriptionPayments:: failed to send email to ${primaryEmail}`, error);
                });
            }
        }

        await SubscriptionPaymentDao.bulkCreate(subscriptionPayments);
    }
}

export default new Service();
