import { Request } from 'express';
import { Languages } from '@dto';
import { PaymentDuration, Platform } from '@homelead-shared-api';
import moment from 'moment';

export const getLanguage = (req: Request) => (req.headers['accept-language'] ?? 'en') as Languages;

export const getPlatform = (req: Request) => req.headers['x-platform'] as Platform;

export const calculatePlanEndDate = (startDate: Date | undefined, paymentDuration: PaymentDuration): string => {
    const planStartDate = moment(startDate);

    switch (paymentDuration) {
        case PaymentDuration.MONTHLY:
            return planStartDate.add(1, 'month').format();
        case PaymentDuration.QUARTERLY:
            return planStartDate.add(3, 'months').format();
        case PaymentDuration.YEARLY:
            return planStartDate.add(1, 'year').format();
        default:
            throw new Error('INVALID_PAYMENT_DURATION');
    }
};
