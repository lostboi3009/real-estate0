import moment from 'moment-timezone';
import { sign, verify } from 'jsonwebtoken';
import { NextFunction, Request, RequestHandler, Response } from 'express';
import { SignUserToken, VerifyUserAccess } from '@dto';
import { __ } from '@lib/i18n';
import { getLanguage, getPlatform } from './common';
import UserDao from '../dao/UserDao';
import { IUserDoc, logger, Status, UserAccountType, TypesObjectId, ICompanyDoc, Platform } from '@homelead-shared-api';

const accountType = [
    UserAccountType.SUPER_ADMIN,
    UserAccountType.SUB_ADMIN,
    UserAccountType.COMPANY_SUB_ADMIN,
    UserAccountType.COMPANY_SUPER_ADMIN,
];

export const signToken = ({ sub, iat, aud, sessionID }: SignUserToken) =>
    sign({ sub, iat, aud, sessionID }, process.env.JWT_SECRET);

export const verifyUserAccess = async ({
    token,
    permission,
    platform,
    language,
    sessionID,
}: VerifyUserAccess): Promise<{
    success: boolean;
    error?: string;
    user?: IUserDoc;
}> => {
    try {
        const decoded = verify(token, process.env.JWT_SECRET) as unknown as SignUserToken;
        const permissionArray = permission?.split('-') || [];
        const module = permissionArray[0] as unknown as string;

        if (!decoded?.sub || decoded.aud !== platform) {
            return {
                success: false,
                error: __(language, 'UNAUTHORIZED'),
            };
        }

        const tokenSubArray = decoded.sub.split('-');

        const user = await UserDao.getUserById({
            id: tokenSubArray[0] as unknown as TypesObjectId,
            company: tokenSubArray[1] as unknown as TypesObjectId,
            accountType,
        });

        if (!user || !user?.company) {
            return {
                success: false,
                error: __(language, 'USER_NOT_FOUND'),
            };
        }

        const company = user.company as unknown as ICompanyDoc;
        const isSuperAdmin = user.accountType === UserAccountType.SUPER_ADMIN;

        if (!isSuperAdmin && moment(company?.planEndDate).isBefore(moment())) {
            return {
                success: false,
                error: __(language, 'COMPANY_SUBSCRIPTION_EXPIRED'),
            };
        }

        if (user.status === Status.INACTIVE) {
            return {
                success: false,
                error: __(language, 'YOUR_ACCOUNT_SUSPENDED'),
            };
        }

        if (user.authTokenIssuedAt !== decoded.iat) {
            return {
                success: false,
                error: __(language, 'SESSION_EXPIRED'),
            };
        }

        if (process.env.VALIDATE_SESSION === 'true' && sessionID && sessionID !== decoded.sessionID) {
            return {
                success: false,
                error: __(language, 'INVALID_SESSION'),
            };
        }

        const permissions = user.permissions || [];
        const modulePermissions = permissions[module] || [];

        if (process.env.VALIDATE_PERMISSION === 'true' && !isSuperAdmin && permission && !modulePermissions.length) {
            return {
                success: false,
                error: __(language, 'UNAUTHORIZED'),
            };
        }

        if (
            process.env.VALIDATE_PERMISSION === 'true' &&
            !isSuperAdmin &&
            permission &&
            !modulePermissions.includes(permission)
        ) {
            return {
                success: false,
                error: __(language, 'UNAUTHORIZED'),
            };
        }

        user.company = user.company._id;

        return {
            success: true,
            user,
        };
    } catch (e) {
        if (e) {
            return {
                success: false,
                error: __(language, 'UNAUTHORIZED'),
            };
        }
    }

    return {
        success: false,
        error: __(language, 'UNAUTHORIZED'),
    };
};

export const verifyToken = (permission?: string) =>
    (async (req: Request, res: Response, next: NextFunction) => {
        const token = <string>(req.headers.authorization || req.query.state);
        const platform = req.url.includes('sso') ? Platform.web : getPlatform(req);
        const language = getLanguage(req);
        const response = await verifyUserAccess({
            token,
            permission,
            platform,
            language,
            sessionID: req.sessionID,
        });

        if (!response.success || !response.user) {
            logger.error('verifyToken:: authentication error', response.error);
            return res.unauthorized(null, response.error);
        }

        req.user = response.user;
        next();
    }) as RequestHandler;
