import {
    ICompany,
    Status,
    TypesObjectId,
    AddOnServices,
    SubscriptionPaymentStatus,
    PaymentMode,
    ISubscriptionPayment,
} from '@homelead-shared-api';

export interface GetCompanies {
    status?: Status;
    search?: string;
}
export interface GetSubscriptionPayment {
    company?: TypesObjectId;
    paymentStatus?: SubscriptionPaymentStatus;
    paymentMode?: PaymentMode;
    search?: string;
}

export interface GetCompanyBySubDomain {
    subDomain: string;
    id?: TypesObjectId;
}

export interface ICreateCompany extends ICompany {
    onboardingRequest?: TypesObjectId;
    subscriptionPaymentStatus: SubscriptionPaymentStatus;
    paymentMode: PaymentMode;
    transactionRefNo?: string;
    remarks?: string;
}

export interface IUpGradePlan {
    plan: TypesObjectId;
    maxNoOfUsers?: number;
    addOnServices?: AddOnServices[];
    amountPaid: number;
    subscriptionPaymentStatus: SubscriptionPaymentStatus;
    paymentMode: PaymentMode;
    transactionRefNo?: string;
    remarks?: string;
    planStartDate?: Date;
    planEndDate?: Date;
}

export interface GetPlanExpiredCompanies {
    startDate: Date;
    endDate: Date;
}

export interface ISubscriptionPayments extends ISubscriptionPayment {
    _id: TypesObjectId;
}
