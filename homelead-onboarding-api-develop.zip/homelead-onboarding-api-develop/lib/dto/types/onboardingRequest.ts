import { OnboardingStatus } from '@homelead-shared-api';

export interface GetOnboardingRequests {
    search?: string;
    onboardingStatus?: OnboardingStatus;
}

export interface IOnboardingStatus {
    onboardingStatus: OnboardingStatus;
}
