import { Status } from '@homelead-shared-api';

export interface GetPlans {
    search?: string;
    status?: Status;
}

export interface GetBySlug {
    slug: string;
}
