import { Platform, TypesObjectId, CommonId, IUser } from '@homelead-shared-api';
import { Languages } from '@dto';

export interface EmailAddress {
    email: string;
}

export interface CountryCodeAndPhone {
    countryCode: string;
    phone: string;
}

export interface GetUserByEmail extends EmailAddress {
    id?: TypesObjectId;
    company?: TypesObjectId;
}

export interface GetUserByPhone extends CountryCodeAndPhone {
    id?: TypesObjectId;
    company?: TypesObjectId;
}

export interface UpdateUser extends CommonId {
    company?: TypesObjectId;
    data: Partial<IUser>;
}

export interface SignToken {
    sub: string;
    iat: number;
    sessionID: string;
}

export interface SignUserToken extends SignToken {
    aud: Platform;
}

export interface VerifyUserAccess {
    platform: Platform;
    language: Languages;
    token: string;
    permission?: string;
    sessionID?: string;
}
