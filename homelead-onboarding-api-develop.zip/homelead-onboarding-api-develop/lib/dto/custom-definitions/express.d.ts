import { IUserDoc, ResponseTypes } from '@homelead-shared-api';

declare global {
    namespace Express {
        interface Request {
            __: (key: string, ...params: string[]) => string;
            user: IUserDoc;
        }
        interface Response extends ResponseTypes {}
    }
}
export {};
