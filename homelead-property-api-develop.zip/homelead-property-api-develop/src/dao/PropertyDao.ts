import { ExportCSVProperty, GetAvailableUnits, GetProperties, UpdateProperty } from '@dto';
import {
    CommonId,
    CompanyId,
    getSearchRegex,
    IProperty,
    IPropertyDoc,
    mongoose,
    Project,
    Property,
    Status,
    IProjectDoc,
    Pagination,
    TypesObjectId,
} from '@homelead-shared-api';

type FilterQueryIProperty = mongoose.FilterQuery<IProperty>;

class PropertyDao {
    async getAll({
        company,
        page,
        perPage,
        search,
        status,
        bhk,
        bhkType,
        propertyUnitSubType,
        budgetRange,
    }: GetProperties & Pagination): Promise<ExportCSVProperty[]> {
        const matchCriteria: FilterQueryIProperty = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ propertyType: { $regex: searchRegex } }];
        }

        if (propertyUnitSubType) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { propertyUnitSubType }];
        }

        if (bhk) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { bhk }];
        }

        if (bhkType) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { bhkType }];
        }

        if (budgetRange) {
            matchCriteria.$or = [
                ...(matchCriteria.$or || []),
                { $and: [{ minBudget: { $lte: budgetRange } }, { maxBudget: { $gte: budgetRange } }] },
            ];
        }

        return Property.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .select(
                'propertyType propertyUnitSubType bhk bhkType blockName floor flatNo carpetArea minBudget maxBudget status'
            )
            .populate([
                { path: 'bhk', select: 'name' },
                { path: 'bhkType', select: 'name' },
                { path: 'propertyUnitSubType', select: 'name' },
            ])
            .sort({
                _id: -1,
            });
    }

    async countAll({
        company,
        search,
        status,
        bhk,
        bhkType,
        propertyUnitSubType,
        budgetRange,
    }: GetProperties): Promise<number> {
        const matchCriteria: FilterQueryIProperty = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ propertyType: { $regex: searchRegex } }];
        }

        if (propertyUnitSubType) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { propertyUnitSubType }];
        }

        if (bhk) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { bhk }];
        }

        if (bhkType) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { bhkType }];
        }

        if (budgetRange) {
            matchCriteria.$or = [
                ...(matchCriteria.$or || []),
                { $and: [{ minBudget: { $lte: budgetRange } }, { maxBudget: { $gte: budgetRange } }] },
            ];
        }

        return Property.countDocuments(matchCriteria);
    }

    async getInventory({
        company,
        project,
        search,
        facing,
        propertyType,
        propertyUnitSubType,
    }: GetAvailableUnits & CompanyId): Promise<IProperty[]> {
        const matchCriteria: FilterQueryIProperty = {
            company,
            project,
            status: { $ne: Status.ARCHIVED },
        };

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { blockName: { $regex: searchRegex } },
                { floorName: { $regex: searchRegex } },
                { series: { $regex: searchRegex } },
                { flatNo: { $regex: searchRegex } },
                { shopNo: { $regex: searchRegex } },
            ];
        }

        if (facing) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { facing }];
        }

        if (propertyUnitSubType) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { propertyUnitSubType }];
        }

        if (propertyType) {
            matchCriteria.$or = [...(matchCriteria.$or || []), { propertyType }];
        }

        return Property.find(matchCriteria)
            .populate([
                { path: 'bhk', select: 'name' },
                { path: 'bhkType', select: 'name' },
                { path: 'propertyUnitSubType', select: 'name' },
            ])
            .sort({
                _id: -1,
            });
    }

    async create(property: IProperty): Promise<IPropertyDoc> {
        return Property.create(property);
    }

    async bulkCreate(properties: IProperty[]): Promise<IPropertyDoc[]> {
        return Property.insertMany(properties);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IPropertyDoc | null> {
        return Property.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async detailsById({ id, company }: CommonId & CompanyId): Promise<IPropertyDoc | null> {
        return Property.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        }).populate([
            {
                path: 'project',
                select: 'name',
            },
            {
                path: 'bhk',
                select: 'name',
            },
            {
                path: 'bhkType',
                select: 'name',
            },
            {
                path: 'propertyUnitSubType',
                select: 'name',
            },
        ]);
    }

    async updateById({ id, company, data }: UpdateProperty) {
        return Property.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    getProjectById({ id, company }: CommonId & CompanyId): Promise<IProjectDoc | null> {
        return Project.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    getProjectsByIds({ ids, company }: { ids: TypesObjectId[] } & CompanyId): Promise<IProjectDoc[]> {
        return Project.find({
            _id: {
                $in: ids,
            },
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }
}

export default new PropertyDao();
