import { AreaType, commonValidations, Facing, FurnishedStatus, joi, PropertyType } from '@homelead-shared-api';

const create = joi.object().keys({
    project: commonValidations.id,
    propertyType: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyType))
        .required(),
    propertyUnitSubType: commonValidations.id.optional().allow(''),
    bhk: commonValidations.id.optional().allow(''),
    bhkType: commonValidations.id.optional().allow(''),
    blockName: joi.string().trim().required(),
    floorName: joi.string().trim().required(),
    series: joi.string().trim().required(),
    flatNo: joi.string().trim().optional().allow(''),
    shopNo: joi.string().trim().optional().allow(''),
    furnishedStatus: joi
        .string()
        .trim()
        .valid(...Object.values(FurnishedStatus))
        .optional()
        .allow(''),
    minBudget: joi.number().positive().required(),
    maxBudget: joi.number().positive().min(joi.ref('minBudget')).required(),
    facing: joi
        .string()
        .trim()
        .valid(...Object.values(Facing))
        .optional()
        .allow(''),
    vastuCompliant: joi.boolean().optional().allow(''),
    carpetArea: joi.number().positive().optional().allow(''),
    builtUpArea: joi.number().positive().optional().allow(''),
    superBuiltUpArea: joi.number().positive().optional().allow(''),
    carpetAreaType: joi
        .string()
        .trim()
        .valid(...Object.values(AreaType))
        .optional()
        .allow(''),
    builtUpAreaType: joi
        .string()
        .trim()
        .valid(...Object.values(AreaType))
        .optional()
        .allow(''),
    superBuiltUpAreaType: joi
        .string()
        .trim()
        .valid(...Object.values(AreaType))
        .optional()
        .allow(''),
    noOfBalconies: joi.number().min(0).optional().allow(''),
    noOfBathRooms: joi.number().min(0).optional().allow(''),
    noOfBedRooms: joi.number().min(0).optional().allow(''),
    noOfKitchens: joi.number().min(0).optional().allow(''),
    noOfDrawingRooms: joi.number().min(0).optional().allow(''),
    noOfParkingLots: joi.number().min(0).optional().allow(''),
    images: joi.array().items(joi.string().trim()).optional().allow(''),
    about: joi.string().trim().optional().allow(''),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

const getInventory = joi.object().keys({
    project: commonValidations.id,
    search: joi.string().trim().optional(),
    propertyType: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyType))
        .optional(),
    propertyUnitSubType: commonValidations.id.optional(),
    facing: joi
        .string()
        .trim()
        .valid(...Object.values(Facing))
        .optional(),
});

const getAll = joi.object().keys({
    page: commonValidations.page,
    perPage: commonValidations.perPage,
    search: joi.string().trim().optional(),
    status: commonValidations.status.optional(),
    bhk: commonValidations.id.optional(),
    bhkType: commonValidations.id.optional(),
    propertyUnitSubType: commonValidations.id.optional(),
    budgetRange: joi.number().positive().optional(),
});

const csv = joi
    .array()
    .items(
        create.keys({
            company: commonValidations.id,
        })
    )
    .required();

const importCsv = joi.object().keys({
    key: joi.string().trim().required(),
});

export default {
    create,
    requiredId,
    updateStatus,
    getAll,
    getInventory,
    csv,
    importCsv,
};
