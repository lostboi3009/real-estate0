export { router } from './PropertyRoutes';
