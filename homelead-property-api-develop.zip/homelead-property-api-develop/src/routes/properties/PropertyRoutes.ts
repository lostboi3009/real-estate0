import { RequestHandler, Router } from 'express';
import PropertyService from './PropertyService';
import PropertyValidations from './PropertyValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.PROPERTIES_LIST),
    validate(PropertyValidations.getAll, 'query'),
    PropertyService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.PROPERTIES_ADD),
    validate(PropertyValidations.create),
    PropertyService.create as RequestHandler
);

router.get(
    '/inventory',
    verifyToken(UserPermissions.PROPERTIES_LIST_INVENTORIES),
    validate(PropertyValidations.getInventory, 'query'),
    PropertyService.getInventory as RequestHandler
);

router.post(
    '/import-csv',
    verifyToken(UserPermissions.PROPERTIES_IMPORT),
    validate(PropertyValidations.importCsv),
    PropertyService.importCsv as unknown as RequestHandler
);

router.get(
    '/export-pdf',
    verifyToken(UserPermissions.PROPERTIES_EXPORT_PDF),
    PropertyService.exportPdf as RequestHandler
);

router.get(
    '/export-csv',
    verifyToken(UserPermissions.PROPERTIES_EXPORT_CSV),
    PropertyService.exportCsv as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.PROPERTIES_VIEW),
    validate(PropertyValidations.requiredId, 'params'),
    PropertyService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.PROPERTIES_UPDATE),
    validate(PropertyValidations.requiredId, 'params'),
    validate(PropertyValidations.create),
    PropertyService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.PROPERTIES_DELETE),
    validate(PropertyValidations.requiredId, 'params'),
    PropertyService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.PROPERTIES_UPDATE),
    validate(PropertyValidations.requiredId, 'params'),
    validate(PropertyValidations.updateStatus),
    PropertyService.updateStatus as RequestHandler
);

export { router };
