import { Request, Response } from 'express';
import {
    Status,
    CommonId,
    CommonStatus,
    IProperty,
    Pagination,
    jsonToCsvBuffer,
    csvToJson,
    TypesObjectId,
} from '@homelead-shared-api';
import { GetAvailableUnits, GetProperties } from '@dto';
import { exportPdf, getLanguage } from '../../utils/common';
import PropertyDao from '../../dao/PropertyDao';
import { csvValidate } from '../../utils/validations';
import PropertyValidations from './PropertyValidations';

class PropertyService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, search, status, bhk, bhkType, propertyUnitSubType, budgetRange } =
            req.query as unknown as GetProperties & Pagination;

        const [count, properties] = await Promise.all([
            PropertyDao.countAll({
                company,
                search,
                status,
                bhk,
                bhkType,
                propertyUnitSubType,
                budgetRange,
            }),
            PropertyDao.getAll({
                company,
                page,
                perPage,
                search,
                status,
                bhk,
                bhkType,
                propertyUnitSubType,
                budgetRange,
            }),
        ]);

        return res.success({
            count,
            properties,
        });
    }

    async getInventory(req: Request, res: Response) {
        const { company } = req.user;
        const { project, search, facing, propertyType, propertyUnitSubType } =
            req.query as unknown as GetAvailableUnits;

        const availableFlats = await PropertyDao.getInventory({
            company,
            project,
            search,
            facing,
            propertyType,
            propertyUnitSubType,
        });

        return res.success(availableFlats);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const property: IProperty = req.body;

        const project = await PropertyDao.getProjectById({ id: property.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const response = await PropertyDao.create({
            ...property,
            company,
        });

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const property = await PropertyDao.detailsById({ id, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        return res.success(property);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: IProperty = req.body;

        const property = await PropertyDao.getById({ id, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const project = await PropertyDao.getProjectById({ id: data.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        await PropertyDao.updateById({ id, company, data });

        return res.success(null, req.__('PROPERTY_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IProperty> = {
            status: Status.ARCHIVED,
        };

        const property = await PropertyDao.getById({ id, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        await PropertyDao.updateById({ id, company, data });

        return res.success(null, req.__('PROPERTY_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const property = await PropertyDao.getById({ id, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        await PropertyDao.updateById({ id, company, data });

        return res.success(null, req.__('PROPERTY_STATUS_UPDATED'));
    }

    async exportCsv(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, search, status, bhk, bhkType, propertyUnitSubType, budgetRange } =
            req.query as unknown as GetProperties & Pagination;

        const properties = await PropertyDao.getAll({
            company,
            page,
            perPage,
            search,
            status,
            bhk,
            bhkType,
            propertyUnitSubType,
            budgetRange,
        });

        if (!properties) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const filteredProperties = properties.map(property => ({
            propertyType: property.propertyType,
            propertyUnitSubType: property?.propertyUnitSubType?.name,
            blockName: property.blockName,
            minBudget: property.minBudget,
            maxBudget: property.maxBudget,
        }));

        const csv = jsonToCsvBuffer(filteredProperties, {
            excelBOM: true,
        });

        res.header('Content-Type', 'text/csv');
        res.attachment('properties.csv');
        return res.send(csv);
    }

    async exportPdf(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, search, status, bhk, bhkType, propertyUnitSubType, budgetRange } =
            req.query as unknown as GetProperties & Pagination;

        const properties = await PropertyDao.getAll({
            company,
            page,
            perPage,
            search,
            status,
            bhk,
            bhkType,
            propertyUnitSubType,
            budgetRange,
        });

        if (!properties) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const pdfBuffer = await exportPdf('export-properties.ejs', properties);

        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="lands.pdf"');
        return res.send(pdfBuffer);
    }

    async importCsv(req: Request, res: Response) {
        const { key } = req.body;
        const { company } = req.user;

        const csvJson = await csvToJson<IProperty[]>(key, { company });

        const { error, data } = await csvValidate(PropertyValidations.csv, csvJson, getLanguage(req));

        if (error) {
            return res.badRequest(null, error);
        }

        const uniqueProjectIds = [
            ...new Set(data?.map((item: IProperty) => item && (item.project as unknown as TypesObjectId))),
        ] as unknown as TypesObjectId[];

        const projects = await PropertyDao.getProjectsByIds({
            ids: uniqueProjectIds,
            company,
        });

        if (projects.length !== uniqueProjectIds.length) {
            return res.warn(null, req.__('PROJECT_NOT_FOUND'));
        }

        await PropertyDao.bulkCreate(data);

        return res.success(null, 'CSV_IMPORT_SUCCESSFULLY');
    }
}

export default new PropertyService();
