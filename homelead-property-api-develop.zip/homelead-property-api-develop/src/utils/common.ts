import { Request } from 'express';
import fs from 'fs';
import path from 'path';
import { Languages } from '@dto';
import { ejsTemplateToPdfBuffer, Platform } from '@homelead-shared-api';

export const getLanguage = (req: Request) => (req.headers['accept-language'] ?? 'en') as Languages;

export const getPlatform = (req: Request) => req.headers['x-platform'] as Platform;

export const exportPdf = async (template: string, data: object[]) => {
    const templatePath = path.join(__dirname, '..', 'views', template);
    const templateContent = fs.readFileSync(templatePath, 'utf-8');

    const pdfBuffer = await ejsTemplateToPdfBuffer(templateContent, data);

    return pdfBuffer;
};
