import { Express } from 'express';
import session from 'express-session';
import MongoStore from 'connect-mongo';

export const useSessions = () =>
    session({
        name: 'user',
        cookie: {
            path: '/',
            maxAge: Number(process.env.SESSION_VALIDITY_DAYS || 15) * 86400000,
            secure: process.env.NODE_ENV === 'production',
        },
        resave: false,
        saveUninitialized: true,
        secret: process.env.SESSION_SECRET,
        store: new MongoStore({
            mongoUrl: process.env.MONGO_URI,
            collectionName: 'user-sessions',
            autoRemove: 'interval',
            autoRemoveInterval: 60,
        }),
    });

export const sessions = (app: Express) => {
    app.use(useSessions());
};
