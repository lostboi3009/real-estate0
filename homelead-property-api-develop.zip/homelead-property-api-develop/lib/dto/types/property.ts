import {
    CommonId,
    CompanyId,
    Facing,
    IProperty,
    IPropertyDoc,
    PropertyType,
    Status,
    TypesObjectId,
} from '@homelead-shared-api';

export interface GetProperties extends CompanyId {
    search?: string;
    status?: Status;
    bhk?: string;
    bhkType?: string;
    propertyUnitSubType?: string;
    budgetRange?: number;
}

export interface UpdateProperty extends CommonId, CompanyId {
    data: Partial<IProperty>;
}

export interface GetAvailableUnits {
    project: TypesObjectId;
    search?: string;
    facing?: Facing;
    propertyType?: PropertyType;
    propertyUnitSubType?: TypesObjectId;
}

export interface ExportCSVProperty extends Omit<IPropertyDoc, 'propertyUnitSubType'> {
    propertyUnitSubType?: {
        _id?: TypesObjectId;
        name?: string;
    };
}
