import { RequestHandler, Router } from 'express';
import LeadService from './LeadService';
import { validate } from '../../utils/validations';
import LeadValidations from './LeadValidations';

const router = Router();

router.get('/generate/:company', validate(LeadValidations.create), LeadService.createLead as RequestHandler);

export { router };
