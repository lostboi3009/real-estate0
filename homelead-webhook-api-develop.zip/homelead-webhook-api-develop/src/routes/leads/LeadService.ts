import { Request, Response } from 'express';
import { CommunicationType, CompanyId } from '@homelead-shared-api';
import { CreateLead } from '@dto';
import CompanyDao from '../../dao/CompanyDao';
import LeadDao from '../../dao/LeadDao';

class LeadService {
    async createLead(req: Request, res: Response) {
        const { company } = req.params as unknown as CompanyId;
        const { virtual_number, customer_number, receiver_number, call_date, duration, recording_path } =
            req.query as unknown as CreateLead;

        const companyData = await CompanyDao.getById({ company });

        if (!companyData) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        const leadCount = await LeadDao.getNextLeadNumber();

        // TODO: countryCode: need to get it from the IVR,
        // TODO: maxBudget: Need to get from the IVR
        // TODO: minBudget: Need to get from the IVR
        // TODO: buyingTimeLine: Need to get from the IVR
        // TODO: for now create new lead on every ivr call

        const lead = await LeadDao.createLead({
            company,
            countryCode: '+91',
            minBudget: 0,
            maxBudget: 0,
            name: customer_number,
            phone: customer_number,
            leadNo: `#${leadCount?.counts?.lead || 0}`,
        });

        await LeadDao.createLeadNote({
            company,
            lead: lead._id,
            callDate: call_date,
            callDuration: duration,
            receiverPhone: receiver_number,
            fileLink: recording_path,
            virtualPhone: virtual_number,
            communicationType: CommunicationType.CALL,
        });

        return res.success(null);
    }
}

export default new LeadService();
