import { joi } from '@homelead-shared-api';

const create = joi.object().keys({
    virtual_number: joi.string().trim().required(),
    customer_number: joi.string().trim().required(),
    receiver_number: joi.string().trim().required(),
    call_date: joi.date().required(),
    duration: joi.string().trim().required(),
    recording_path: joi.string().trim().required(),
});

export default {
    create,
};
