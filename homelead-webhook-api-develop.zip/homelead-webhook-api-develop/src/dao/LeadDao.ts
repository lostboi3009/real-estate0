import { Counter, ICounterDoc, ILead, ILeadDoc, ILeadNote, ILeadNoteDoc, Lead, LeadNote } from '@homelead-shared-api';

class LeadDao {
    async createLead(lead: Partial<ILead>): Promise<ILeadDoc> {
        return Lead.create(lead);
    }

    async createLeadNote(leadNote: Partial<ILeadNote>): Promise<ILeadNoteDoc> {
        return LeadNote.create(leadNote);
    }

    async getNextLeadNumber(): Promise<ICounterDoc> {
        return Counter.findOneAndUpdate({}, { $inc: { 'counts.lead': 1 } }, { new: true, upsert: true });
    }
}

export default new LeadDao();
