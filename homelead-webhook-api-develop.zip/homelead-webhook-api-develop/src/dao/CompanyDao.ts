import { Company, CompanyId, ICompany, Status } from '@homelead-shared-api';

class CompanyDao {
    async getById({ company }: CompanyId): Promise<ICompany | null> {
        return Company.findOne(
            {
                _id: company,
                status: Status.ACTIVE,
            },
            { _id: 1 }
        );
    }
}

export default new CompanyDao();
