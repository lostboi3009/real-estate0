export interface CreateLead {
    virtual_number: string;
    customer_number: string;
    receiver_number: string;
    call_date: Date;
    duration: string;
    recording_path: string;
}
