import type { Session, SessionData } from 'express-session';
import type { Languages } from '@dto';
import type { IUser } from '@homelead-shared-api';

declare module 'node:http' {
    interface IncomingMessage {
        session: Session &
            Partial<SessionData> & {
                token?: string | null;
                timeZone?: string | null;
                language?: Languages;
                user?: IUser;
            };
    }
}
