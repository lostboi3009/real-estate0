import { Platform } from '@homelead-shared-api';
import { Languages } from '@dto';

export interface SignToken {
    sub: string;
    iat: number;
    sessionID: string;
}

export interface SignUserToken extends SignToken {
    aud: Platform;
}

export interface VerifyUserAccess {
    platform: Platform;
    language: Languages;
    token: string;
    permission?: string;
    sessionID?: string;
}
