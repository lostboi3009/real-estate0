import { BankAccountType, Status, CommonId, CompanyId, IBroker, TypesObjectId } from '@homelead-shared-api';

export interface INewBroker {
    company: TypesObjectId;
    name: string;
    countryCode: string;
    phone: string;
    country: TypesObjectId;
    city: TypesObjectId;
    state: TypesObjectId;
    address: string;
    zipCode: string;
    aadharNo: string;
    panNo: string;
    bankDetails: {
        bankNameId: TypesObjectId;
        bankAccountType: BankAccountType;
        accountNo: number;
        ifscCode: string;
        swiftCode: string;
    };
    realEstateLicenseDetails?: {
        licenseNo?: string;
        licenseIssueDate?: Date;
        licenseExpirationDate?: Date;
    };
    yearStartedInRealEstate?: number;
    status: Status;
}

export interface UpdateBroker extends CommonId, CompanyId {
    data: Partial<IBroker>;
}
