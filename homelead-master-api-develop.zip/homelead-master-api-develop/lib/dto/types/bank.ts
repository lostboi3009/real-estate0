import { CommonId, CompanyId, IBank, TypesObjectId } from '@homelead-shared-api';

export interface BankData {
    bankNameId: TypesObjectId;
    branchName: string;
    branchAddress: string;
    company: TypesObjectId;
    ifscCode: string;
    swiftCode: string;
    contactPersonDetails: {
        fullName: string;
        countryCode: string;
        phone: string;
        designation: string;
    };
}

export interface UpdateBank extends CommonId, CompanyId {
    data: Partial<IBank>;
}
