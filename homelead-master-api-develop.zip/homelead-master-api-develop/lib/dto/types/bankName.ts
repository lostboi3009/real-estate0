export interface BankName {
    name: string;
}
