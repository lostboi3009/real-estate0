import { I18n, ValidationKeys, ValidationMessages, Validations } from '@dto';

const validationKeys: ValidationKeys = Object.freeze({
    name: 'Name',
    firstName: 'First name',
    lastName: 'Last name',
    fullName: 'Full name',
    email: 'Email',
    countryCode: 'Country code',
    phone: 'Phone',
    emailToken: 'Email token',
    phoneToken: 'Phone token',
    emailPattern: 'must be a valid email.',
    semanticPattern: 'must be a valid version.',
    countryCodePattern: 'must be a valid country code.',
    phonePattern: 'must be a valid phone.',
    timeIn24Hours: 'must be a valid time.',
    page: 'Page',
    perPage: 'Per page',
});

const validationMessages: ValidationMessages = Object.freeze({
    NOT_AVAILABLE: 'N/A',
    VIEW: 'View',
    EDIT: 'Edit',
    DELETE: 'Delete',
    REMOVE: 'Remove',
    ACTIVATE: 'Activate',
    IN_ACTIVATE: 'In-activate',
    HEALTH_CHECK: 'Health check',
    NOT_FOUND: 'Resource not found.',
    GENERAL_ERROR: 'Something went wrong.',
    INVALID_REQUEST: 'Invalid request, request validation failed.',
    EMAIL_ALREADY_FOUND: 'Email address already exists.',
    PHONE_ALREADY_FOUND: 'Phone already exists.',
    USER_NOT_FOUND: 'User not found.',
    YOUR_ACCOUNT_SUSPENDED: 'Your account is suspended.',
    UNAUTHORIZED: 'Unauthorized access.',
    SESSION_EXPIRED: 'Session expired.',
    INVALID_SESSION: 'Invalid session.',
    BANK_NAME_NOT_FOUND: 'Bank name not found.',
    BANK_NAME_UPDATE_SUCCESS: 'Bank name updated successfully.',
    BANK_NAME_DELETE_SUCCESS: 'Bank name deleted successfully.',
    BANK_NAME_STATUS_UPDATED: 'Bank name status updated successfully.',
    BANK_NOT_FOUND: 'Bank name not found.',
    BANK_UPDATE_SUCCESS: 'Bank name updated successfully.',
    BANK_DELETE_SUCCESS: 'Bank name deleted successfully.',
    BANK_STATUS_UPDATED: 'Bank name status updated successfully.',
    AMENITY_NOT_FOUND: 'Amenity not found.',
    AMENITY_UPDATE_SUCCESS: 'Amenity updated successfully',
    AMENITY_DELETE_SUCCESS: 'Amenity deleted successfully',
    AMENITY_STATUS_UPDATED: 'Amenity status updated successfully',
    PROJECT_CATEGORY_NOT_FOUND: 'Project category not found.',
    PROJECT_CATEGORY_UPDATE_SUCCESS: 'Project category updated successfully.',
    PROJECT_CATEGORY_DELETE_SUCCESS: 'Project category deleted successfully.',
    PROJECT_CATEGORY_STATUS_UPDATED: 'Project category status updated successfully.',
    DESIGNATION_NOT_FOUND: 'Designation not found.',
    DESIGNATION_UPDATE_SUCCESS: 'Designation updated successfully.',
    DESIGNATION_DELETE_SUCCESS: 'Designation deleted successfully.',
    DESIGNATION_STATUS_UPDATED: 'Designation status updated successfully.',
    BHK_NOT_FOUND: 'Bhk not found.',
    BHK_UPDATE_SUCCESS: 'Bhk updated successfully.',
    BHK_DELETE_SUCCESS: 'Bhk deleted successfully.',
    BHK_STATUS_UPDATED: 'Bhk status updated successfully.',
    BHK_TYPE_NOT_FOUND: 'Bhk Type not found.',
    BHK_TYPE_UPDATE_SUCCESS: 'Bhk Type updated successfully.',
    BHK_TYPE_DELETE_SUCCESS: 'Bhk Type deleted successfully.',
    BHK_TYPE_STATUS_UPDATED: 'Bhk Type status updated successfully.',
    PROPERTY_UNIT_SUB_TYPE_NOT_FOUND: 'Property Unit Sub Type not found.',
    PROPERTY_UNIT_SUB_TYPE_UPDATE_SUCCESS: 'Property Unit Sub Type updated successfully.',
    PROPERTY_UNIT_SUB_TYPE_DELETE_SUCCESS: 'Property Unit Sub Type deleted successfully.',
    PROPERTY_UNIT_SUB_TYPE_STATUS_UPDATED: 'Property Unit Sub Type status updated successfully.',
    BROKER_NOT_FOUND: 'Broker not found.',
    BROKER_UPDATE_SUCCESS: 'Broker updated successfully.',
    BROKER_DELETE_SUCCESS: 'Broker deleted successfully.',
    BROKER_STATUS_UPDATED: 'Broker status updated successfully.',
    TAG_NOT_FOUND: 'Tag not found.',
    TAG_UPDATE_SUCCESS: 'Tag updated successfully.',
    TAG_DELETE_SUCCESS: 'Tag deleted successfully.',
    TAG_STATUS_UPDATED: 'Tag status updated successfully.',
    NEAR_BY_LOCATION_NOT_FOUND: 'Near by location not found.',
    NEAR_BY_LOCATION_UPDATE_SUCCESS: 'Near by location updated successfully.',
    NEAR_BY_LOCATION_DELETE_SUCCESS: 'Near by location deleted successfully.',
    NEAR_BY_LOCATION_STATUS_UPDATED: 'Near by location status updated successfully.',
    COMPANY_SUBSCRIPTION_EXPIRED: 'Company subscription ended',
});

const formatKeyName = (keyName: string): string => validationKeys[keyName.replace(/\.\d+/, '')] ?? keyName;

const validations: Validations = {
    'any.required': ({ path }) => `${formatKeyName(path.join('.'))} is required.`,
    'any.unknown': ({ path }) => `${formatKeyName(path.join('.'))} is not allowed.`,
    'any.invalid': ({ path }) => `${formatKeyName(path.join('.'))} contains an invalid value.`,
    'any.empty': ({ path }) => `${formatKeyName(path.join('.'))} is required.`,
    'any.allowOnly': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be one of ${context?.valids?.map((item: string) => formatKeyName(item)).join(', ')}`,
    'string.base': ({ path }) => `${formatKeyName(path.join('.'))} must be a string`,
    'string.min': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be at least ${context?.limit} characters in length.`,
    'string.max': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be under ${context?.limit} characters in length.`,
    'string.hex': ({ path }) => `${formatKeyName(path.join('.'))} must only contain hexadecimal characters.`,
    'string.length': ({ path }) => `${formatKeyName(path.join('.'))} length must be 4 characters long.`,
    'string.pattern.name': ({ path, context }) => `${formatKeyName(path.join('.'))} ${formatKeyName(context?.name)}`,
    'number.base': ({ path }) => `${formatKeyName(path.join('.'))} must be a number`,
    'number.min': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be larger than or equal to ${context?.limit}.`,
    'number.max': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be less than or equal to ${context?.limit}.`,
    'number.integer': ({ path }) => `${formatKeyName(path.join('.'))} must be an integer number.`,
    'objectId.isValid': ({ path }) => `${formatKeyName(path.join('.'))} needs to be a valid objectId`,
    'object.base': ({ path }) => `${formatKeyName(path.join('.'))} must be an object`,
    'object.xor': ({ context }) =>
        `only one of ${context?.peers?.map((peer: string) => formatKeyName(peer)).join(', ')} is allowed.`,
    'object.with': ({ context }) => `${formatKeyName(context?.peer)} is required with ${formatKeyName(context?.main)}.`,
    'object.without': ({ context }) =>
        `${formatKeyName(context?.peer)} needs to be removed with ${formatKeyName(context?.main)}.`,
    'object.and': ({ context }) =>
        `${context?.missing?.map((peer: string) => formatKeyName(peer)).join(', ')} required with ${context?.present
            .map((peer: string) => formatKeyName(peer))
            .join(', ')}.`,
    'object.missing': ({ context }) =>
        `one of ${context?.peers?.map((peer: string) => formatKeyName(peer).toLowerCase()).join(', ')} is required.`,
    'array.min': ({ path, context }) =>
        `${formatKeyName(path.join('.'))} must contain at least ${context?.limit} items.`,
    'array.max': ({ path, context }) =>
        `${formatKeyName(path.join('.'))} must contain at most ${context?.limit} items.`,
    'array.unique': ({ path }) => `${formatKeyName(path.join('.'))} must contain a unique value.`,
};

const i18n: I18n = {
    validationKeys,
    validationMessages,
    validations,
};

export default i18n;
