import { CommonId, Designation, IDesignation, IDesignationDoc, Status } from '@homelead-shared-api';

class DesignationDao {
    async getAll(): Promise<IDesignationDoc[]> {
        return Designation.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeDesignations(): Promise<IDesignationDoc[]> {
        return Designation.find({
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(designation: IDesignation): Promise<IDesignationDoc> {
        return Designation.create(designation);
    }

    async getById({ id }: CommonId): Promise<IDesignationDoc | null> {
        return Designation.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<IDesignation> }) {
        return Designation.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new DesignationDao();
