import { Page, IPageDoc, Status, ICountry, ICountryDoc, Country, mongoose } from '@homelead-shared-api';

type FilterQueryICountry = mongoose.FilterQuery<ICountry>;

class CommonDao {
    async getStaticPage(slug: string): Promise<IPageDoc | null> {
        return Page.findOne({
            slug,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getAllCountries(matchCriteria: FilterQueryICountry): Promise<ICountryDoc[]> {
        return Country.find(matchCriteria);
    }
}

export default new CommonDao();
