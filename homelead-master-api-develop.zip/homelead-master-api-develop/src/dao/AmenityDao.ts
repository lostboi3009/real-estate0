import { Amenity, IAmenity, IAmenityDoc, Status, CommonId } from '@homelead-shared-api';

class AmenityDao {
    async getAll(): Promise<IAmenityDoc[]> {
        return Amenity.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeAmenities(): Promise<IAmenityDoc[]> {
        return Amenity.find({
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(amenity: IAmenity): Promise<IAmenityDoc> {
        return Amenity.create(amenity);
    }

    async getById({ id }: CommonId): Promise<IAmenityDoc | null> {
        return Amenity.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<IAmenity> }) {
        return Amenity.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new AmenityDao();
