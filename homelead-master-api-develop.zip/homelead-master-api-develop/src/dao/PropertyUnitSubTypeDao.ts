import {
    PropertyUnitSubType,
    Status,
    CommonId,
    IPropertyUnitSubType,
    IPropertyUnitSubTypeDoc,
} from '@homelead-shared-api';

class PropertyUnitSubTypeDao {
    async getAll(): Promise<IPropertyUnitSubTypeDoc[]> {
        return PropertyUnitSubType.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activePropertyUnitSubTypes(): Promise<IPropertyUnitSubTypeDoc[]> {
        return PropertyUnitSubType.find({
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(name: IPropertyUnitSubType): Promise<IPropertyUnitSubTypeDoc> {
        return PropertyUnitSubType.create(name);
    }

    async getById({ id }: CommonId): Promise<IPropertyUnitSubTypeDoc | null> {
        return PropertyUnitSubType.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<IPropertyUnitSubTypeDoc> }) {
        return PropertyUnitSubType.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new PropertyUnitSubTypeDao();
