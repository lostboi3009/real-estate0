import { User, CommonId, CompanyId, IUserDoc, Status, AccountType } from '@homelead-shared-api';

class UserDao {
    getUserById({ id, company, accountType }: CommonId & CompanyId & AccountType): Promise<IUserDoc | null> {
        return User.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: {
                $in: accountType,
            },
        }).populate({
            path: 'company',
            match: {
                status: Status.ACTIVE,
            },
        });
    }
}

export default new UserDao();
