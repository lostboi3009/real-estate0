import { CommonId, Status, INearByLocationDoc, NearByLocation, INearByLocation } from '@homelead-shared-api';

class NearByLocationDao {
    async getAll(): Promise<INearByLocationDoc[]> {
        return NearByLocation.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeNearByLocations(): Promise<INearByLocationDoc[]> {
        return NearByLocation.find({
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(nearByLocation: INearByLocation): Promise<INearByLocationDoc> {
        return NearByLocation.create(nearByLocation);
    }

    async getById({ id }: CommonId): Promise<INearByLocation | null> {
        return NearByLocation.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<INearByLocation> }) {
        return NearByLocation.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new NearByLocationDao();
