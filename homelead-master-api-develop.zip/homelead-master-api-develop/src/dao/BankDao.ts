import { Status, CommonId, IBank, Bank, IBankDoc, CompanyId } from '@homelead-shared-api';
import { UpdateBank } from '@dto';

class BankDao {
    async getAll({ company }: CompanyId): Promise<IBank[]> {
        return Bank.find({
            company,
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeBanks({ company }: CompanyId): Promise<IBankDoc[]> {
        return Bank.find({
            company,
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(bank: IBank): Promise<IBankDoc> {
        return Bank.create(bank);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IBankDoc | null> {
        return Bank.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, company, data }: UpdateBank) {
        return Bank.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new BankDao();
