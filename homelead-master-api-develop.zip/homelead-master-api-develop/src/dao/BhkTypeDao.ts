import { BhkType, Status, CommonId, IBhk, IBhkTypeDoc } from '@homelead-shared-api';

class BhkTypeDao {
    async getAll(): Promise<IBhkTypeDoc[]> {
        return BhkType.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeBhkTypes(): Promise<IBhkTypeDoc[]> {
        return BhkType.find({
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(name: IBhk): Promise<IBhkTypeDoc> {
        return BhkType.create(name);
    }

    async getById({ id }: CommonId): Promise<IBhkTypeDoc | null> {
        return BhkType.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<IBhkTypeDoc> }) {
        return BhkType.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new BhkTypeDao();
