import { Status, CommonId, ProjectCategory, IProjectCategoryDoc, IProjectCategory } from '@homelead-shared-api';

class ProjectCategoryDao {
    async getAll(): Promise<IProjectCategoryDoc[]> {
        return ProjectCategory.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeProjectCategories(): Promise<IProjectCategoryDoc[]> {
        return ProjectCategory.find({
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(projectCategory: IProjectCategory): Promise<IProjectCategoryDoc> {
        return ProjectCategory.create(projectCategory);
    }

    async getById({ id }: CommonId): Promise<IProjectCategoryDoc | null> {
        return ProjectCategory.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<IProjectCategory> }) {
        return ProjectCategory.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new ProjectCategoryDao();
