import { BankName, IBankName, IBankNameDoc, Status, CommonId } from '@homelead-shared-api';

class BankNameDao {
    async getAll(): Promise<IBankNameDoc[]> {
        return BankName.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeBankNames(): Promise<IBankNameDoc[]> {
        return BankName.find({
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(bankName: IBankName): Promise<IBankNameDoc> {
        return BankName.create(bankName);
    }

    async getById({ id }: CommonId): Promise<IBankNameDoc | null> {
        return BankName.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<IBankName> }) {
        return BankName.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new BankNameDao();
