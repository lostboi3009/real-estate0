import { Broker, CommonId, CompanyId, IBroker, IBrokerDoc, Status } from '@homelead-shared-api';
import { UpdateBroker } from '@dto';

class BrokerDao {
    async getAll({ company }: CompanyId): Promise<IBroker[]> {
        return Broker.find({
            company,
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeBrokers({ company }: CompanyId): Promise<IBrokerDoc[]> {
        return Broker.find({
            company,
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(broker: IBroker): Promise<IBrokerDoc> {
        return Broker.create(broker);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IBrokerDoc | null> {
        return Broker.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, company, data }: UpdateBroker) {
        return Broker.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new BrokerDao();
