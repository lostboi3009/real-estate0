import { Bhk, Status, CommonId, IBhkDoc, IBhk } from '@homelead-shared-api';

class BhkDao {
    async getAll(): Promise<IBhkDoc[]> {
        return Bhk.find({
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async activeBhk(): Promise<IBhkDoc[]> {
        return Bhk.find({
            status: Status.ACTIVE,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(name: IBhk): Promise<IBhkDoc> {
        return Bhk.create(name);
    }

    async getById({ id }: CommonId): Promise<IBhkDoc | null> {
        return Bhk.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data }: CommonId & { data: Partial<IBhkDoc> }) {
        return Bhk.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new BhkDao();
