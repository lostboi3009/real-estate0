import { RequestHandler, Router } from 'express';
import BhkService from './BhkService';
import BhkValidations from './BhkValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.BHKS_LIST), BhkService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.BHKS_ADD),
    validate(BhkValidations.create),
    BhkService.create as RequestHandler
);

router.get('/active-bhk', verifyToken(), BhkService.activeBhk as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.BHKS_VIEW),
    validate(BhkValidations.requiredId, 'params'),
    BhkService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.BHKS_UPDATE),
    validate(BhkValidations.requiredId, 'params'),
    validate(BhkValidations.create),
    BhkService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.BHKS_DELETE),
    validate(BhkValidations.requiredId, 'params'),
    BhkService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.BHKS_UPDATE),
    validate(BhkValidations.requiredId, 'params'),
    validate(BhkValidations.updateStatus),
    BhkService.updateStatus as RequestHandler
);

export { router };
