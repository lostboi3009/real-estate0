import { Request, Response } from 'express';
import BhkDao from '../../dao/BhkDao';
import { IBhk, Status, CommonId, CommonStatus } from '@homelead-shared-api';

class BhkService {
    async getAll(req: Request, res: Response) {
        const bhks = await BhkDao.getAll();

        return res.success(bhks);
    }

    async activeBhk(req: Request, res: Response) {
        const bhks = await BhkDao.activeBhk();

        return res.success(bhks);
    }

    async create(req: Request, res: Response) {
        const bhk: IBhk = req.body;

        const response = await BhkDao.create(bhk);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const bhk = await BhkDao.getById({ id });

        if (!bhk) {
            return res.notFound(null, req.__('BHK_NOT_FOUND'));
        }

        return res.success(bhk);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IBhk = req.body;

        const bhk = await BhkDao.getById({ id });

        if (!bhk) {
            return res.notFound(null, req.__('BHK_NOT_FOUND'));
        }

        await BhkDao.updateById({ id, data });

        return res.success(null, req.__('BHK_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IBhk> = {
            status: Status.ARCHIVED,
        };

        const bhk = await BhkDao.getById({ id });

        if (!bhk) {
            return res.notFound(null, req.__('BHK_NOT_FOUND'));
        }

        await BhkDao.updateById({ id, data });

        return res.success(null, req.__('BHK_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const bhk = await BhkDao.getById({ id });

        if (!bhk) {
            return res.notFound(null, req.__('BHK_NOT_FOUND'));
        }

        await BhkDao.updateById({ id, data });

        return res.success(null, req.__('BHK_STATUS_UPDATED'));
    }
}

export default new BhkService();
