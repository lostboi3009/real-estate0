export { router } from './BhkRoutes';
