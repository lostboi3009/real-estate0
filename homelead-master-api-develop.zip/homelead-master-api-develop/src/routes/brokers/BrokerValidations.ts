import { BankAccountType, commonValidations, joi } from '@homelead-shared-api';

const create = joi.object().keys({
    name: joi.string().trim().min(3).max(30).required(),
    countryCode: commonValidations.countryCode,
    phone: commonValidations.phone,
    country: commonValidations.id,
    city: commonValidations.id,
    state: commonValidations.id,
    address: joi.string().trim().max(200).required(),
    zipCode: joi.string().trim().max(10).required(),
    aadharNo: joi.string().trim().length(12).required(),
    panNo: joi.string().trim().length(10).required(),
    bankDetails: joi
        .object()
        .keys({
            bankNameId: commonValidations.id,
            bankAccountType: joi
                .string()
                .trim()
                .valid(...Object.values(BankAccountType))
                .required(),
            accountNo: joi.number().required(),
            ifscCode: joi.string().trim().min(3).max(30).required(),
            swiftCode: joi.string().trim().required(),
        })
        .required(),
    realEstateLicenseDetails: joi.object().keys({
        licenseNo: joi.string().trim(),
        licenseIssueDate: joi.date(),
        licenseExpirationDate: joi.date(),
    }),
    yearStartedInRealEstate: joi.number().integer().min(1900).max(new Date().getFullYear()),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    create,
    requiredId,
    updateStatus,
};
