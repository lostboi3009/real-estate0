import { Request, Response } from 'express';
import BrokerDao from '../../dao/BrokerDao';
import { CommonId, CommonStatus, IBroker, Status } from '@homelead-shared-api';
import BankNameDao from '../../dao/BankNameDao';
import { INewBroker } from '@dto';

class BrokerService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const broker = await BrokerDao.getAll({ company });

        return res.success(broker);
    }

    async activeBrokers(req: Request, res: Response) {
        const { company } = req.user;
        const brokers = await BrokerDao.activeBrokers({ company });

        return res.success(brokers);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const broker: INewBroker = req.body;

        const bankName = await BankNameDao.getById({ id: broker.bankDetails.bankNameId });

        if (!bankName) {
            return res.notFound(null, req.__('BANK_NAME_NOT_FOUND'));
        }

        const data = {
            ...broker,
            company,
            bankDetails: {
                ...broker.bankDetails,
                bankNameId: {
                    _id: bankName._id,
                    name: bankName.name,
                    icon: bankName.icon,
                },
            },
            status: Status.ACTIVE,
        };

        const response = await BrokerDao.create(data);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const broker = await BrokerDao.getById({ id, company });

        if (!broker) {
            return res.notFound(null, req.__('BROKER_NOT_FOUND'));
        }

        return res.success(broker);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: INewBroker = req.body;

        const broker = await BrokerDao.getById({ id, company });

        if (!broker) {
            return res.notFound(null, req.__('BROKER_NOT_FOUND'));
        }

        const bankName = await BankNameDao.getById({ id: data.bankDetails.bankNameId });

        if (!bankName) {
            return res.notFound(null, req.__('BANK_NAME_NOT_FOUND'));
        }

        const updatedData = {
            ...data,
            bankDetails: {
                ...data.bankDetails,
                bankNameId: {
                    _id: bankName._id,
                    name: bankName.name,
                    icon: bankName.icon,
                },
            },
            status: Status.ACTIVE,
        };

        await BrokerDao.updateById({ id, company, data: updatedData as object });

        return res.success(null, req.__('BROKER_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IBroker> = {
            status: Status.ARCHIVED,
        };

        const broker = await BrokerDao.getById({ id, company });

        if (!broker) {
            return res.notFound(null, req.__('BROKER_NOT_FOUND'));
        }

        await BrokerDao.updateById({ id, company, data });

        return res.success(null, req.__('BROKER_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const broker = await BrokerDao.getById({ id, company });

        if (!broker) {
            return res.notFound(null, req.__('BROKER_NOT_FOUND'));
        }

        await BrokerDao.updateById({ id, company, data });

        return res.success(null, req.__('BROKER_STATUS_UPDATED'));
    }
}

export default new BrokerService();
