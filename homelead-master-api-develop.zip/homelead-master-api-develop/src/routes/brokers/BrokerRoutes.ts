import { RequestHandler, Router } from 'express';
import BrokerService from './BrokerService';
import { validate } from '../../utils/validations';
import BrokerValidations from './BrokerValidations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.BROKERS_LIST), BrokerService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.BROKERS_ADD),
    validate(BrokerValidations.create),
    BrokerService.create as RequestHandler
);

router.get('/active-brokers', verifyToken(), BrokerService.activeBrokers as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.BROKERS_VIEW),
    validate(BrokerValidations.requiredId, 'params'),
    BrokerService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.BROKERS_UPDATE),
    validate(BrokerValidations.requiredId, 'params'),
    validate(BrokerValidations.create),
    BrokerService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.BROKERS_DELETE),
    validate(BrokerValidations.requiredId, 'params'),
    BrokerService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.BROKERS_UPDATE),
    validate(BrokerValidations.requiredId, 'params'),
    validate(BrokerValidations.updateStatus),
    BrokerService.updateStatus as RequestHandler
);

export { router };
