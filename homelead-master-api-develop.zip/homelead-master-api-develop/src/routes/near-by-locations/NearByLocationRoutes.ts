import { RequestHandler, Router } from 'express';
import NearByLocationService from './NearByLocationService';
import NearByLocationValidations from './NearByLocationValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.NEAR_BY_LOCATIONS_LIST), NearByLocationService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.NEAR_BY_LOCATIONS_ADD),
    validate(NearByLocationValidations.create),
    NearByLocationService.create as RequestHandler
);

router.get('/active-near-by-locations', verifyToken(), NearByLocationService.activeNearByLocations as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.NEAR_BY_LOCATIONS_VIEW),
    validate(NearByLocationValidations.requiredId, 'params'),
    NearByLocationService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.NEAR_BY_LOCATIONS_UPDATE),
    validate(NearByLocationValidations.requiredId, 'params'),
    validate(NearByLocationValidations.create),
    NearByLocationService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.NEAR_BY_LOCATIONS_DELETE),
    validate(NearByLocationValidations.requiredId, 'params'),
    NearByLocationService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.NEAR_BY_LOCATIONS_UPDATE),
    validate(NearByLocationValidations.requiredId, 'params'),
    validate(NearByLocationValidations.updateStatus),
    NearByLocationService.updateStatus as RequestHandler
);

export { router };
