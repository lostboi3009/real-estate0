import { Request, Response } from 'express';
import NearByLocationDao from '../../dao/NearByLocationDao';
import { Status, CommonId, CommonStatus, INearByLocation } from '@homelead-shared-api';

class NearByLocationService {
    async getAll(req: Request, res: Response) {
        const nearByLocations = await NearByLocationDao.getAll();

        return res.success(nearByLocations);
    }

    async activeNearByLocations(req: Request, res: Response) {
        const nearByLocations = await NearByLocationDao.activeNearByLocations();

        return res.success(nearByLocations);
    }

    async create(req: Request, res: Response) {
        const nearByLocation: INearByLocation = req.body;

        const response = await NearByLocationDao.create(nearByLocation);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const nearByLocation = await NearByLocationDao.getById({ id });

        if (!nearByLocation) {
            return res.notFound(null, req.__('NEAR_BY_LOCATION_NOT_FOUND'));
        }

        return res.success(nearByLocation);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: INearByLocation = req.body;

        const nearByLocation = await NearByLocationDao.getById({ id });

        if (!nearByLocation) {
            return res.notFound(null, req.__('NEAR_BY_LOCATION_NOT_FOUND'));
        }

        await NearByLocationDao.updateById({ id, data });

        return res.success(null, req.__('NEAR_BY_LOCATION_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<INearByLocation> = {
            status: Status.ARCHIVED,
        };

        const nearByLocation = await NearByLocationDao.getById({ id });

        if (!nearByLocation) {
            return res.notFound(null, req.__('NEAR_BY_LOCATION_NOT_FOUND'));
        }

        await NearByLocationDao.updateById({ id, data });

        return res.success(null, req.__('NEAR_BY_LOCATION_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const nearByLocation = await NearByLocationDao.getById({ id });

        if (!nearByLocation) {
            return res.notFound(null, req.__('NEAR_BY_LOCATION_NOT_FOUND'));
        }

        await NearByLocationDao.updateById({ id, data });

        return res.success(null, req.__('NEAR_BY_LOCATION_STATUS_UPDATED'));
    }
}

export default new NearByLocationService();
