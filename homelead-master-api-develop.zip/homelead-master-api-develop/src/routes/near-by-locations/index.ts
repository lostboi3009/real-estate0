export { router } from './NearByLocationRoutes';
