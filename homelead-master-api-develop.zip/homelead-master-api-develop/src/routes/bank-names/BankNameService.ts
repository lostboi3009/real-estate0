import { Request, Response } from 'express';
import BankNameDao from '../../dao/BankNameDao';
import { IBankName, Status, CommonId, CommonStatus } from '@homelead-shared-api';

class BankNameService {
    async getAll(req: Request, res: Response) {
        const bankNames = await BankNameDao.getAll();

        return res.success(bankNames);
    }

    async activeBankNames(req: Request, res: Response) {
        const bankNames = await BankNameDao.activeBankNames();

        return res.success(bankNames);
    }

    async create(req: Request, res: Response) {
        const bankName: IBankName = req.body;

        const response = await BankNameDao.create(bankName);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const bankName = await BankNameDao.getById({ id });

        if (!bankName) {
            return res.notFound(null, req.__('BANK_NAME_NOT_FOUND'));
        }

        return res.success(bankName);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IBankName = req.body;

        const bankName = await BankNameDao.getById({ id });

        if (!bankName) {
            return res.notFound(null, req.__('BANK_NAME_NOT_FOUND'));
        }

        await BankNameDao.updateById({ id, data });

        return res.success(null, req.__('BANK_NAME_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IBankName> = {
            status: Status.ARCHIVED,
        };

        const bankName = await BankNameDao.getById({ id });

        if (!bankName) {
            return res.notFound(null, req.__('BANK_NAME_NOT_FOUND'));
        }

        await BankNameDao.updateById({ id, data });

        return res.success(null, req.__('BANK_NAME_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const bankName = await BankNameDao.getById({ id });

        if (!bankName) {
            return res.notFound(null, req.__('BANK_NAME_NOT_FOUND'));
        }

        await BankNameDao.updateById({ id, data });

        return res.success(null, req.__('BANK_NAME_STATUS_UPDATED'));
    }
}

export default new BankNameService();
