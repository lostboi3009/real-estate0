import { RequestHandler, Router } from 'express';
import BankNameService from './BankNameService';
import BankNameValidations from './BankNameValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.BANKS_NAMES_LIST), BankNameService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.BANKS_NAMES_ADD),
    validate(BankNameValidations.create),
    BankNameService.create as RequestHandler
);

router.get('/active-bank-names', verifyToken(), BankNameService.activeBankNames as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.BANKS_NAMES_VIEW),
    validate(BankNameValidations.requiredId, 'params'),
    BankNameService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.BANKS_NAMES_UPDATE),
    validate(BankNameValidations.requiredId, 'params'),
    validate(BankNameValidations.create),
    BankNameService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.BANKS_DELETE),
    validate(BankNameValidations.requiredId, 'params'),
    BankNameService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.BANKS_NAMES_UPDATE),
    validate(BankNameValidations.requiredId, 'params'),
    validate(BankNameValidations.updateStatus),
    BankNameService.updateStatus as RequestHandler
);

export { router };
