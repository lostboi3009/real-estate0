export { router } from './BankNameRoutes';
