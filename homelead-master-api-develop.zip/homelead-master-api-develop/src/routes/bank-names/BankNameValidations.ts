import { joi, commonValidations } from '@homelead-shared-api';

const create = joi.object().keys({
    name: joi.string().trim().min(3).max(30).required(),
    icon: joi.string().trim().optional(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    create,
    requiredId,
    updateStatus,
};
