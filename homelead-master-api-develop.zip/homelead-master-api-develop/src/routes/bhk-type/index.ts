export { router } from './BhkTypeRoutes';
