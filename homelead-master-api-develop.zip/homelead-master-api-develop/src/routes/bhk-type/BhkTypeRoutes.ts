import { RequestHandler, Router } from 'express';
import BhkTypeService from './BhkTypeService';
import BhkTypeValidations from './BhkTypeValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.BHKS_TYPES_LIST), BhkTypeService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.BHKS_TYPES_ADD),
    validate(BhkTypeValidations.create),
    BhkTypeService.create as RequestHandler
);

router.get('/active-bhk-types', verifyToken(), BhkTypeService.activeBhkTypes as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.BHKS_TYPES_VIEW),
    validate(BhkTypeValidations.requiredId, 'params'),
    BhkTypeService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.BHKS_TYPES_UPDATE),
    validate(BhkTypeValidations.requiredId, 'params'),
    validate(BhkTypeValidations.create),
    BhkTypeService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.BHKS_TYPES_DELETE),
    validate(BhkTypeValidations.requiredId, 'params'),
    BhkTypeService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.BHKS_TYPES_UPDATE),
    validate(BhkTypeValidations.requiredId, 'params'),
    validate(BhkTypeValidations.updateStatus),
    BhkTypeService.updateStatus as RequestHandler
);

export { router };
