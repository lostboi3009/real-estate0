import { Request, Response } from 'express';
import BhkTypeDao from '../../dao/BhkTypeDao';
import { IBhkType, Status, CommonId, CommonStatus } from '@homelead-shared-api';

class BhkTypeService {
    async getAll(req: Request, res: Response) {
        const bhkTypes = await BhkTypeDao.getAll();

        return res.success(bhkTypes);
    }

    async activeBhkTypes(req: Request, res: Response) {
        const bhkTypes = await BhkTypeDao.activeBhkTypes();

        return res.success(bhkTypes);
    }

    async create(req: Request, res: Response) {
        const bhkType: IBhkType = req.body;

        const response = await BhkTypeDao.create(bhkType);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const bhkType = await BhkTypeDao.getById({ id });

        if (!bhkType) {
            return res.notFound(null, req.__('BHK_TYPE_NOT_FOUND'));
        }

        return res.success(bhkType);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IBhkType = req.body;

        const bhkType = await BhkTypeDao.getById({ id });

        if (!bhkType) {
            return res.notFound(null, req.__('BHK_TYPE_NOT_FOUND'));
        }

        await BhkTypeDao.updateById({ id, data });

        return res.success(null, req.__('BHK_TYPE_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IBhkType> = {
            status: Status.ARCHIVED,
        };

        const bhkType = await BhkTypeDao.getById({ id });

        if (!bhkType) {
            return res.notFound(null, req.__('BHK_TYPE_NOT_FOUND'));
        }

        await BhkTypeDao.updateById({ id, data });

        return res.success(null, req.__('BHK_TYPE_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const bhkType = await BhkTypeDao.getById({ id });

        if (!bhkType) {
            return res.notFound(null, req.__('BHK_TYPE_NOT_FOUND'));
        }

        await BhkTypeDao.updateById({ id, data });

        return res.success(null, req.__('BHK_TYPE_STATUS_UPDATED'));
    }
}

export default new BhkTypeService();
