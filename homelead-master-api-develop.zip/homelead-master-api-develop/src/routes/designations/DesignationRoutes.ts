import { RequestHandler, Router } from 'express';
import DesignationService from './DesignationService';
import DesignationValidations from './DesignationValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.DESIGNATIONS_LIST), DesignationService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.DESIGNATIONS_ADD),
    validate(DesignationValidations.create),
    DesignationService.create as RequestHandler
);

router.get('/active-designations', verifyToken(), DesignationService.activeDesignations as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.DESIGNATIONS_VIEW),
    validate(DesignationValidations.requiredId, 'params'),
    DesignationService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.DESIGNATIONS_UPDATE),
    validate(DesignationValidations.requiredId, 'params'),
    validate(DesignationValidations.create),
    DesignationService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.DESIGNATIONS_DELETE),
    validate(DesignationValidations.requiredId, 'params'),
    DesignationService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.DESIGNATIONS_UPDATE),
    validate(DesignationValidations.requiredId, 'params'),
    validate(DesignationValidations.updateStatus),
    DesignationService.updateStatus as RequestHandler
);

export { router };
