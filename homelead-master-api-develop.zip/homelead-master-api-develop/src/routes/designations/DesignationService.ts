import { Request, Response } from 'express';
import { CommonId, CommonStatus, IDesignation, Status } from '@homelead-shared-api';
import DesignationDao from '../../dao/DesignationDao';

class DesignationService {
    async getAll(req: Request, res: Response) {
        const designations = await DesignationDao.getAll();

        return res.success(designations);
    }

    async activeDesignations(req: Request, res: Response) {
        const designations = await DesignationDao.activeDesignations();

        return res.success(designations);
    }

    async create(req: Request, res: Response) {
        const designation: IDesignation = req.body;

        const response = await DesignationDao.create(designation);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const designation = await DesignationDao.getById({ id });

        if (!designation) {
            return res.notFound(null, req.__('DESIGNATION_NOT_FOUND'));
        }

        return res.success(designation);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IDesignation = req.body;

        const designation = await DesignationDao.getById({ id });

        if (!designation) {
            return res.notFound(null, req.__('DESIGNATION_NOT_FOUND'));
        }

        await DesignationDao.updateById({ id, data });

        return res.success(null, req.__('DESIGNATION_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IDesignation> = {
            status: Status.ARCHIVED,
        };

        const designation = await DesignationDao.getById({ id });

        if (!designation) {
            return res.notFound(null, req.__('DESIGNATION_NOT_FOUND'));
        }

        await DesignationDao.updateById({ id, data });

        return res.success(null, req.__('DESIGNATION_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const designation = await DesignationDao.getById({ id });

        if (!designation) {
            return res.notFound(null, req.__('DESIGNATION_NOT_FOUND'));
        }

        await DesignationDao.updateById({ id, data });

        return res.success(null, req.__('DESIGNATION_STATUS_UPDATED'));
    }
}

export default new DesignationService();
