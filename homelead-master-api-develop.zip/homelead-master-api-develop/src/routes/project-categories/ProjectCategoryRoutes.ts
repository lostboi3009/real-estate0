import { RequestHandler, Router } from 'express';
import ProjectCategoryService from './ProjectCategoryService';
import ProjectCategoryValidations from './ProjectCategoryValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.PROJECTS_CATEGORIES_LIST), ProjectCategoryService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.PROJECTS_CATEGORIES_ADD),
    validate(ProjectCategoryValidations.create),
    ProjectCategoryService.create as RequestHandler
);

router.get(
    '/active-project-categories',
    verifyToken(),
    ProjectCategoryService.activeProjectCategories as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_CATEGORIES_VIEW),
    validate(ProjectCategoryValidations.requiredId, 'params'),
    ProjectCategoryService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_CATEGORIES_UPDATE),
    validate(ProjectCategoryValidations.requiredId, 'params'),
    validate(ProjectCategoryValidations.create),
    ProjectCategoryService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_CATEGORIES_DELETE),
    validate(ProjectCategoryValidations.requiredId, 'params'),
    ProjectCategoryService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.PROJECTS_CATEGORIES_UPDATE),
    validate(ProjectCategoryValidations.requiredId, 'params'),
    validate(ProjectCategoryValidations.updateStatus),
    ProjectCategoryService.updateStatus as RequestHandler
);

export { router };
