import { Request, Response } from 'express';
import { CommonId, CommonStatus, IProjectCategory, Status } from '@homelead-shared-api';
import ProjectCategoryDao from '../../dao/ProjectCategoryDao';

class ProjectCategoryService {
    async getAll(req: Request, res: Response) {
        const projectCategory = await ProjectCategoryDao.getAll();

        return res.success(projectCategory);
    }

    async activeProjectCategories(req: Request, res: Response) {
        const projectCategories = await ProjectCategoryDao.activeProjectCategories();

        return res.success(projectCategories);
    }

    async create(req: Request, res: Response) {
        const projectCategory: IProjectCategory = req.body;

        const response = await ProjectCategoryDao.create(projectCategory);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const projectCategory = await ProjectCategoryDao.getById({ id });

        if (!projectCategory) {
            return res.notFound(null, req.__('PROJECT_CATEGORY_NOT_FOUND'));
        }

        return res.success(projectCategory);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IProjectCategory = req.body;

        const projectCategory = await ProjectCategoryDao.getById({ id });

        if (!projectCategory) {
            return res.notFound(null, req.__('PROJECT_CATEGORY_NOT_FOUND'));
        }

        await ProjectCategoryDao.updateById({ id, data });

        return res.success(null, req.__('PROJECT_CATEGORY_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IProjectCategory> = {
            status: Status.ARCHIVED,
        };

        const projectCategory = await ProjectCategoryDao.getById({ id });

        if (!projectCategory) {
            return res.notFound(null, req.__('PROJECT_CATEGORY_NOT_FOUND'));
        }

        await ProjectCategoryDao.updateById({ id, data });

        return res.success(null, req.__('PROJECT_CATEGORY_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const projectCategory = await ProjectCategoryDao.getById({ id });

        if (!projectCategory) {
            return res.notFound(null, req.__('PROJECT_CATEGORY_NOT_FOUND'));
        }

        await ProjectCategoryDao.updateById({ id, data });

        return res.success(null, req.__('PROJECT_CATEGORY_STATUS_UPDATED'));
    }
}
export default new ProjectCategoryService();
