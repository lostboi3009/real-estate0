import { Request, Response } from 'express';
import BankDao from '../../dao/BankDao';
import { IBank, Status, CommonId, CommonStatus } from '@homelead-shared-api';
import { BankData } from '@dto';
import BankNameDao from '../../dao/BankNameDao';

class BankService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const banks = await BankDao.getAll({ company });

        return res.success(banks);
    }

    async activeBanks(req: Request, res: Response) {
        const { company } = req.user;
        const banks = await BankDao.activeBanks({ company });

        return res.success(banks);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const bank: BankData = req.body;
        const bankName = await BankNameDao.getById({ id: bank.bankNameId });

        if (!bankName) {
            return res.notFound(null, req.__('BANK_NAME_NOT_FOUND'));
        }

        const data = {
            ...bank,
            company,
            bankNameId: {
                _id: bankName._id,
                name: bankName.name,
                icon: bankName.icon,
            },
            status: Status.ACTIVE,
        };

        const response = await BankDao.create(data);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const bank = await BankDao.getById({ id, company });

        if (!bank) {
            return res.notFound(null, req.__('BANK_NOT_FOUND'));
        }

        return res.success(bank);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: BankData = req.body;

        const bank = await BankDao.getById({ id, company });

        if (!bank) {
            return res.notFound(null, req.__('BANK_NOT_FOUND'));
        }

        const bankName = await BankNameDao.getById({ id: data.bankNameId });

        if (!bankName) {
            return res.notFound(null, req.__('BANK_NAME_NOT_FOUND'));
        }

        const updatedData = {
            ...data,
            bankNameId: {
                _id: bankName._id,
                name: bankName.name,
                icon: bankName.icon,
            },
            status: Status.ACTIVE,
        };

        await BankDao.updateById({ id, company, data: updatedData });

        return res.success(null, req.__('BANK_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IBank> = {
            status: Status.ARCHIVED,
        };

        const bank = await BankDao.getById({ id, company });

        if (!bank) {
            return res.notFound(null, req.__('BANK_NOT_FOUND'));
        }

        await BankDao.updateById({ id, company, data });

        return res.success(null, req.__('BANK_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const bank = await BankDao.getById({ id, company });

        if (!bank) {
            return res.notFound(null, req.__('BANK_NOT_FOUND'));
        }

        await BankDao.updateById({ id, company, data });

        return res.success(null, req.__('BANK_STATUS_UPDATED'));
    }
}

export default new BankService();
