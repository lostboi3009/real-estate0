import { joi, commonValidations } from '@homelead-shared-api';

const create = joi.object().keys({
    bankNameId: commonValidations.id,
    branchName: joi.string().trim().min(3).max(30).required(),
    branchAddress: joi.string().trim().max(200).required(),
    ifscCode: joi.string().trim().min(3).max(30).required(),
    swiftCode: joi.string().trim().required(),
    contactPersonDetails: {
        fullName: joi.string().trim().min(3).max(30).required(),
        countryCode: commonValidations.countryCode,
        phone: commonValidations.phone,
        designation: joi.string().trim().min(3).max(30).required(),
    },
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    create,
    requiredId,
    updateStatus,
};
