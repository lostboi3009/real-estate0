import { RequestHandler, Router } from 'express';
import BankService from './BankService';
import BankValidations from './BankValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.BANKS_LIST), BankService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.BANKS_ADD),
    validate(BankValidations.create),
    BankService.create as RequestHandler
);

router.get('/active-banks', verifyToken(), BankService.activeBanks as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.BANKS_VIEW),
    validate(BankValidations.requiredId, 'params'),
    BankService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.BANKS_UPDATE),
    validate(BankValidations.requiredId, 'params'),
    validate(BankValidations.create),
    BankService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.BANKS_DELETE),
    validate(BankValidations.requiredId, 'params'),
    BankService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.BANKS_UPDATE),
    validate(BankValidations.requiredId, 'params'),
    validate(BankValidations.updateStatus),
    BankService.updateStatus as RequestHandler
);

export { router };
