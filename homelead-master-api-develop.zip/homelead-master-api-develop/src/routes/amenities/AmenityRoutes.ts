import { RequestHandler, Router } from 'express';
import AmenityService from './AmenityService';
import AmenityValidations from './AmenityValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/', verifyToken(UserPermissions.AMENITIES_LIST), AmenityService.getAll as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.AMENITIES_ADD),
    validate(AmenityValidations.create),
    AmenityService.create as RequestHandler
);

router.get('/active-amenities', verifyToken(), AmenityService.activeAmenities as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.AMENITIES_VIEW),
    validate(AmenityValidations.requiredId, 'params'),
    AmenityService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.AMENITIES_UPDATE),
    validate(AmenityValidations.requiredId, 'params'),
    validate(AmenityValidations.create),
    AmenityService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.AMENITIES_DELETE),
    validate(AmenityValidations.requiredId, 'params'),
    AmenityService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.AMENITIES_UPDATE),
    validate(AmenityValidations.requiredId, 'params'),
    validate(AmenityValidations.updateStatus),
    AmenityService.updateStatus as RequestHandler
);

export { router };
