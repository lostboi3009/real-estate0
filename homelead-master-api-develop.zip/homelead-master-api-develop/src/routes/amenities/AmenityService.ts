import { Request, Response } from 'express';
import AmenityDao from '../../dao/AmenityDao';
import { IAmenity, Status, CommonId, CommonStatus } from '@homelead-shared-api';

class AmenityService {
    async getAll(req: Request, res: Response) {
        const amenities = await AmenityDao.getAll();

        return res.success(amenities);
    }

    async activeAmenities(req: Request, res: Response) {
        const amenities = await AmenityDao.activeAmenities();

        return res.success(amenities);
    }

    async create(req: Request, res: Response) {
        const amenity: IAmenity = req.body;

        const response = await AmenityDao.create(amenity);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const amenity = await AmenityDao.getById({ id });

        if (!amenity) {
            return res.notFound(null, req.__('AMENITY_NOT_FOUND'));
        }

        return res.success(amenity);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IAmenity = req.body;

        const amenity = await AmenityDao.getById({ id });

        if (!amenity) {
            return res.notFound(null, req.__('AMENITY_NOT_FOUND'));
        }

        await AmenityDao.updateById({ id, data });

        return res.success(null, req.__('AMENITY_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IAmenity> = {
            status: Status.ARCHIVED,
        };

        const amenity = await AmenityDao.getById({ id });

        if (!amenity) {
            return res.notFound(null, req.__('AMENITY_NOT_FOUND'));
        }

        await AmenityDao.updateById({ id, data });

        return res.success(null, req.__('AMENITY_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const amenity = await AmenityDao.getById({ id });

        if (!amenity) {
            return res.notFound(null, req.__('AMENITY_NOT_FOUND'));
        }

        await AmenityDao.updateById({ id, data });

        return res.success(null, req.__('AMENITY_STATUS_UPDATED'));
    }
}

export default new AmenityService();
