import { Request, Response } from 'express';
import CommonDao from '../../dao/CommonDao';
import * as enums from '@homelead-shared-api/enums';

const availableCountries = ['India'];

class CommonService {
    async getStaticPage(req: Request, res: Response) {
        const slug = req.params.slug as string;
        const page = await CommonDao.getStaticPage(slug);

        return res.success(page);
    }

    async getPageView(req: Request, res: Response) {
        const slug = req.params.slug as string;
        const page = await CommonDao.getStaticPage(slug);

        return res.render('static-page', {
            page,
        });
    }

    async getAllCountries(req: Request, res: Response) {
        const countries = await CommonDao.getAllCountries({
            name: {
                $in: availableCountries,
            },
        });

        return res.success(countries);
    }

    async getConfigurations(req: Request, res: Response) {
        return res.success({
            enums,
        });
    }
}

export default new CommonService();
