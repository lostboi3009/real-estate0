import { joi } from '@homelead-shared-api';

const getStaticPage = joi.object().keys({
    slug: joi.string().trim().required(),
});

export default {
    getStaticPage,
};
