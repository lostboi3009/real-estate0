import { RequestHandler, Router } from 'express';
import CommonService from './CommonService';
import CommonValidations from './CommonValidations';
import { validate } from '../../utils/validations';

const router = Router();

router.get(
    '/pages/:slug',
    validate(CommonValidations.getStaticPage, 'params'),
    CommonService.getStaticPage as RequestHandler
);

router.get(
    '/page-view/:slug',
    validate(CommonValidations.getStaticPage, 'params'),
    CommonService.getPageView as RequestHandler
);

router.get('/countries', CommonService.getAllCountries as RequestHandler);

router.get('/configurations', CommonService.getConfigurations as RequestHandler);

export { router };
