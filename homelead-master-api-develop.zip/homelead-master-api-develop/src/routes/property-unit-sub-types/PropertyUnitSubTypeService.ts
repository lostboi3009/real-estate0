import { Request, Response } from 'express';
import PropertyUnitSubTypeDao from '../../dao/PropertyUnitSubTypeDao';
import { IPropertyUnitSubType, Status, CommonId, CommonStatus } from '@homelead-shared-api';

class PropertyUnitSubTypeService {
    async getAll(req: Request, res: Response) {
        const propertyUnitSubTypes = await PropertyUnitSubTypeDao.getAll();

        return res.success(propertyUnitSubTypes);
    }

    async activePropertyUnitSubTypes(req: Request, res: Response) {
        const propertyUnitSubTypes = await PropertyUnitSubTypeDao.activePropertyUnitSubTypes();

        return res.success(propertyUnitSubTypes);
    }

    async create(req: Request, res: Response) {
        const propertyUnitSubType: IPropertyUnitSubType = req.body;

        const response = await PropertyUnitSubTypeDao.create(propertyUnitSubType);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const propertyUnitSubType = await PropertyUnitSubTypeDao.getById({ id });

        if (!propertyUnitSubType) {
            return res.notFound(null, req.__('PROPERTY_UNIT_SUB_TYPE_NOT_FOUND'));
        }

        return res.success(propertyUnitSubType);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: IPropertyUnitSubType = req.body;

        const propertyUnitSubType = await PropertyUnitSubTypeDao.getById({ id });

        if (!propertyUnitSubType) {
            return res.notFound(null, req.__('PROPERTY_UNIT_SUB_TYPE_NOT_FOUND'));
        }

        await PropertyUnitSubTypeDao.updateById({ id, data });

        return res.success(null, req.__('PROPERTY_UNIT_SUB_TYPE_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IPropertyUnitSubType> = {
            status: Status.ARCHIVED,
        };

        const propertyUnitSubType = await PropertyUnitSubTypeDao.getById({ id });

        if (!propertyUnitSubType) {
            return res.notFound(null, req.__('PROPERTY_UNIT_SUB_TYPE_NOT_FOUND'));
        }

        await PropertyUnitSubTypeDao.updateById({ id, data });

        return res.success(null, req.__('PROPERTY_UNIT_SUB_TYPE_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const propertyUnitSubType = await PropertyUnitSubTypeDao.getById({ id });

        if (!propertyUnitSubType) {
            return res.notFound(null, req.__('PROPERTY_UNIT_SUB_TYPE_NOT_FOUND'));
        }

        await PropertyUnitSubTypeDao.updateById({ id, data });

        return res.success(null, req.__('PROPERTY_UNIT_SUB_TYPE_STATUS_UPDATED'));
    }
}

export default new PropertyUnitSubTypeService();
