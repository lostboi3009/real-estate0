import { RequestHandler, Router } from 'express';
import PropertyUnitSubTypeService from './PropertyUnitSubTypeService';
import PropertyUnitSubTypeValidations from './PropertyUnitSubTypeValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.PROJECTS_UNITS_SUB_TYPES_LIST),
    PropertyUnitSubTypeService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.PROJECTS_UNITS_SUB_TYPES_ADD),
    validate(PropertyUnitSubTypeValidations.create),
    PropertyUnitSubTypeService.create as RequestHandler
);

router.get(
    '/active-property-unit-sub-types',
    verifyToken(),
    PropertyUnitSubTypeService.activePropertyUnitSubTypes as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_UNITS_SUB_TYPES_VIEW),
    validate(PropertyUnitSubTypeValidations.requiredId, 'params'),
    PropertyUnitSubTypeService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_UNITS_SUB_TYPES_UPDATE),
    validate(PropertyUnitSubTypeValidations.requiredId, 'params'),
    validate(PropertyUnitSubTypeValidations.create),
    PropertyUnitSubTypeService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.PROJECTS_UNITS_SUB_TYPES_DELETE),
    validate(PropertyUnitSubTypeValidations.requiredId, 'params'),
    PropertyUnitSubTypeService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.PROJECTS_UNITS_SUB_TYPES_UPDATE),
    validate(PropertyUnitSubTypeValidations.requiredId, 'params'),
    validate(PropertyUnitSubTypeValidations.updateStatus),
    PropertyUnitSubTypeService.updateStatus as RequestHandler
);

export { router };
