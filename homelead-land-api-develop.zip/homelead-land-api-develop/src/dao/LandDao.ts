import {
    CommonId,
    getSearchRegex,
    ILandDoc,
    ILand,
    Land,
    mongoose,
    Status,
    CompanyId,
    Pagination,
} from '@homelead-shared-api';
import { GetLands } from '@dto';

type FilterQueryILand = mongoose.FilterQuery<ILand>;

class LandDao {
    async getAll({ status, search, page, perPage, company }: GetLands & Pagination): Promise<ILandDoc[]> {
        const matchCriteria: FilterQueryILand = {
            status: { $ne: Status.ARCHIVED },
            company,
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { name: { $regex: searchRegex } },
                { propertyType: { $regex: searchRegex } },
                { address: { $regex: searchRegex } },
                { ownerName: { $regex: searchRegex } },
                { ownerEmail: { $regex: searchRegex } },
                { pastOwnerName: { $regex: searchRegex } },
            ];
        }

        return Land.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .sort({ _id: -1 });
    }

    async getCount({ status, search, company }: GetLands): Promise<number> {
        const matchCriteria: FilterQueryILand = {
            status: { $ne: Status.ARCHIVED },
            company,
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }, { propertyType: { $regex: searchRegex } }];
        }

        return Land.countDocuments(matchCriteria);
    }

    async activeLands({ company }: CompanyId): Promise<ILandDoc[]> {
        return Land.find({
            status: Status.ACTIVE,
            company,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    async create(name: ILand): Promise<ILandDoc> {
        return Land.create(name);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<ILandDoc | null> {
        return Land.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data, company }: CommonId & CompanyId & { data: Partial<ILandDoc> }) {
        return Land.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new LandDao();
