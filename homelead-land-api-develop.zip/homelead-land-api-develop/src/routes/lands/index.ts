export { router } from './LandRoutes';
