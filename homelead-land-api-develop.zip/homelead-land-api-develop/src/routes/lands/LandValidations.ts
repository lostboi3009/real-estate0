import { joi, commonValidations, PropertyType, AreaType, OccupancyStatus } from '@homelead-shared-api';

const create = joi.object().keys({
    name: joi.string().trim().min(3).max(30).required(),
    propertyType: joi
        .array()
        .items(
            joi
                .string()
                .trim()
                .valid(...Object.values(PropertyType))
        )
        .required(),
    address: joi.string().trim().max(200).required(),
    country: commonValidations.id,
    state: commonValidations.id,
    city: commonValidations.id,
    zipCode: joi.string().trim().required(),
    coordinates: commonValidations.coordinates.optional(),
    nearByArea: joi.string().trim().optional(),
    purchasePrice: joi.number().positive().required(),
    currentMarketValue: joi.number().positive().required(),
    propertyTaxRefNo: joi.string().trim().optional(),
    isOnLease: joi.boolean().optional(),
    rentalIncome: joi.number().optional(),
    occupancyStatus: joi
        .string()
        .trim()
        .valid(...Object.values(OccupancyStatus))
        .optional(),
    leaseAgreementDocs: joi.array().items(joi.string().trim()).optional(),
    isAnyConstructionExists: joi.boolean().optional(),
    plotSize: joi.number().optional(),
    sizeType: joi
        .string()
        .trim()
        .valid(...Object.values(AreaType))
        .optional(),
    geoGraphicalDetails: joi.string().trim().optional(),
    amenities: joi.array().items(joi.string().trim()).optional(),
    ownerName: joi.string().trim().required(),
    ownerEmail: commonValidations.email.optional(),
    ownerCountryCode: commonValidations.countryCode,
    ownerPhone: commonValidations.phone,
    pastOwnerName: joi.string().trim().optional(),
    pastOwnerCountryCode: commonValidations.countryCode.optional(),
    pastOwnerPhone: commonValidations.phone.optional(),
});

const getAll = joi.object().keys({
    search: joi.string().trim().optional(),
    status: commonValidations.status.optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    create,
    requiredId,
    updateStatus,
    getAll,
};
