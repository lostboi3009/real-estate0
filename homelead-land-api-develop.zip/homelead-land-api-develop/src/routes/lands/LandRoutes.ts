import { RequestHandler, Router } from 'express';
import { UserPermissions } from '@homelead-shared-api';
import LandService from './LandService';
import LandValidations from './LandValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.LANDS_LIST),
    validate(LandValidations.getAll, 'query'),
    LandService.getAll as RequestHandler
);

router.get('/export-pdf', verifyToken(UserPermissions.LANDS_EXPORT_PDF), LandService.exportPdf as RequestHandler);

router.get('/export-csv', verifyToken(UserPermissions.LANDS_EXPORT_CSV), LandService.exportCsv as RequestHandler);

router.get('/active-lands', verifyToken(), LandService.activeLands as RequestHandler);

router.post(
    '/',
    verifyToken(UserPermissions.LANDS_ADD),
    validate(LandValidations.create),
    LandService.create as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.LANDS_VIEW),
    validate(LandValidations.requiredId, 'params'),
    LandService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.LANDS_UPDATE),
    validate(LandValidations.requiredId, 'params'),
    validate(LandValidations.create),
    LandService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.LANDS_DELETE),
    validate(LandValidations.requiredId, 'params'),
    LandService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.LANDS_UPDATE),
    validate(LandValidations.requiredId, 'params'),
    validate(LandValidations.updateStatus),
    LandService.updateStatus as RequestHandler
);

export { router };
