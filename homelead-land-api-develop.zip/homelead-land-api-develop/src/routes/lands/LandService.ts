import { Request, Response } from 'express';
import LandDao from '../../dao/LandDao';
import { ILand, Status, CommonId, CommonStatus, Pagination, jsonToCsvBuffer } from '@homelead-shared-api';
import { GetLands } from '@lib/dto';
import { exportPdf } from '../../utils/common';

class LandService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { search, status, page, perPage } = req.query as unknown as GetLands & Pagination;

        const [lands, count] = await Promise.all([
            LandDao.getAll({
                company,
                status,
                search,
                page,
                perPage,
            }),
            LandDao.getCount({
                company,
                status,
                search,
            }),
        ]);

        return res.success({
            lands,
            count,
        });
    }

    async activeLands(req: Request, res: Response) {
        const { company } = req.user;
        const lands = await LandDao.activeLands({
            company,
        });

        return res.success(lands);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const land: ILand = req.body;
        const data = {
            ...land,
            company,
        };

        const response = await LandDao.create(data);

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const land = await LandDao.getById({ id, company });

        if (!land) {
            return res.notFound(null, req.__('LAND_NOT_FOUND'));
        }

        return res.success(land);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: ILand = req.body;

        const land = await LandDao.getById({ id, company });

        if (!land) {
            return res.notFound(null, req.__('LAND_NOT_FOUND'));
        }

        await LandDao.updateById({ id, data, company });

        return res.success(null, req.__('LAND_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<ILand> = {
            status: Status.ARCHIVED,
        };

        const land = await LandDao.getById({ id, company });

        if (!land) {
            return res.notFound(null, req.__('LAND_NOT_FOUND'));
        }

        await LandDao.updateById({ id, data, company });

        return res.success(null, req.__('LAND_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: CommonStatus = req.body;

        const land = await LandDao.getById({ id, company });

        if (!land) {
            return res.notFound(null, req.__('LAND_NOT_FOUND'));
        }

        await LandDao.updateById({ id, data, company });

        return res.success(null, req.__('LAND_STATUS_UPDATED'));
    }

    async exportPdf(req: Request, res: Response) {
        const { company } = req.user;
        const { search, status, page, perPage } = req.query as unknown as GetLands & Pagination;

        const lands = await LandDao.getAll({
            company,
            search,
            status,
            page,
            perPage,
        });

        if (!lands.length) {
            return res.notFound(null, req.__('LAND_NOT_FOUND'));
        }

        const pdfBuffer = await exportPdf('export-lands.ejs', lands);

        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="lands.pdf"');
        return res.send(pdfBuffer);
    }

    async exportCsv(req: Request, res: Response) {
        const { company } = req.user;
        const { search, status, page, perPage } = req.query as unknown as GetLands & Pagination;

        const lands = await LandDao.getAll({
            company,
            search,
            status,
            page,
            perPage,
        });

        if (!lands.length) {
            return res.notFound(null, req.__('LAND_NOT_FOUND'));
        }

        const csv = jsonToCsvBuffer(lands, {
            excelBOM: true,
        });

        res.header('Content-Type', 'text/csv');
        res.attachment('lands.csv');
        return res.send(csv);
    }
}

export default new LandService();
