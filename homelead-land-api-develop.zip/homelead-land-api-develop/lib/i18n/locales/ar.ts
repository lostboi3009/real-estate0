import { I18n, ValidationKeys, ValidationMessages, Validations } from '@dto';

const validationKeys: ValidationKeys = Object.freeze({
    name: 'الاسم',
    firstName: 'الاسم الأول',
    lastName: 'الاسم الأخير',
    fullName: 'الاسم الكامل',
    email: 'البريد الإلكتروني',
    countryCode: 'رمز الدولة',
    phone: 'الهاتف',
    emailToken: 'رمز البريد الإلكتروني',
    phoneToken: 'رمز الهاتف',
    emailPattern: 'يجب أن يكون بريد إلكتروني صالح.',
    semanticPattern: 'يجب أن يكون إصداراً صالحاً.',
    countryCodePattern: 'يجب أن يكون رمز دولة صالح.',
    phonePattern: 'يجب أن يكون رقم هاتف صالح.',
    timeIn24Hours: 'يجب أن يكون وقتاً صحيحاً بصيغة 24 ساعة.',
    page: 'الصفحة',
    perPage: 'لكل صفحة',
    company: 'شركة',
    propertyType: 'نوع الملكية',
    address: 'العنوان',
    country: 'الدولة',
    state: 'الولاية',
    city: 'المدينة',
    zipCode: 'الرمز البريدي',
    purchasePrice: 'سعر الشراء',
    currentMarketValue: 'القيمة السوقية الحالية',
    ownerEmail: 'بريد مالك العقار الإلكتروني',
    ownerCountryCode: 'رمز الدولة للمالك',
    ownerPhone: 'هاتف المالك',
});

const validationMessages: ValidationMessages = Object.freeze({
    NOT_AVAILABLE: 'غير متوفر',
    VIEW: 'عرض',
    EDIT: 'تعديل',
    DELETE: 'حذف',
    REMOVE: 'إزالة',
    ACTIVATE: 'تفعيل',
    IN_ACTIVATE: 'تعطيل',
    HEALTH_CHECK: 'فحص الصحة',
    NOT_FOUND: 'المورد غير موجود.',
    GENERAL_ERROR: 'حدث خطأ ما.',
    INVALID_REQUEST: 'طلب غير صالح، فشل التحقق من الطلب.',
    EMAIL_ALREADY_FOUND: 'البريد الإلكتروني موجود بالفعل.',
    PHONE_ALREADY_FOUND: 'الهاتف موجود بالفعل.',
    USER_NOT_FOUND: 'المستخدم غير موجود.',
    YOUR_ACCOUNT_SUSPENDED: 'تم تعليق حسابك.',
    UNAUTHORIZED: 'دخول غير مصرح به.',
    SESSION_EXPIRED: 'انتهت الجلسة.',
    INVALID_SESSION: 'جلسة غير صالحة.',
    LAND_NOT_FOUND: 'الأرض غير موجودة.',
    LAND_UPDATE_SUCCESS: 'تم تحديث الأرض بنجاح.',
    LAND_DELETE_SUCCESS: 'تم حذف الأرض بنجاح.',
    LAND_STATUS_UPDATED: 'تم تحديث حالة الأرض بنجاح.',
    COMPANY_SUBSCRIPTION_EXPIRED: 'انتهت اشتراك الشركة',
});

const formatKeyName = (keyName: string): string => validationKeys[keyName.replace(/\.\d+/, '')] ?? keyName;

const validations: Validations = {
    'any.required': ({ path }) => `${formatKeyName(path.join('.'))} مطلوب.`,
    'any.unknown': ({ path }) => `${formatKeyName(path.join('.'))} غير مسموح به.`,
    'any.invalid': ({ path }) => `${formatKeyName(path.join('.'))} يحتوي على قيمة غير صالحة.`,
    'any.empty': ({ path }) => `${formatKeyName(path.join('.'))} مطلوب.`,
    'any.allowOnly': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون واحدًا من ${context?.valids?.map((item: string) => formatKeyName(item)).join(', ')}`,
    'string.base': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون نصًا.`,
    'string.min': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون طوله على الأقل ${context?.limit} حرفًا.`,
    'string.max': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون طوله أقل من أو يساوي ${context?.limit} حرفًا.`,
    'string.hex': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يحتوي فقط على أحرف سداسية عشرية.`,
    'string.length': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون طوله 4 أحرف.`,
    'string.pattern.name': ({ path, context }) => `${formatKeyName(path.join('.'))} ${formatKeyName(context?.name)}`,
    'number.base': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون رقمًا.`,
    'number.min': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون أكبر من أو يساوي ${context?.limit}.`,
    'number.max': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون أقل من أو يساوي ${context?.limit}.`,
    'number.integer': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون عددًا صحيحًا.`,
    'objectId.isValid': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون معرف كائن صالح.`,
    'object.base': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون كائنًا.`,
    'object.xor': ({ context }) =>
        `يسمح فقط بواحد من ${context?.peers?.map((peer: string) => formatKeyName(peer)).join(', ')}.`,
    'object.with': ({ context }) => `${formatKeyName(context?.peer)} مطلوب مع ${formatKeyName(context?.main)}.`,
    'object.without': ({ context }) => `${formatKeyName(context?.peer)} يجب إزالته مع ${formatKeyName(context?.main)}.`,
    'object.and': ({ context }) =>
        `${context?.missing?.map((peer: string) => formatKeyName(peer)).join(', ')} مطلوب مع ${context?.present
            .map((peer: string) => formatKeyName(peer))
            .join(', ')}.`,
    'object.missing': ({ context }) =>
        `واحد من ${context?.peers?.map((peer: string) => formatKeyName(peer).toLowerCase()).join(', ')} مطلوب.`,
    'array.min': ({ path, context }) =>
        `${formatKeyName(path.join('.'))} يجب أن تحتوي على الأقل على ${context?.limit} عنصر.`,
    'array.max': ({ path, context }) =>
        `${formatKeyName(path.join('.'))} يجب أن تحتوي على الأكثر ${context?.limit} عنصر.`,
    'array.unique': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن تحتوي على قيمة فريدة.`,
};

const i18n: I18n = {
    validationKeys,
    validationMessages,
    validations,
};

export default i18n;
