import { CompanyId, ILand, Status, TypesObjectId } from '@homelead-shared-api';

export interface CountryCodeAndPhone {
    countryCode: string;
    phone: string;
}

export interface PhoneOrId extends CountryCodeAndPhone {
    id?: TypesObjectId;
}

export interface UpdateLand {
    id: TypesObjectId;
    data: Partial<ILand>;
}

export interface GetLands extends CompanyId {
    status?: Status;
    search?: string;
}
