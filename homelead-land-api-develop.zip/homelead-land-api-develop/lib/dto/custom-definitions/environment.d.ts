declare global {
    namespace NodeJS {
        interface ProcessEnv {
            PORT: string;
            SITE_TITLE: string;
            SITE_URL: string;
            LOGO_PATH: string;
            NODE_ENV: 'development' | 'production';
            SERVER_MODE: 'http' | 'https';
            SERVER_NAME: string;
            SSL_KEY_PATH: string;
            SSL_CERT_PATH: string;
            SSL_CA_PATH: string;
            MONGO_URI: string;
            JWT_SECRET: string;
            VALIDATE_SESSION: string;
            VALIDATE_PERMISSION: string;
            SESSION_SECRET: string;
            SESSION_VALIDITY_DAYS: string;
            LOG_LEVEL: 'error' | 'warn' | 'info' | 'verbose' | 'debug' | 'silly';
            MONGOOSE_DEBUG: 'true' | 'false';
            LOG_REQUESTS: 'true' | 'false';
        }
    }
}
export {};
