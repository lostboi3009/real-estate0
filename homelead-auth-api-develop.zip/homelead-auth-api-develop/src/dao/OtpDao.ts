import { Otp, IOtpDoc, VerifyType } from '@homelead-shared-api';
import { GetEmailOtp, GetPhoneOtp, UpdateOrCreateEmailOtp, UpdateOrCreatePhoneOtp } from '@dto';

class OtpDao {
    getEmailOtp(matchCriteria: GetEmailOtp): Promise<IOtpDoc | null> {
        return Otp.findOne({
            ...matchCriteria,
            verifyType: VerifyType.EMAIL,
        });
    }

    getPhoneOtp(matchCriteria: GetPhoneOtp): Promise<IOtpDoc | null> {
        return Otp.findOne({
            ...matchCriteria,
            verifyType: VerifyType.PHONE,
        });
    }

    updateOrCreateEmailOtp({ company, email, data }: UpdateOrCreateEmailOtp) {
        return Otp.updateOne(
            {
                company,
                email,
            },
            {
                $set: data,
            },
            {
                upsert: true,
            }
        );
    }

    updateOrCreatePhoneOtp({ company, countryCode, phone, data }: UpdateOrCreatePhoneOtp) {
        return Otp.updateOne(
            {
                company,
                countryCode,
                phone,
            },
            {
                $set: data,
            },
            {
                upsert: true,
            }
        );
    }
}

export default new OtpDao();
