import {
    Team,
    ITeamDoc,
    ITeam,
    mongoose,
    Status,
    getSearchRegex,
    CompanyId,
    CommonId,
    Pagination,
} from '@homelead-shared-api';
import { GetTeams } from '@dto';

type FilterQueryITeam = mongoose.FilterQuery<ITeam>;

class TeamDao {
    getAll({ company, status, search, page, perPage }: GetTeams & Pagination): Promise<ITeamDoc[]> {
        const matchCriteria: FilterQueryITeam = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }];
        }

        return Team.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .populate([
                {
                    path: 'groups',
                    select: 'name',
                },
                { path: 'members', select: 'firstName lastName fullName' },
                { path: 'teamLead', select: 'firstName lastName fullName' },
                { path: 'defaultPrimary', select: 'firstName lastName fullName' },
                { path: 'defaultSecondary', select: 'firstName lastName fullName' },
            ])
            .sort({ _id: -1 });
    }

    countAll({ company, status, search }: GetTeams): Promise<number> {
        const matchCriteria: FilterQueryITeam = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }];
        }

        return Team.countDocuments(matchCriteria);
    }

    async activeTeams({ company }: CompanyId): Promise<ITeamDoc[]> {
        return Team.find({
            status: Status.ACTIVE,
            company,
        })
            .select('name _id')
            .sort({ _id: -1 });
    }

    create(team: ITeam): Promise<ITeamDoc | null> {
        return Team.create(team);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<ITeamDoc | null> {
        return Team.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        }).populate([
            {
                path: 'groups',
                select: 'name',
                match: { status: Status.ACTIVE },
            },
            { path: 'members', select: 'firstName lastName fullName', match: { status: Status.ACTIVE } },
            { path: 'teamLead', select: 'firstName lastName fullName', match: { status: Status.ACTIVE } },
            { path: 'defaultPrimary', select: 'firstName lastName fullName', match: { status: Status.ACTIVE } },
            { path: 'defaultSecondary', select: 'firstName lastName fullName', match: { status: Status.ACTIVE } },
        ]);
    }

    async updateById({ id, data, company }: CommonId & CompanyId & { data: Partial<ITeamDoc> }) {
        return Team.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new TeamDao();
