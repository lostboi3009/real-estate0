import {
    CommonId,
    Group,
    IGroup,
    IGroupDoc,
    Status,
    CompanyId,
    TypesObjectId,
    IPermissionData,
    Pagination,
    mongoose,
    getSearchRegex,
} from '@homelead-shared-api';
import { GetGroups, UpdateGroup } from '@dto';

type FilterQueryIGroup = mongoose.FilterQuery<IGroup>;

class GroupDao {
    async getAll({ company, status, search, page, perPage }: GetGroups & Pagination): Promise<IGroupDoc[]> {
        const matchCriteria: FilterQueryIGroup = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }];
        }

        return Group.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .populate({ path: 'members', select: 'fullName' })
            .sort({ _id: -1 });
    }

    async countAll({ company, status, search }: GetGroups): Promise<number> {
        const matchCriteria: FilterQueryIGroup = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }];
        }

        return Group.countDocuments(matchCriteria);
    }

    async activeGroups({ company }: CompanyId): Promise<IGroupDoc[]> {
        return Group.find({
            status: Status.ACTIVE,
            company,
        })
            .select('name permissions')
            .populate({ path: 'members', select: 'fullName' })
            .sort({ _id: -1 });
    }

    async create(group: IGroup): Promise<IGroupDoc> {
        return Group.create(group);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IGroupDoc | null> {
        return Group.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getByIds({ ids, company }: { ids: TypesObjectId[] } & CompanyId): Promise<IGroupDoc[]> {
        return Group.find({
            _id: { $in: ids },
            company,
            status: { $ne: Status.ARCHIVED },
        }).populate('members', 'email');
    }

    async updateById({ id, company, data }: UpdateGroup) {
        return Group.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    async addUserToGroups({ ids, memberIds }: { ids: TypesObjectId[]; memberIds: TypesObjectId[] }) {
        return Group.updateMany(
            {
                _id: { $in: ids },
                status: {
                    $ne: Status.ARCHIVED,
                },
            },
            {
                $addToSet: {
                    members: {
                        $each: memberIds,
                    },
                },
            }
        );
    }

    async removeUserFromGroups({ ids, memberIds }: { ids: TypesObjectId[]; memberIds: TypesObjectId[] }) {
        return Group.updateMany(
            {
                _id: {
                    $in: ids,
                },
                status: {
                    $ne: Status.ARCHIVED,
                },
            },
            {
                $pull: {
                    members: {
                        $in: memberIds,
                    },
                },
            }
        );
    }

    async updateGroupPermissions({
        groupIds,
        company,
        permissions,
    }: {
        company: TypesObjectId;
        groupIds: TypesObjectId[];
        permissions: IPermissionData;
    }) {
        return Group.updateMany(
            {
                company,
                _id: {
                    $in: groupIds,
                },
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    permissions,
                },
            }
        );
    }

    async getGroupWithMembersById({ id, company }: CommonId & CompanyId): Promise<IGroupDoc | null> {
        return Group.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        }).populate('members', 'email');
    }
}

export default new GroupDao();
