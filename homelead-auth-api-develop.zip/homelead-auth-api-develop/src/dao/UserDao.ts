import {
    getSearchRegex,
    IUser,
    IUserDoc,
    IPermissionDoc,
    IPermissionData,
    mongoose,
    Permission,
    Status,
    User,
    CommonId,
    CompanyId,
    TypesObjectId,
    Pagination,
    AccountType,
    UserAccountType,
    ICompanyDoc,
    Company,
    ISettingDoc,
    Setting,
} from '@homelead-shared-api';
import {
    GetUserByEmail,
    GetUserByEmailAndPhone,
    GetUsers,
    GetUserByPhone,
    UpdateUser,
    GetCompanyBySubDomain,
} from '@dto';

type FilterQueryIUser = mongoose.FilterQuery<IUser>;

class UserDao {
    async getAllSubAdmins({ company, status, search, page, perPage }: GetUsers & Pagination): Promise<IUserDoc[]> {
        const matchCriteria: FilterQueryIUser = {
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: UserAccountType.COMPANY_SUB_ADMIN,
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { fullName: { $regex: searchRegex } },
                { email: { $regex: searchRegex } },
                { phone: { $regex: searchRegex } },
            ];
        }

        return User.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .populate([
                { path: 'groups', select: 'name' },
                { path: 'designation', select: 'name' },
                { path: 'reportsTo', select: 'firstName lastName fullName' },
            ])
            .sort({ _id: -1 });
    }

    async countAllSubAdmins({ company, status, search }: GetUsers): Promise<number> {
        const matchCriteria: FilterQueryIUser = {
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: UserAccountType.COMPANY_SUB_ADMIN,
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { fullName: { $regex: searchRegex } },
                { email: { $regex: searchRegex } },
                { phone: { $regex: searchRegex } },
            ];
        }

        return User.countDocuments(matchCriteria);
    }

    async getActiveSubAdmins({ company }: CompanyId): Promise<IUserDoc[]> {
        return User.find({
            company,
            status: Status.ACTIVE,
            accountType: UserAccountType.COMPANY_SUB_ADMIN,
        })
            .select('firstName lastName fullName permissions')
            .sort({ _id: -1 });
    }

    async create(user: IUser): Promise<IUserDoc> {
        return User.create(user);
    }

    async getUserById({ id, company, accountType }: CommonId & CompanyId & AccountType): Promise<IUserDoc | null> {
        return User.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: {
                $in: accountType,
            },
        }).populate({
            path: 'company',
            match: {
                status: Status.ACTIVE,
            },
            populate: {
                path: 'plan',
            },
        });
    }

    async getSubAdminById({ id, company }: CommonId & CompanyId): Promise<IUserDoc | null> {
        return User.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: UserAccountType.COMPANY_SUB_ADMIN,
        });
    }

    async getSubAdminDetailsById({ id, company }: CommonId & CompanyId): Promise<IUserDoc | null> {
        return User.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: UserAccountType.COMPANY_SUB_ADMIN,
        }).populate([
            {
                path: 'reportsTo',
                select: 'firstName lastName fullName',
            },
            {
                path: 'designation',
                select: 'name',
            },
            {
                path: 'groups',
                select: 'name',
            },
        ]);
    }

    async getUserByEmail({ company, id, email }: GetUserByEmail): Promise<IUserDoc | null> {
        const matchCriteria: FilterQueryIUser = {
            company,
            email,
            status: { $ne: Status.ARCHIVED },
        };

        if (id) {
            matchCriteria._id = {
                $ne: id,
            };
        }

        return User.findOne(matchCriteria);
    }

    async getUserByPhone({ company, id, countryCode, phone }: GetUserByPhone): Promise<IUserDoc | null> {
        const matchCriteria: FilterQueryIUser = {
            company,
            countryCode,
            phone,
            status: { $ne: Status.ARCHIVED },
        };

        if (id) {
            matchCriteria._id = {
                $ne: id,
            };
        }

        return User.findOne(matchCriteria);
    }

    async getUserByEmailOrPhone({
        company,
        email,
        countryCode,
        phone,
    }: GetUserByEmailAndPhone): Promise<IUserDoc | null> {
        const matchCriteria: FilterQueryIUser = {
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: {
                $in: [
                    UserAccountType.SUPER_ADMIN,
                    UserAccountType.SUB_ADMIN,
                    UserAccountType.COMPANY_SUB_ADMIN,
                    UserAccountType.COMPANY_SUPER_ADMIN,
                ],
            },
        };

        if (email) {
            matchCriteria.email = email;
        }

        if (countryCode && phone) {
            matchCriteria.countryCode = countryCode;
            matchCriteria.phone = phone;
        }

        return User.findOne(matchCriteria);
    }

    async updateUser({ id, company, data }: UpdateUser) {
        return User.updateOne(
            {
                company,
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    async getAllPermissions({ slugs }: { slugs: string[] }): Promise<IPermissionDoc[]> {
        return Permission.find({
            slug: {
                $in: slugs,
            },
            status: { $ne: Status.ARCHIVED },
        }).sort({ name: 1 });
    }

    async updateUsersPermissions({
        company,
        userIds,
        permissions,
    }: {
        company: TypesObjectId;
        userIds: TypesObjectId[];
        permissions: IPermissionData;
    }) {
        return User.updateMany(
            {
                company,
                _id: {
                    $in: userIds,
                },
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    permissions,
                },
            }
        );
    }

    async getAllReportingManager({ company }: CompanyId): Promise<IUserDoc[]> {
        return User.find({
            company,
            status: Status.ACTIVE,
            isReportingManager: true,
        })
            .select('firstName lastName fullName formattedPhone email status')
            .populate([
                { path: 'groups', select: 'name' },
                { path: 'designation', select: 'name' },
            ])
            .sort({ _id: -1 });
    }

    async getCompanyById({ id }: CommonId): Promise<ICompanyDoc | null> {
        return Company.findOne({
            _id: id,
            status: Status.ACTIVE,
        }).populate({
            path: 'plan',
        });
    }

    async getCompanySettings({ company }: CompanyId): Promise<ISettingDoc | null> {
        return Setting.findOne({
            company,
        }).sort({
            _id: -1,
        });
    }

    async getUserDetailsById({ company, ids }: CompanyId & { ids: TypesObjectId[] }): Promise<IUserDoc[]> {
        return User.find(
            {
                company,
                _id: { $in: ids },
                status: Status.ACTIVE,
            },
            'email phone countryCode'
        );
    }

    async getCompanyBySubDomain({ subDomain }: GetCompanyBySubDomain): Promise<ICompanyDoc | null> {
        return Company.findOne({
            subDomain,
            status: Status.ACTIVE,
        });
    }
}

export default new UserDao();
