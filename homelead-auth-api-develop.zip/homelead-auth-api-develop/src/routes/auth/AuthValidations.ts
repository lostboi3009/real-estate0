import { OtpType, VerifyType, commonValidations, joi } from '@homelead-shared-api';

const getBySubdomain = joi.object().keys({
    subDomain: joi.string().trim().required(),
});

const requestOtp = joi.object().keys({
    company: commonValidations.id,
    verifyType: joi
        .string()
        .trim()
        .valid(...Object.values(VerifyType))
        .required(),
    otpType: joi
        .string()
        .trim()
        .valid(...Object.values(OtpType))
        .required(),
    email: joi.string().when('verifyType', {
        is: [VerifyType.EMAIL, VerifyType.BOTH],
        then: commonValidations.email,
        otherwise: commonValidations.email.optional(),
    }),
    countryCode: joi.string().when('verifyType', {
        is: [VerifyType.PHONE, VerifyType.BOTH],
        then: commonValidations.countryCode,
        otherwise: commonValidations.countryCode.optional(),
    }),
    phone: joi.string().when('verifyType', {
        is: [VerifyType.PHONE, VerifyType.BOTH],
        then: commonValidations.phone,
        otherwise: commonValidations.phone.optional(),
    }),
});

const verifyOtp = requestOtp.keys({
    emailToken: joi.string().when('verifyType', {
        is: [VerifyType.EMAIL, VerifyType.BOTH],
        then: commonValidations.otp,
        otherwise: commonValidations.otp.optional(),
    }),
    phoneToken: joi.string().when('verifyType', {
        is: [VerifyType.PHONE, VerifyType.BOTH],
        then: commonValidations.otp,
        otherwise: commonValidations.otp.optional(),
    }),
});

const logIn = joi
    .object()
    .keys({
        company: commonValidations.id,
        email: commonValidations.email.optional(),
        countryCode: commonValidations.countryCode.optional(),
        phone: commonValidations.phone.optional(),
        password: joi.string().trim().required(),
    })
    .with('countryCode', 'phone')
    .with('phone', 'countryCode')
    .xor('phone', 'email')
    .xor('countryCode', 'email');

const resetPassword = logIn.keys({
    company: commonValidations.id,
    password: commonValidations.password,
});

const verifyMFA = joi.object().keys({
    company: commonValidations.id,
    user: commonValidations.id,
    MFAToken: commonValidations.otp,
});

const changePassword = joi.object().keys({
    currentPassword: joi.string().trim().required(),
    newPassword: commonValidations.password,
});

const updateProfile = joi.object().keys({
    firstName: joi.string().trim().min(3).max(30).required(),
    lastName: joi.string().trim().min(3).max(30).required(),
    email: commonValidations.email,
    countryCode: commonValidations.countryCode,
    phone: commonValidations.phone,
    secondaryCountryCode: commonValidations.countryCode.optional(),
    secondaryPhone: commonValidations.phone.optional(),
    avatar: joi.string().trim().optional(),
});

export default {
    getBySubdomain,
    requestOtp,
    verifyOtp,
    logIn,
    resetPassword,
    changePassword,
    verifyMFA,
    updateProfile,
};
