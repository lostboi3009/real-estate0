import { RequestHandler, Router } from 'express';
import AuthService from './AuthService';
import AuthValidations from './AuthValidations';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';

const router = Router();

router.get(
    '/get-by-subdomain',
    validate(AuthValidations.getBySubdomain, 'query'),
    AuthService.getBySubdomain as RequestHandler
);

router.post(
    '/request-otp',
    validate(AuthValidations.requestOtp),
    AuthService.requestOtp.bind(AuthService) as RequestHandler
);

router.post(
    '/verify-otp',
    validate(AuthValidations.verifyOtp),
    AuthService.verifyOtp.bind(AuthService) as RequestHandler
);

router.post('/log-in', validate(AuthValidations.logIn), AuthService.logIn as RequestHandler);

router.post('/verify-mfa', validate(AuthValidations.verifyMFA), AuthService.verifyMFA as RequestHandler);

router.post('/reset-password', validate(AuthValidations.resetPassword), AuthService.resetPassword as RequestHandler);

router.get('/log-out', verifyToken(), AuthService.logout as RequestHandler);

router.put(
    '/change-password',
    verifyToken(),
    validate(AuthValidations.changePassword),
    AuthService.changePassword as RequestHandler
);

router.get('/profile', verifyToken(), AuthService.getProfileById as RequestHandler);

router.put(
    '/profile',
    verifyToken(),
    validate(AuthValidations.updateProfile),
    AuthService.updateProfileById as RequestHandler
);

export { router };
