import { Request, Response } from 'express';
import moment from 'moment-timezone';
import {
    ChangePassword,
    RequestOtpBody,
    ResetPassword,
    UserLogIn,
    ValidateEmailOtpRequest,
    ValidatePhoneOtpRequest,
    VerifyOtpBody,
    GetCompanyBySubDomain,
    IUpdateProfile,
} from '@dto';
import {
    IOtp,
    OtpType,
    VerifyType,
    generateOtp,
    isDevEnv,
    logger,
    showDate,
    sendMail,
    sendSMS,
    Status,
    OtpReceiverChannel,
    UserAccountType,
    ICompanyDoc,
} from '@homelead-shared-api';
import UserDao from '../../dao/UserDao';
import OtpDao from '../../dao/OtpDao';
import { getPlatform, getUserObj } from '../../utils/common';
import { signToken } from '../../utils/auth';

const accountType = [
    UserAccountType.SUPER_ADMIN,
    UserAccountType.SUB_ADMIN,
    UserAccountType.COMPANY_SUB_ADMIN,
    UserAccountType.COMPANY_SUPER_ADMIN,
];

class AuthService {
    async getBySubdomain(req: Request, res: Response) {
        const { subDomain } = req.query as unknown as GetCompanyBySubDomain;

        const company = await UserDao.getCompanyBySubDomain({
            subDomain,
        });

        if (!company) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        return res.success({
            company: company._id,
        });
    }

    async requestOtp(req: Request, res: Response) {
        const { company, otpType, verifyType, email, countryCode, phone }: RequestOtpBody = req.body;
        const otpValidityMinutes = process.env.OTP_VALIDITY_MINUTES ?? 5;

        if (this.isRequestingEmailOTP(otpType, verifyType)) {
            try {
                await this.validateEmailOtpRequest({ company, otpType, email });
            } catch (e: unknown) {
                const errorMessage = e instanceof Error ? e.message : 'GENERAL_ERROR';
                return res.warn(null, req.__(errorMessage));
            }
        }

        if (this.isRequestingPhoneOTP(otpType, verifyType)) {
            try {
                await this.validatePhoneOtpRequest({ company, otpType, countryCode, phone });
            } catch (e: unknown) {
                const errorMessage = e instanceof Error ? e.message : 'GENERAL_ERROR';
                return res.warn(null, req.__(errorMessage));
            }
        }

        if (this.isRequestingEmailOTP(otpType, verifyType)) {
            const emailOtp: IOtp = {
                company,
                otpType,
                email,
                verifyType: VerifyType.EMAIL,
                isVerified: false,
                token: generateOtp(),
                validTill: moment().add(otpValidityMinutes, 'minutes').toDate(),
            };

            await OtpDao.updateOrCreateEmailOtp({
                company,
                email,
                data: emailOtp,
            });

            if (!isDevEnv) {
                sendMail('user-email-verify', req.__('VERIFICATION_EMAIL'), email, {
                    token: emailOtp.token,
                }).catch(error => {
                    logger.error(
                        `AuthService:: requestOtp -> failed to send user-email-verify email to ${email}`,
                        error
                    );
                    throw error;
                });
            }
        }

        if (this.isRequestingPhoneOTP(otpType, verifyType)) {
            const phoneOtp: IOtp = {
                company,
                otpType,
                countryCode,
                phone,
                verifyType: VerifyType.PHONE,
                isVerified: false,
                token: generateOtp(),
                validTill: moment().add(otpValidityMinutes, 'minutes').toDate(),
            };

            await OtpDao.updateOrCreatePhoneOtp({
                company,
                countryCode,
                phone,
                data: phoneOtp,
            });

            if (!isDevEnv) {
                sendSMS('otpVerification', `${countryCode}${phone}`, [phoneOtp.token]).catch(error => {
                    logger.error(
                        `AuthService:: requestOtp -> failed to send otpVerification SMS to ${countryCode}${phone}`,
                        error
                    );
                    throw error;
                });
            }
        }

        return res.success(null, req.__('OTP_SENT'));
    }

    async verifyOtp(req: Request, res: Response) {
        const { company, otpType, verifyType, email, countryCode, phone, emailToken, phoneToken }: VerifyOtpBody =
            req.body;

        if (this.isRequestingEmailOTP(otpType, verifyType)) {
            try {
                await this.validateEmailOtpRequest({ company, otpType, email, emailToken });
            } catch (e: unknown) {
                const errorMessage = e instanceof Error ? e.message : 'GENERAL_ERROR';
                return res.warn(null, req.__(errorMessage));
            }
        }

        if (this.isRequestingPhoneOTP(otpType, verifyType)) {
            try {
                await this.validatePhoneOtpRequest({ company, otpType, countryCode, phone, phoneToken });
            } catch (e: unknown) {
                const errorMessage = e instanceof Error ? e.message : 'GENERAL_ERROR';
                return res.warn(null, req.__(errorMessage));
            }
        }

        if (otpType !== OtpType.CHANGE_PHONE && (verifyType === VerifyType.EMAIL || verifyType === VerifyType.BOTH)) {
            await OtpDao.updateOrCreateEmailOtp({
                company,
                email,
                data: {
                    isVerified: true,
                },
            });
        }

        if (otpType !== OtpType.CHANGE_EMAIL && (verifyType === VerifyType.PHONE || verifyType === VerifyType.BOTH)) {
            await OtpDao.updateOrCreatePhoneOtp({
                company,
                countryCode,
                phone,
                data: {
                    isVerified: true,
                },
            });
        }

        return res.success(null, req.__('OTP_VERIFIED'));
    }

    async logIn(req: Request, res: Response) {
        const { company, email, countryCode, phone, password }: UserLogIn = req.body;

        const user = await UserDao.getUserByEmailOrPhone({
            company,
            email,
            countryCode,
            phone,
        });

        if (!user || !user?.company) {
            return res.warn(null, req.__('USER_NOT_FOUND'));
        }

        if (user.status === Status.INACTIVE) {
            return res.warn(null, req.__('YOUR_ACCOUNT_SUSPENDED'));
        }

        const allowedFailedLoginAttempts = Number(process.env.ALLOWED_FAILED_LOGIN_ATTEMPTS ?? 5);
        const isAccountLocked =
            user.failedLoginAttempts >= allowedFailedLoginAttempts && moment().diff(user.preventLoginTill, 'ms') < 0;

        if (isAccountLocked) {
            return res.warn(null, req.__('ACCOUNT_LOCKED', showDate(user.preventLoginTill)));
        }

        const passwordMatched = await user.comparePassword(password);

        if (!passwordMatched) {
            await UserDao.updateUser({
                id: user._id,
                company: user.company,
                data: {
                    failedLoginAttempts: user.failedLoginAttempts + 1,
                    preventLoginTill: moment()
                        .add(process.env.PREVENT_LOGIN_ON_FAILED_ATTEMPTS_TILL ?? 10, 'minutes')
                        .valueOf(),
                },
            });

            const chanceLeft = allowedFailedLoginAttempts - user.failedLoginAttempts - 1;
            const message =
                chanceLeft <= 0
                    ? req.__('ACCOUNT_LOCKED', showDate(user.preventLoginTill))
                    : req.__('INVALID_LOGIN_CREDENTIALS', chanceLeft.toString());
            return res.warn(null, message);
        }

        const settings = await UserDao.getCompanySettings({ company: user.company });

        if (settings?.security?.isTwoFactorAuthenticationEnabled) {
            const userIdsToEnableMFA = (settings?.security?.otpSettings?.userIdsToEnableMFA ||
                []) as unknown as string[];
            const requiresMFA =
                settings?.security?.otpSettings?.isEnabledForAll || userIdsToEnableMFA.includes(user._id.toString());

            if (requiresMFA) {
                const MFAToken = generateOtp();
                const receiverUserIds = settings?.security?.otpSettings?.receiverUserIds || [];
                const receivers = await UserDao.getUserDetailsById({
                    company: user.company,
                    ids: receiverUserIds,
                });

                for (const receiver of receivers) {
                    const channels = settings?.security?.otpSettings?.channels || [];

                    if (!isDevEnv && channels.includes(OtpReceiverChannel.EMAIL)) {
                        sendMail('user-mfa-verify', req.__('MFA_CODE_FOR_USER', user.fullName), receiver.email, {
                            token: MFAToken,
                        }).catch(error => {
                            logger.error(
                                `AuthService:: login -> failed to send user-email-verify email to ${receiver.email}`,
                                error
                            );
                            throw error;
                        });
                    }

                    if (!isDevEnv && channels.includes(OtpReceiverChannel.SMS)) {
                        sendSMS('mfaVerification', `${receiver.countryCode}${receiver.phone}`, [
                            MFAToken,
                            user.fullName,
                        ]).catch(error => {
                            logger.error(
                                `AuthService:: login -> failed to send otpVerification SMS to ${receiver.countryCode}${receiver.phone}`,
                                error
                            );
                            throw error;
                        });
                    }
                }

                await UserDao.updateUser({
                    id: user._id,
                    company: user.company,
                    data: {
                        failedLoginAttempts: 0,
                        preventLoginTill: 0,
                        MFAToken,
                    },
                });

                return res.success({
                    isMFAEnabled: true,
                    user: user._id,
                });
            }
        }

        const authUpdates = {
            authTokenIssuedAt: moment().valueOf(),
            failedLoginAttempts: 0,
            preventLoginTill: 0,
        };

        await UserDao.updateUser({
            id: user._id,
            company: user.company,
            data: authUpdates,
        });

        const companyData = user.company as unknown as ICompanyDoc;
        const platform = getPlatform(req);
        const token = signToken({
            sub: `${user._id}-${companyData._id}`,
            iat: authUpdates.authTokenIssuedAt,
            aud: platform,
            sessionID: req.sessionID,
        });
        const userJson = getUserObj(user);
        userJson.company = companyData._id;

        return res.success({
            isMFAEnabled: false,
            token,
            user: userJson,
        });
    }

    async verifyMFA(req: Request, res: Response) {
        const { MFAToken, user: userId, company } = req.body;

        const user = await UserDao.getUserById({
            id: userId,
            company,
            accountType,
        });

        if (!user || !user?.company) {
            return res.warn(null, req.__('USER_NOT_FOUND'));
        }

        if (user.status === Status.INACTIVE) {
            return res.warn(null, req.__('YOUR_ACCOUNT_SUSPENDED'));
        }

        if (user.MFAToken !== MFAToken) {
            return res.success(null, req.__('INVALID_MFA_TOKEN'));
        }

        const authUpdates = {
            authTokenIssuedAt: moment().valueOf(),
            failedLoginAttempts: 0,
            preventLoginTill: 0,
            MFAToken: generateOtp(),
        };

        await UserDao.updateUser({
            id: userId,
            company: user.company,
            data: authUpdates,
        });
        const companyData = user.company as unknown as ICompanyDoc;
        const platform = getPlatform(req);
        const token = signToken({
            sub: `${user._id}-${companyData._id}`,
            iat: authUpdates.authTokenIssuedAt,
            aud: platform,
            sessionID: req.sessionID,
        });
        const userJson = getUserObj(user);
        userJson.company = companyData._id;

        return res.success({
            token,
            user: userJson,
        });
    }

    async logout(req: Request, res: Response) {
        const { user } = req;
        await UserDao.updateUser({
            id: user._id,
            company: user.company,
            data: {
                authTokenIssuedAt: 0,
            },
        });
        req.session.destroy(err => {
            if (err) {
                logger.error('AuthService :: logout : error in destroying session', err);
                throw err;
            }
        });

        return res.success(null, req.__('LOGOUT_SUCCESS'));
    }

    async resetPassword(req: Request, res: Response) {
        const { company, email, countryCode, phone, password }: ResetPassword = req.body;
        let emailVerified = false;
        let phoneVerified = false;

        if (email) {
            const emailOtp = await OtpDao.getEmailOtp({
                company,
                email,
                isVerified: true,
                otpType: OtpType.FORGOT_PASSWORD,
            });

            if (!emailOtp || moment(emailOtp.validTill).isBefore(moment())) {
                return res.warn(null, req.__('EMAIL_NOT_VERIFIED'));
            }

            emailVerified = true;
        }

        if (countryCode && phone) {
            const phoneOtp = await OtpDao.getPhoneOtp({
                company,
                countryCode,
                phone,
                isVerified: true,
                otpType: OtpType.FORGOT_PASSWORD,
            });

            if (!phoneOtp || moment(phoneOtp.validTill).isBefore(moment())) {
                return res.warn(null, req.__('PHONE_NOT_VERIFIED'));
            }

            phoneVerified = true;
        }

        if (!emailVerified && !phoneVerified) {
            return res.warn(null, req.__('EMAIL_PHONE_NOT_VERIFIED'));
        }

        const user = await UserDao.getUserByEmailOrPhone({
            company,
            email,
            countryCode,
            phone,
        });

        if (!user) {
            return res.warn(null, req.__('USER_NOT_FOUND'));
        }

        if (user.status === Status.INACTIVE) {
            return res.warn(null, req.__('YOUR_ACCOUNT_SUSPENDED'));
        }

        const passwordMatched = await user.comparePassword(password);

        if (passwordMatched) {
            return res.warn(null, req.__('NEW_PASSWORD_MATCHES_OLD_PASSWORD'));
        }

        await UserDao.updateUser({
            id: user._id,
            company: user.company,
            data: {
                password,
                authTokenIssuedAt: 0,
                failedLoginAttempts: 0,
                preventLoginTill: 0,
                askForPasswordReset: false,
            },
        });

        return res.success(null, req.__('PASSWORD_CHANGE_SUCCESS'));
    }

    async changePassword(req: Request, res: Response) {
        const { _id, company } = req.user;
        const { currentPassword, newPassword }: ChangePassword = req.body;

        const user = await UserDao.getUserById({ id: _id, company, accountType });

        if (!user) {
            return res.warn(null, req.__('USER_NOT_FOUND'));
        }

        const passwordMatched = await user.comparePassword(currentPassword);

        if (!passwordMatched) {
            return res.warn(null, req.__('OLD_PASSWORD_INCORRECT'));
        }

        await UserDao.updateUser({
            id: _id,
            company,
            data: {
                password: newPassword,
                askForPasswordReset: false,
            },
        });

        return res.success({ passwordMatched }, req.__('PASSWORD_CHANGE_SUCCESS'));
    }

    async getProfileById(req: Request, res: Response) {
        const { company, _id } = req.user;

        const user = await UserDao.getUserById({ id: _id, company, accountType });

        if (!user) {
            return res.notFound(null, req.__('USER_NOT_FOUND'));
        }

        return res.success(user);
    }

    async updateProfileById(req: Request, res: Response) {
        const { company, _id } = req.user;

        const data: IUpdateProfile = req.body;

        const user = await UserDao.getUserById({ id: _id, company, accountType });

        if (!user) {
            return res.notFound(null, req.__('USER_NOT_FOUND'));
        }

        const emailExists = await UserDao.getUserByEmail({
            id: user._id,
            company,
            email: data.email,
        });

        if (emailExists) {
            return res.badRequest(null, req.__('EMAIL_ALREADY_FOUND'));
        }

        const phoneExists = await UserDao.getUserByPhone({
            id: user._id,
            company,
            phone: data.phone,
            countryCode: data.countryCode,
        });

        if (phoneExists) {
            return res.badRequest(null, req.__('PHONE_ALREADY_FOUND'));
        }

        await UserDao.updateUser({ id: _id, company, data });

        return res.success(null, req.__('USER_UPDATE_SUCCESS'));
    }

    private isRequestingEmailOTP = (otpType: OtpType, verifyType: VerifyType) =>
        otpType !== OtpType.CHANGE_PHONE && (verifyType === VerifyType.EMAIL || verifyType === VerifyType.BOTH);

    private isRequestingPhoneOTP = (otpType: OtpType, verifyType: VerifyType) =>
        otpType !== OtpType.CHANGE_EMAIL && (verifyType === VerifyType.PHONE || verifyType === VerifyType.BOTH);

    private async validateEmailOtpRequest({ company, otpType, email, emailToken }: ValidateEmailOtpRequest) {
        if (otpType === OtpType.CHANGE_EMAIL) {
            const user = await UserDao.getUserByEmail({ company, email });

            if (user) {
                throw new Error('EMAIL_ALREADY_FOUND');
            }
        } else if (otpType === OtpType.FORGOT_PASSWORD) {
            const user = await UserDao.getUserByEmail({ company, email });

            if (!user) {
                throw new Error('USER_NOT_FOUND_WITH_EMAIL');
            }

            if (user.status === Status.INACTIVE) {
                throw new Error('YOUR_ACCOUNT_SUSPENDED');
            }
        }

        if (emailToken) {
            const otp = await OtpDao.getEmailOtp({
                company,
                email,
                otpType,
                isVerified: false,
            });

            if (otp?.token !== emailToken) {
                throw new Error('INVALID_EMAIL_OTP');
            }

            if (moment(otp.validTill).isBefore(moment())) {
                throw new Error('EMAIL_OTP_EXPIRED');
            }
        }
    }

    private async validatePhoneOtpRequest({
        company,
        otpType,
        countryCode,
        phone,
        phoneToken,
    }: ValidatePhoneOtpRequest) {
        if (OtpType.CHANGE_PHONE === otpType) {
            const user = await UserDao.getUserByPhone({ company, countryCode, phone });

            if (user) {
                throw new Error('PHONE_ALREADY_FOUND');
            }
        } else if (otpType === OtpType.FORGOT_PASSWORD) {
            const user = await UserDao.getUserByPhone({ company, countryCode, phone });

            if (!user) {
                throw new Error('USER_NOT_FOUND_WITH_PHONE');
            }

            if (user.status === Status.INACTIVE) {
                throw new Error('YOUR_ACCOUNT_SUSPENDED');
            }
        }

        if (phoneToken) {
            const otp = await OtpDao.getPhoneOtp({
                company,
                countryCode,
                phone,
                otpType,
                isVerified: false,
            });

            if (otp?.token !== phoneToken) {
                throw new Error('INVALID_PHONE_OTP');
            }

            if (moment(otp.validTill).isBefore(moment())) {
                throw new Error('PHONE_OTP_EXPIRED');
            }
        }
    }
}

export default new AuthService();
