import { Request, Response } from 'express';
import GroupDao from '../../dao/GroupDao';
import { CommonId, CommonStatus, IGroup, Status, Pagination } from '@homelead-shared-api';
import { GetGroups } from '@dto';

class GroupService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { search, status, page, perPage } = req.query as unknown as GetGroups & Pagination;

        const [count, groups] = await Promise.all([
            GroupDao.countAll({
                company,
                search,
                status,
            }),
            GroupDao.getAll({
                company,
                search,
                status,
                page,
                perPage,
            }),
        ]);

        return res.success({ count, groups });
    }

    async activeGroups(req: Request, res: Response) {
        const { company } = req.user;

        const activeGroups = await GroupDao.activeGroups({
            company,
        });

        return res.success(activeGroups);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;

        const groupData: IGroup = req.body;

        const response = await GroupDao.create({
            ...groupData,
            company,
        });

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const group = await GroupDao.getGroupWithMembersById({ id, company });

        if (!group) {
            return res.notFound(null, req.__('GROUP_NOT_FOUND'));
        }

        return res.success(group);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: IGroup = req.body;

        const group = await GroupDao.getById({ id, company });

        if (!group) {
            return res.notFound(null, req.__('GROUP_NOT_FOUND'));
        }

        await GroupDao.updateById({ id, company, data });

        return res.success(null, req.__('GROUP_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IGroup> = {
            status: Status.ARCHIVED,
        };

        const group = await GroupDao.getById({ id, company });

        if (!group) {
            return res.notFound(null, req.__('GROUP_NOT_FOUND'));
        }

        await GroupDao.updateById({ id, company, data });

        return res.success(null, req.__('GROUP_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const group = await GroupDao.getById({ id, company });

        if (!group) {
            return res.notFound(null, req.__('GROUP_NOT_FOUND'));
        }

        await GroupDao.updateById({ id, company, data });

        return res.success(null, req.__('GROUP_STATUS_UPDATED'));
    }
}

export default new GroupService();
