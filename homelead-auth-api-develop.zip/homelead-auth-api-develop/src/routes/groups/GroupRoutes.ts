import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import GroupService from './GroupService';
import GroupValidations from './GroupValidations';
import { validate } from '../../utils/validations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.GROUPS_LIST),
    validate(GroupValidations.getAll, 'query'),
    GroupService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.GROUPS_ADD),
    validate(GroupValidations.create),
    GroupService.create as RequestHandler
);

router.get('/active-groups', verifyToken(), GroupService.activeGroups as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.GROUPS_VIEW),
    validate(GroupValidations.requiredId, 'params'),
    GroupService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.GROUPS_UPDATE),
    validate(GroupValidations.requiredId, 'params'),
    validate(GroupValidations.create),
    GroupService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.GROUPS_DELETE),
    validate(GroupValidations.requiredId, 'params'),
    GroupService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.GROUPS_UPDATE),
    validate(GroupValidations.requiredId, 'params'),
    validate(GroupValidations.updateStatus),
    GroupService.updateStatus as RequestHandler
);

export { router };
