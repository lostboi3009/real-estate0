import { commonValidations, joi } from '@homelead-shared-api';

const getAll = joi.object().keys({
    search: joi.string().trim().optional(),
    status: commonValidations.status.optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const create = joi.object().keys({
    name: joi.string().trim().min(2).max(30).required(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    getAll,
    create,
    requiredId,
    updateStatus,
};
