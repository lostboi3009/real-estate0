import { GetTeams } from '@dto';
import { Request, Response } from 'express';
import { CommonId, CommonStatus, ITeam, Status, Pagination } from '@homelead-shared-api';
import TeamDao from '../../dao/TeamDao';

class TeamService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { search, status, page, perPage } = req.query as unknown as GetTeams & Pagination;

        const [count, teams] = await Promise.all([
            TeamDao.countAll({
                company,
                status,
                search,
            }),
            TeamDao.getAll({
                company,
                page,
                perPage,
                status,
                search,
            }),
        ]);

        return res.success({ count, teams });
    }

    async activeTeams(req: Request, res: Response) {
        const { company } = req.user;

        const activeTeams = await TeamDao.activeTeams({
            company,
        });

        return res.success(activeTeams);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;

        const team = await TeamDao.create({ ...req.body, company });

        return res.success(team);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const team = await TeamDao.getById({ id, company });

        if (!team) {
            return res.notFound(null, req.__('TEAM_NOT_FOUND'));
        }

        return res.success(team);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: ITeam = req.body;

        const team = await TeamDao.getById({ id, company });

        if (!team) {
            return res.notFound(null, req.__('TEAM_NOT_FOUND'));
        }

        await TeamDao.updateById({ id, data, company });

        return res.success(null, req.__('TEAM_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<ITeam> = {
            status: Status.ARCHIVED,
        };

        const team = await TeamDao.getById({ id, company });

        if (!team) {
            return res.notFound(null, req.__('TEAM_NOT_FOUND'));
        }

        await TeamDao.updateById({ id, data, company });

        return res.success(null, req.__('TEAM_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: CommonStatus = req.body;

        const team = await TeamDao.getById({ id, company });

        if (!team) {
            return res.notFound(null, req.__('TEAM_NOT_FOUND'));
        }

        await TeamDao.updateById({ id, data, company });

        return res.success(null, req.__('TEAM_STATUS_UPDATED'));
    }
}

export default new TeamService();
