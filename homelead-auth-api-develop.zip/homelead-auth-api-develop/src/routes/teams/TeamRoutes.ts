import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import TeamValidations from './TeamValidations';
import TeamService from './TeamService';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.TEAMS_LIST),
    validate(TeamValidations.getAll, 'query'),
    TeamService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.TEAMS_ADD),
    validate(TeamValidations.create),
    TeamService.create as RequestHandler
);

router.get('/active-teams', verifyToken(), TeamService.activeTeams as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.TEAMS_VIEW),
    validate(TeamValidations.requiredId, 'params'),
    TeamService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.TEAMS_UPDATE),
    validate(TeamValidations.requiredId, 'params'),
    validate(TeamValidations.create),
    TeamService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.TEAMS_DELETE),
    validate(TeamValidations.requiredId, 'params'),
    TeamService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.TEAMS_UPDATE),
    validate(TeamValidations.requiredId, 'params'),
    validate(TeamValidations.updateStatus),
    TeamService.updateStatus as RequestHandler
);

export { router };
