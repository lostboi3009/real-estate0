import { CustomHelpers } from 'joi';
import { commonValidations, joi } from '@homelead-shared-api';

const create = joi.object().keys({
    name: joi.string().trim().min(3).max(30).required(),
    groups: joi.array().items(commonValidations.id).optional(),
    members: joi
        .array()
        .items(commonValidations.id)
        .min(1)
        .max(10)
        .unique()
        .custom((value: string[], helpers: CustomHelpers) => {
            const teamLead = helpers.state.ancestors[0].teamLead;
            const defaultPrimary = helpers.state.ancestors[0].defaultPrimary;
            const defaultSecondary = helpers.state.ancestors[0].defaultSecondary;

            if (!value.includes(teamLead) || !value.includes(defaultPrimary) || !value.includes(defaultSecondary)) {
                return helpers.error('any.invalid');
            }

            return value;
        })
        .required(),
    teamLead: commonValidations.id,
    defaultPrimary: commonValidations.id,
    defaultSecondary: commonValidations.id,
});

const getAll = joi.object().keys({
    search: joi.string().trim().optional(),
    status: commonValidations.status.optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    create,
    getAll,
    requiredId,
    updateStatus,
};
