import { commonValidations, joi } from '@homelead-shared-api';

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const getAll = joi.object().keys({
    search: joi.string().trim().optional(),
    status: commonValidations.status.optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const create = joi.object().keys({
    firstName: joi.string().trim().min(3).max(30).required(),
    lastName: joi.string().trim().min(3).max(30).required(),
    email: commonValidations.email,
    countryCode: commonValidations.countryCode,
    phone: commonValidations.phone,
    password: commonValidations.password,
    secondaryCountryCode: commonValidations.countryCode.optional(),
    secondaryPhone: commonValidations.phone.optional(),
    status: commonValidations.status,
    groups: joi.array().items(commonValidations.id).optional(),
    designation: commonValidations.id,
    isReportingManager: joi.boolean().optional(),
    reportsTo: commonValidations.id.optional(),
    avatar: joi.string().trim().optional(),
    description: joi.string().trim().max(400),
});

const update = joi.object().keys({
    firstName: joi.string().trim().min(3).max(30).required(),
    lastName: joi.string().trim().min(3).max(30).required(),
    email: commonValidations.email,
    countryCode: commonValidations.countryCode,
    phone: commonValidations.phone,
    secondaryCountryCode: commonValidations.countryCode.optional(),
    secondaryPhone: commonValidations.phone.optional(),
    status: commonValidations.status,
    groups: joi.array().items(commonValidations.id).optional(),
    designation: commonValidations.id,
    isReportingManager: joi.boolean().optional(),
    reportsTo: commonValidations.id.optional(),
    avatar: joi.string().trim().optional(),
    description: joi.string().trim().max(400),
});

const updatePassword = joi.object().keys({ newPassword: commonValidations.password });

const updatePermission = joi
    .object()
    .keys({
        userIds: joi.array().items(commonValidations.id).optional(),
        groupIds: joi.array().items(commonValidations.id).optional(),
        permissions: joi.object().pattern(joi.string(), joi.array().items(joi.string())).required(),
    })
    .xor('userIds', 'groupIds')
    .or('userIds', 'groupIds');

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

const isEmailExists = joi.object().keys({
    email: commonValidations.email,
    id: commonValidations.id.optional(),
});

const isPhoneExists = joi.object().keys({
    phone: commonValidations.phone,
    countryCode: commonValidations.countryCode,
    id: commonValidations.id.optional(),
});

export default {
    requiredId,
    getAll,
    create,
    update,
    updatePassword,
    updatePermission,
    updateStatus,
    isEmailExists,
    isPhoneExists,
};
