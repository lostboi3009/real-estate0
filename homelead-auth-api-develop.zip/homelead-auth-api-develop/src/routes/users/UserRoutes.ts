import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import UserService from './UserService';
import UserValidations from './UserValidations';
import { validate } from '../../utils/validations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.USERS_LIST),
    validate(UserValidations.getAll, 'query'),
    UserService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.USERS_ADD),
    validate(UserValidations.create),
    UserService.create as RequestHandler
);

router.get('/active-users', verifyToken(), UserService.getActiveUsers as RequestHandler);

router.get('/reporting-managers', verifyToken(), UserService.getReportingManagers as RequestHandler);

router.get(
    '/permissions',
    verifyToken(UserPermissions.USERS_UPDATE_PERMISSION),
    UserService.getAllPermissions as RequestHandler
);

router.put(
    '/permissions',
    verifyToken(UserPermissions.USERS_UPDATE_PERMISSION),
    validate(UserValidations.updatePermission),
    UserService.updatePermission as RequestHandler
);

router.post(
    '/is-email-exists',
    verifyToken(),
    validate(UserValidations.isEmailExists),
    UserService.isEmailExists as RequestHandler
);

router.post(
    '/is-phone-exists',
    verifyToken(),
    validate(UserValidations.isPhoneExists),
    UserService.isPhoneExists as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.USERS_VIEW),
    validate(UserValidations.requiredId, 'params'),
    UserService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.USERS_UPDATE),
    validate(UserValidations.requiredId, 'params'),
    validate(UserValidations.update),
    UserService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.USERS_DELETE),
    validate(UserValidations.requiredId, 'params'),
    UserService.deleteById as RequestHandler
);

router.patch(
    '/:id/update-password',
    verifyToken(UserPermissions.USERS_UPDATE_PASSWORD),
    validate(UserValidations.updatePassword),
    UserService.updatePassword as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.USERS_UPDATE),
    validate(UserValidations.requiredId, 'params'),
    validate(UserValidations.updateStatus),
    UserService.updateStatus as RequestHandler
);

export { router };
