import { Request, Response } from 'express';
import UserDao from '../../dao/UserDao';
import {
    CommonId,
    CommonStatus,
    IGroup,
    IPermissionData,
    IUser,
    Status,
    TypesObjectId,
    UserAccountType,
    IGroupDoc,
    Pagination,
    toObjectId,
    IPlanDoc,
    IPermissionDoc,
    IPermission,
} from '@homelead-shared-api';
import { GetUserByEmail, GetUserByPhone, GetUsers, UpdatePermission } from '@dto';
import GroupDao from '../../dao/GroupDao';

class UserService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { search, status, page, perPage } = req.query as unknown as GetUsers & Pagination;
        const [count, users] = await Promise.all([
            UserDao.countAllSubAdmins({
                company,
                status,
                search,
            }),
            UserDao.getAllSubAdmins({
                company,
                page,
                perPage,
                status,
                search,
            }),
        ]);

        return res.success({
            count,
            users,
        });
    }

    async getActiveUsers(req: Request, res: Response) {
        const { company } = req.user;

        const users = await UserDao.getActiveSubAdmins({
            company,
        });

        return res.success(users);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        let groups: IGroupDoc[] = [];
        const data: IUser = {
            ...req.body,
            company,
            accountType: UserAccountType.COMPANY_SUB_ADMIN,
        };

        const emailExists = await UserDao.getUserByEmail({
            company,
            email: data.email,
        });

        if (emailExists) {
            return res.badRequest(null, req.__('EMAIL_ALREADY_FOUND'));
        }

        const phoneExists = await UserDao.getUserByPhone({
            company,
            phone: data.phone,
            countryCode: data.countryCode,
        });

        if (phoneExists) {
            return res.badRequest(null, req.__('PHONE_ALREADY_FOUND'));
        }

        if (data?.groups?.length) {
            groups = await GroupDao.getByIds({ ids: data?.groups, company });

            if (groups?.length !== data?.groups?.length) {
                return res.badRequest(null, req.__('GROUP_NOT_FOUND'));
            }

            const permissions: IPermissionData = {};
            groups.forEach(group => {
                if (group.permissions) {
                    Object.entries(group.permissions).forEach(([key, value]) => {
                        if (!permissions[key]) {
                            permissions[key] = [];
                        }

                        permissions[key] = [...new Set([...permissions[key], ...value])];
                    });
                }
            });

            data.permissions = permissions;
        }

        const userData = await UserDao.create(data);

        if (data?.groups?.length) {
            await GroupDao.addUserToGroups({
                ids: data?.groups || [],
                memberIds: [userData?._id],
            });
        }

        return res.success(userData);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const user = await UserDao.getSubAdminDetailsById({ id, company });

        if (!user) {
            return res.notFound(null, req.__('USER_NOT_FOUND'));
        }

        return res.success(user);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: IUser = req.body;

        const user = await UserDao.getSubAdminById({ id, company });

        if (!user) {
            return res.notFound(null, req.__('USER_NOT_FOUND'));
        }

        const emailExists = await UserDao.getUserByEmail({
            id: user._id,
            company,
            email: data.email,
        });

        if (emailExists) {
            return res.badRequest(null, req.__('EMAIL_ALREADY_FOUND'));
        }

        const phoneExists = await UserDao.getUserByPhone({
            id: user._id,
            company,
            phone: data.phone,
            countryCode: data.countryCode,
        });

        if (phoneExists) {
            return res.badRequest(null, req.__('PHONE_ALREADY_FOUND'));
        }

        const existingGroups = user?.groups?.map(i => i.toString());
        const isGroupsModified =
            existingGroups?.length !== data?.groups?.length ||
            existingGroups?.some(i => !data?.groups?.includes(i as unknown as TypesObjectId));

        if (isGroupsModified) {
            const userIds: TypesObjectId[] = [user._id];
            const existingGroupIds = existingGroups?.map(i => toObjectId(i)) as unknown as TypesObjectId[];

            const groups: IGroupDoc[] = await GroupDao.getByIds({ ids: data?.groups || [], company });

            if (groups?.length !== data?.groups?.length) {
                return res.badRequest(null, req.__('GROUP_NOT_FOUND'));
            }

            await GroupDao.removeUserFromGroups({
                ids: existingGroupIds,
                memberIds: userIds,
            });

            await GroupDao.addUserToGroups({
                ids: data?.groups || [],
                memberIds: userIds,
            });

            const permissions: IPermissionData = {};
            groups.forEach(group => {
                if (group.permissions) {
                    Object.entries(group.permissions).forEach(([key, value]) => {
                        if (!permissions[key]) {
                            permissions[key] = [];
                        }

                        permissions[key] = [...new Set([...permissions[key], ...value])];
                    });
                }
            });

            data.permissions = permissions;
        }

        await UserDao.updateUser({ id, company, data });

        return res.success(null, req.__('USER_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IUser> = {
            status: Status.ARCHIVED,
        };

        const user = await UserDao.getSubAdminById({ id, company });

        if (!user) {
            return res.notFound(null, req.__('USER_NOT_FOUND'));
        }

        await UserDao.updateUser({ id, company, data });

        return res.success(null, req.__('USER_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const user = await UserDao.getSubAdminById({ id, company });

        if (!user) {
            return res.notFound(null, req.__('USER_NOT_FOUND'));
        }

        await UserDao.updateUser({ id, company, data });

        return res.success(null, req.__('USER_STATUS_UPDATED'));
    }

    async getAllPermissions(req: Request, res: Response) {
        const { company } = req.user;

        const companyData = await UserDao.getCompanyById({
            id: company,
        });

        if (!companyData || !companyData.plan) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        const plan = companyData.plan as unknown as IPlanDoc;
        const planPermissions: IPermissionData = plan.permissions || {};
        const slugs = Object.keys(planPermissions);
        const actions = Object.values(planPermissions).flat();

        const permissionsData = await UserDao.getAllPermissions({
            slugs,
        });

        const permissions = permissionsData.map((i: IPermissionDoc) => {
            const permission = <IPermission>i.toJSON();
            permission.actions = permission.actions.filter(j => actions.includes(j.slug));
            return permission;
        });

        return res.success(permissions);
    }

    async updatePermission(req: Request, res: Response) {
        const { groupIds, userIds, permissions }: UpdatePermission = req.body;
        const { company } = req.user;

        if (groupIds?.length) {
            const groups: IGroup[] = await GroupDao.getByIds({ ids: groupIds, company });

            if (groups?.length !== groupIds.length) {
                return res.badRequest(null, req.__('GROUP_NOT_FOUND'));
            }

            const userIds: TypesObjectId[] = [...new Set(groups.flatMap(group => group.members))];

            await UserDao.updateUsersPermissions({ company, userIds, permissions });

            await GroupDao.updateGroupPermissions({ groupIds, company, permissions });
        }

        if (userIds?.length) {
            await UserDao.updateUsersPermissions({ company, userIds, permissions });
        }

        return res.success(null, req.__('PERMISSION_UPDATED'));
    }

    async updatePassword(req: Request, res: Response) {
        const { company } = req.user;
        const { newPassword } = req.body;
        const { id } = req.params as unknown as CommonId;

        const user = await UserDao.getSubAdminById({ id, company });

        if (!user) {
            return res.notFound(null, req.__('USER_NOT_FOUND'));
        }

        await UserDao.updateUser({
            id,
            company,
            data: {
                password: newPassword,
            },
        });

        return res.success(null, req.__('USER_PASSWORD_UPDATED'));
    }

    async isEmailExists(req: Request, res: Response) {
        const { email, id }: GetUserByEmail = req.body;
        const { company } = req.user;

        const isEmailExists = await UserDao.getUserByEmail({
            id,
            company,
            email,
        });

        return res.success({
            isEmailExists: isEmailExists !== null,
        });
    }

    async isPhoneExists(req: Request, res: Response) {
        const { phone, countryCode, id }: GetUserByPhone = req.body;
        const { company } = req.user;

        const isPhoneExists = await UserDao.getUserByPhone({
            id,
            company,
            phone,
            countryCode,
        });

        return res.success({
            isPhoneExists: isPhoneExists !== null,
        });
    }

    async getReportingManagers(req: Request, res: Response) {
        const { company } = req.user;

        const users = await UserDao.getAllReportingManager({
            company,
        });

        return res.success(users);
    }
}

export default new UserService();
