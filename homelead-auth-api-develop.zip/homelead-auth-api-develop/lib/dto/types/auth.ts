import { IOtp, VerifyType, OtpType, Platform, TypesObjectId } from '@homelead-shared-api';
import { Languages } from '@dto';

export interface RequestOtpBody {
    company: TypesObjectId;
    otpType: OtpType;
    verifyType: VerifyType;
    email: string;
    countryCode: string;
    phone: string;
}

export interface VerifyOtpBody extends RequestOtpBody {
    emailToken: string;
    phoneToken: string;
}

export interface ValidateEmailOtpRequest {
    company: TypesObjectId;
    otpType: OtpType;
    email: string;
    emailToken?: string;
}

export interface ValidatePhoneOtpRequest {
    company: TypesObjectId;
    otpType: OtpType;
    countryCode: string;
    phone: string;
    phoneToken?: string;
}

export interface GetEmailOtp {
    company: TypesObjectId;
    email: string;
    otpType: OtpType;
    isVerified: boolean;
}

export interface GetPhoneOtp {
    company: TypesObjectId;
    countryCode: string;
    phone: string;
    otpType: OtpType;
    isVerified: boolean;
}

export type UpdateOrCreateOtp<T> = T & { data: Partial<IOtp> };

export interface UpdateOrCreateEmailOtp {
    company: TypesObjectId;
    email: string;
    data: Partial<IOtp>;
}

export interface UpdateOrCreatePhoneOtp {
    company: TypesObjectId;
    countryCode: string;
    phone: string;
    data: Partial<IOtp>;
}

export interface UserLogIn {
    company: TypesObjectId;
    email?: string;
    countryCode?: string;
    phone?: string;
    password: string;
}

export interface ResetPassword {
    company: TypesObjectId;
    email?: string;
    countryCode?: string;
    phone?: string;
    password: string;
}

export interface SignToken {
    sub: string;
    iat: number;
    sessionID: string;
}

export interface SignUserToken extends SignToken {
    aud: Platform;
}

export interface VerifyUserAccess {
    platform: Platform;
    language: Languages;
    token: string;
    permission?: string;
    sessionID?: string;
    originalUrl?: string;
}

export interface ChangePassword {
    currentPassword: string;
    newPassword: string;
}

export interface GetCompanyBySubDomain {
    subDomain: string;
}
