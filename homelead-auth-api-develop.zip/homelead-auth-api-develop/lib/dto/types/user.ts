import { IUser, Status, CommonId, CompanyId, TypesObjectId, IPermissionData } from '@homelead-shared-api';

export interface EmailAddress {
    email: string;
}

export interface CountryCodeAndPhone {
    countryCode: string;
    phone: string;
}

export interface GetUserByEmail extends EmailAddress {
    id?: TypesObjectId;
    company?: TypesObjectId;
}

export interface GetUserByPhone extends CountryCodeAndPhone {
    id?: TypesObjectId;
    company?: TypesObjectId;
}

export interface GetUserByEmailAndPhone {
    company: TypesObjectId;
    email?: string;
    countryCode?: string;
    phone?: string;
}

export interface UpdateUser extends CommonId {
    company?: TypesObjectId;
    data: Partial<IUser>;
}

export interface GetUsers extends CompanyId {
    status: Status;
    search: string;
}

export interface UpdatePermission {
    groupIds: TypesObjectId[];
    userIds: TypesObjectId[];
    permissions: IPermissionData;
}

export interface IUpdateProfile {
    firstName: string;
    lastName: string;
    email: string;
    countryCode: string;
    phone: string;
    secondaryCountryCode?: string;
    secondaryPhone?: string;
    avatar?: string;
}
