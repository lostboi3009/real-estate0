import { CompanyId, Status } from '@homelead-shared-api';

export interface GetTeams extends CompanyId {
    status?: Status;
    search?: string;
}
