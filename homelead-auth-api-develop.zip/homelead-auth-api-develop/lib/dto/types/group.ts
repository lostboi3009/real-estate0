import { CommonId, CompanyId, IGroup, Status } from '@homelead-shared-api';

export interface GetGroups extends CompanyId {
    status?: Status;
    search?: string;
}

export interface UpdateGroup extends CommonId, CompanyId {
    data: Partial<IGroup>;
}
