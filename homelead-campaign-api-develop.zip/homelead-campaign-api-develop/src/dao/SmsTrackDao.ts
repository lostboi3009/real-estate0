import { SmsTrack, ISmsTrackDoc, ISmsTrack, SmsStatus, CommonId, CompanyId, mongoose } from '@homelead-shared-api';
import { GetSmsTrackByCampaignId } from '@dto';

class SmsTrackDao {
    async getByCampaignId({ campaign, company }: GetSmsTrackByCampaignId): Promise<ISmsTrackDoc[]> {
        return SmsTrack.find({ campaign, company, smsStatus: SmsStatus.PENDING });
    }

    async markAsDelivered({ id, company }: CommonId & CompanyId) {
        return SmsTrack.updateMany(
            {
                campaign: id,
                emailStatus: SmsStatus.PENDING,
                company,
            },
            {
                $set: {
                    smsStatus: SmsStatus.DELIVERED,
                },
            }
        );
    }

    async bulkCreate(smsTracks: ISmsTrack[]) {
        return SmsTrack.insertMany(smsTracks);
    }

    async deleteByCampaignId({ id, company }: CommonId & CompanyId): Promise<mongoose.DeleteResult> {
        return SmsTrack.deleteMany({
            company,
            campaign: id,
        });
    }
}

export default new SmsTrackDao();
