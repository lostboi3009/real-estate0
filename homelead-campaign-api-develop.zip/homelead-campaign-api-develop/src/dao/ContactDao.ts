import {
    CommonId,
    CompanyId,
    Contact,
    getSearchRegex,
    IContact,
    IContactDoc,
    mongoose,
    Pagination,
    Status,
} from '@homelead-shared-api';
import { ContactTargets, GetContacts } from '@dto';

type FilterQueryIContact = mongoose.FilterQuery<IContact>;

class ContactDao {
    async getEmailTargets({ company, targets }: ContactTargets): Promise<IContactDoc[]> {
        return Contact.find({
            _id: {
                $in: targets,
            },
            company,
            status: Status.ACTIVE,
            email: {
                $exists: true,
            },
        });
    }

    async getSmsTargets({ company, targets }: ContactTargets): Promise<IContactDoc[]> {
        return Contact.find({
            _id: {
                $in: targets,
            },
            company,
            status: Status.ACTIVE,
            phone: {
                $exists: true,
            },
            countryCode: {
                $exists: true,
            },
        });
    }

    async getAll({ company, page, perPage, search, status }: GetContacts & Pagination): Promise<IContactDoc[]> {
        const matchCriteria: FilterQueryIContact = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { name: { $regex: searchRegex } },
                { email: { $regex: searchRegex } },
                { phone: { $regex: searchRegex } },
            ];
        }

        return Contact.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .sort({ _id: -1 });
    }

    async countAll({ company, search, status }: GetContacts): Promise<number> {
        const matchCriteria: FilterQueryIContact = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { name: { $regex: searchRegex } },
                { email: { $regex: searchRegex } },
                { phone: { $regex: searchRegex } },
            ];
        }

        return Contact.countDocuments(matchCriteria);
    }

    async getActiveContacts({ company }: CompanyId): Promise<IContactDoc[]> {
        return Contact.find({
            company,
            status: Status.ACTIVE,
        }).sort({ _id: -1 });
    }

    async create(contact: IContact): Promise<IContactDoc> {
        return Contact.create(contact);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IContactDoc | null> {
        return Contact.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, company, data }: CommonId & CompanyId & { data: Partial<IContact> }) {
        return Contact.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new ContactDao();
