import {
    CampaignTemplate,
    CommonId,
    CompanyId,
    getSearchRegex,
    ICampaignTemplate,
    ICampaignTemplateDoc,
    mongoose,
    Pagination,
    Status,
} from '@homelead-shared-api';
import { GetTemplates, GetTemplatesByTemplateType } from '@dto';

type FilterQueryITemplate = mongoose.FilterQuery<ICampaignTemplate>;
class TemplateDao {
    async getAll({ company, page, perPage, search }: GetTemplates & Pagination): Promise<ICampaignTemplateDoc[]> {
        const matchCriteria: FilterQueryITemplate = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }];
        }

        return CampaignTemplate.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .sort({ _id: -1 });
    }

    async countAll({ company, search }: GetTemplates): Promise<number> {
        const matchCriteria: FilterQueryITemplate = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }];
        }

        return CampaignTemplate.countDocuments(matchCriteria);
    }

    async getActive({ company }: CompanyId): Promise<ICampaignTemplateDoc[]> {
        return CampaignTemplate.find({
            company,
            status: { $in: Status.ACTIVE },
        }).sort({ _id: -1 });
    }

    async create(template: ICampaignTemplate): Promise<ICampaignTemplateDoc> {
        return CampaignTemplate.create(template);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<ICampaignTemplateDoc | null> {
        return CampaignTemplate.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getByTemplateType({
        company,
        id,
        templateType,
    }: GetTemplatesByTemplateType): Promise<ICampaignTemplateDoc | null> {
        return CampaignTemplate.findOne({
            _id: id,
            company,
            templateType,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data, company }: CommonId & CompanyId & { data: Partial<ICampaignTemplate> }) {
        return CampaignTemplate.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new TemplateDao();
