import {
    CommonId,
    CompanyId,
    EmailStatus,
    EmailTrack,
    IEmailTrack,
    IEmailTrackDoc,
    mongoose,
} from '@homelead-shared-api';
import { GetEmailTrackByCampaignId } from '@dto';

class EmailTrackDao {
    async getByCampaignId({ campaign, company }: GetEmailTrackByCampaignId): Promise<IEmailTrackDoc[]> {
        return EmailTrack.find({ campaign, company, emailStatus: EmailStatus.PENDING });
    }

    async markAsDelivered({ id, company }: CommonId & CompanyId) {
        return EmailTrack.updateMany(
            {
                campaign: id,
                emailStatus: EmailStatus.PENDING,
                company,
            },
            {
                $set: {
                    emailStatus: EmailStatus.DELIVERED,
                },
            }
        );
    }

    async bulkCreate(emailTracks: IEmailTrack[]) {
        return EmailTrack.insertMany(emailTracks);
    }

    async deleteByCampaignId({ id, company }: CommonId & CompanyId): Promise<mongoose.DeleteResult> {
        return EmailTrack.deleteMany({
            company,
            campaign: id,
        });
    }
}

export default new EmailTrackDao();
