import { User, CommonId, CompanyId, IUserDoc, Status, AccountType, ISettingDoc, Setting } from '@homelead-shared-api';
import { UpdateUser } from '@dto';

class UserDao {
    getUserById({ id, company, accountType }: CommonId & CompanyId & AccountType): Promise<IUserDoc | null> {
        return User.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: {
                $in: accountType,
            },
        });
    }

    async updateUser({ id, company, data }: UpdateUser) {
        return User.updateOne(
            {
                company,
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
    async getCompanySettings({ company }: CompanyId): Promise<ISettingDoc | null> {
        return Setting.findOne({
            company,
        }).sort({
            _id: -1,
        });
    }
}

export default new UserDao();
