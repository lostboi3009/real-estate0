import mongoose from 'mongoose';
import {
    Campaign,
    CampaignStatus,
    CommonId,
    CompanyId,
    getSearchRegex,
    ICampaign,
    ICampaignDoc,
    Pagination,
    Status,
} from '@homelead-shared-api';
import { CampaignById, GetCampaign } from '@dto';

type FilterQueryICampaign = mongoose.FilterQuery<ICampaign>;

class CampaignDao {
    async create(campaign: ICampaign): Promise<ICampaignDoc> {
        return Campaign.create(campaign);
    }

    async getAll({
        company,
        page,
        perPage,
        campaignStatus,
        status,
        search,
        campaignType,
        fromDate,
        toDate,
    }: GetCampaign & Pagination): Promise<ICampaignDoc[]> {
        const matchCriteria: FilterQueryICampaign = {
            company,
            campaignType,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (campaignStatus) {
            matchCriteria.campaignStatus = campaignStatus;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }, { subject: { $regex: searchRegex } }];
        }

        if (fromDate && toDate) {
            matchCriteria.createdAt = {
                $gte: new Date(fromDate),
                $lte: new Date(toDate),
            };
        }

        return Campaign.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .sort({ _id: -1 });
    }

    async count({
        company,
        campaignStatus,
        status,
        search,
        campaignType,
        fromDate,
        toDate,
    }: GetCampaign): Promise<number> {
        const matchCriteria: FilterQueryICampaign = {
            company,
            campaignType,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (campaignStatus) {
            matchCriteria.campaignStatus = campaignStatus;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ name: { $regex: searchRegex } }, { subject: { $regex: searchRegex } }];
        }

        if (fromDate && toDate) {
            matchCriteria.createdAt = {
                $gte: new Date(fromDate),
                $lte: new Date(toDate),
            };
        }

        return Campaign.countDocuments(matchCriteria);
    }

    async getCampaignById({ id, company, campaignType }: CampaignById): Promise<ICampaignDoc | null> {
        return Campaign.findOne({
            _id: id,
            company,
            status: {
                $ne: Status.ARCHIVED,
            },
            campaignType,
        }).populate([{ path: 'targets', select: 'name email countryCode phone' }]);
    }

    async getById({ id, company }: CampaignById): Promise<ICampaignDoc | null> {
        return Campaign.findOne({
            _id: id,
            company,
            status: {
                $ne: Status.ARCHIVED,
            },
        });
    }

    async updateStatus({ id, company, campaignStatus }: CommonId & CompanyId & { campaignStatus: CampaignStatus }) {
        return Campaign.updateOne(
            {
                _id: id,
                company,
                status: {
                    $ne: Status.ARCHIVED,
                },
            },
            {
                $set: {
                    campaignStatus,
                },
            }
        );
    }

    async updateCampaignById({ id, company, data }: CommonId & CompanyId & { data: Partial<ICampaign> }) {
        return Campaign.updateOne(
            {
                _id: id,
                company,
                status: {
                    $ne: Status.ARCHIVED,
                },
            },
            {
                $set: data,
            }
        );
    }
}

export default new CampaignDao();
