import { CampaignService, CampaignStatus } from '@homelead-shared-api';
import CampaignDao from '../../dao/CampaignDao';
import SmsTrackDao from '../../dao/SmsTrackDao';
import { handleSmsSend } from '../../utils/sms';
import { SendSmsTrack } from '@dto';

class Service {
    async sendSmsCampaign({ campaign, company }: SendSmsTrack) {
        const campaignData = await CampaignDao.getById({ id: campaign, company });
        const targets = await SmsTrackDao.getByCampaignId({ campaign, company });

        await CampaignDao.updateStatus({
            id: campaign,
            company,
            campaignStatus: CampaignStatus.IN_PROGRESS,
        });

        for (const target of targets) {
            await handleSmsSend({
                fromNumber: process.env.TWILIO_FROM_PHONE,
                msg: target.message,
                serviceType: campaignData?.service as CampaignService,
                toNumber: `${target.countryCode}${target.phone}`,
            });
        }

        await SmsTrackDao.markAsDelivered({
            id: campaign,
            company,
        });

        await CampaignDao.updateStatus({
            id: campaign,
            company,
            campaignStatus: CampaignStatus.DELIVERED,
        });
    }
}

export default new Service();
