import Agenda from 'agenda';
import { logger } from '@homelead-shared-api';
import { DefineJob, Job, SendSmsTrack } from '@dto';
import Service from './Service';

const defineJob: DefineJob = async (jobName: string, agenda: Agenda) => {
    agenda.define(jobName, { priority: 0 }, async (job: { attrs: { data: SendSmsTrack } }, done) => {
        logger.info(`:: JOB "${jobName}" STARTED ::`);
        try {
            const { campaign, company } = job.attrs.data;
            await Service.sendSmsCampaign({ campaign, company });
            done();
        } catch (e) {
            logger.error(`:: JOB "${jobName}" FAILED WITH ERROR`, e);
            throw e;
        }
    });
};

const job: Job = {
    defineJob,
};

export default job;
