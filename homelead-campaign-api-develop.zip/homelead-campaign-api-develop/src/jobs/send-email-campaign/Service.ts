import { CampaignService, CampaignStatus } from '@homelead-shared-api';
import { SendEmailTrack } from '@dto';
import CampaignDao from '../../dao/CampaignDao';
import EmailTrackDao from '../../dao/EmailTrackDao';
import { handleEmailSend } from '../../utils/email';

class Service {
    async sendEmailCampaign({ campaign, company }: SendEmailTrack) {
        const campaignData = await CampaignDao.getById({ id: campaign, company });
        const targets = await EmailTrackDao.getByCampaignId({ campaign, company });

        await CampaignDao.updateStatus({
            id: campaign,
            company,
            campaignStatus: CampaignStatus.IN_PROGRESS,
        });

        for (const target of targets) {
            await handleEmailSend({
                body: target.message,
                from: process.env.TWILIO_FROM_EMAIL,
                serviceType: campaignData?.service as CampaignService,
                to: target.email,
                subject: target.subject,
            });
        }

        await EmailTrackDao.markAsDelivered({
            id: campaign,
            company,
        });

        await CampaignDao.updateStatus({
            id: campaign,
            company,
            campaignStatus: CampaignStatus.DELIVERED,
        });
    }
}

export default new Service();
