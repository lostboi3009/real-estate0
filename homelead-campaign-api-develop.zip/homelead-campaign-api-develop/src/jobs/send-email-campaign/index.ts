import Agenda from 'agenda';
import { logger } from '@homelead-shared-api';
import { DefineJob, Job, SendEmailTrack } from '@dto';
import Service from './Service';

const defineJob: DefineJob = async (jobName: string, agenda: Agenda) => {
    agenda.define(jobName, { priority: 0 }, async (job: { attrs: { data: SendEmailTrack } }, done) => {
        logger.info(`:: JOB "${jobName}" STARTED ::`);
        try {
            const { campaign, company } = job.attrs.data;
            await Service.sendEmailCampaign({ campaign, company });
            done();
        } catch (e) {
            logger.error(`:: JOB "${jobName}" FAILED WITH ERROR`, e);
            throw e;
        }
    });
};

const job: Job = {
    defineJob,
};

export default job;
