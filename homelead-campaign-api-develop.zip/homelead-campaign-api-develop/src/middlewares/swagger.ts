import path from 'path';
import YAML from 'yamljs';
import { Express } from 'express';
import swaggerUi from 'swagger-ui-express';
import { isDevEnv, swaggerComponents } from '@homelead-shared-api';

const swaggerDocument = YAML.load(path.resolve(__dirname, '../docs/swagger.yaml'));

swaggerDocument.components = swaggerComponents;

export const swagger = (app: Express) => {
    if (isDevEnv) {
        app.use(
            '/campaign-api/api-docs',
            swaggerUi.serve,
            swaggerUi.setup(swaggerDocument, {
                customfavIcon: '/favicon-32x32.png',
                customSiteTitle: process.env.SITE_TITLE,
                swaggerOptions: {
                    filter: true,
                    displayRequestDuration: true,
                },
            })
        );
    }
};
