import { joi } from '@homelead-shared-api';

const createPost = joi.object().keys({
    imageUrl: joi.string().trim().required(),
    caption: joi.string().trim().optional(),
});

export default {
    createPost,
};
