import { RequestHandler, Router } from 'express';
import InstagramService from './InstagramService';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import InstagramValidations from './InstagramValidations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.post(
    '/post',
    verifyToken(UserPermissions.CAMPAIGNS_INSTAGRAM_ADD),
    validate(InstagramValidations.createPost),
    InstagramService.createPost as RequestHandler
);

export { router };
