import { Request, Response } from 'express';
import axios from 'axios';
import UserDao from '../../dao/UserDao';

class InstagramService {
    async createPost(req: Request, res: Response) {
        const { company } = req.user;
        const credential = await UserDao.getCompanySettings({
            company,
        });

        const accountId = credential?.credentials.instagram?.accountId;
        const accessToken = credential?.credentials.instagram?.accessToken;

        if (!accessToken || !accountId) {
            res.warn(null, req.__('INSTAGRAM_NOT_CONNECTED'));
        }

        const containerResponse = await axios.post(
            `https://graph.instagram.com/v21.0/${accountId}/media`,
            {},
            {
                params: {
                    image_url: req.body.imageUrl,
                    caption: req.body.caption,
                    access_token: accessToken,
                },
            }
        );

        const containerId = containerResponse.data.id;

        await axios.post(
            `https://graph.instagram.com/v21.0/${accountId}/media_publish`,
            {},
            {
                params: {
                    creation_id: containerId,
                    access_token: accessToken,
                },
            }
        );

        return res.success(null, req.__('INSTAGRAM_POST_CREATED'));
    }
}

export default new InstagramService();
