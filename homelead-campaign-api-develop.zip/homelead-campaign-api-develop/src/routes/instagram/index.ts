export { router } from './InstagramRoutes';
