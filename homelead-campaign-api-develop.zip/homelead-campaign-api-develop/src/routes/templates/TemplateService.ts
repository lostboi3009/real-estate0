import { Request, Response } from 'express';
import { CommonId, CommonStatus, ICampaignTemplate, Pagination, Status } from '@homelead-shared-api';
import TemplateDao from '../../dao/TemplateDao';
import { GetTemplates } from '@dto';

class TemplateService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { search, page, perPage } = req.query as unknown as GetTemplates & Pagination;

        const [count, templates] = await Promise.all([
            await TemplateDao.countAll({ company, search }),
            await TemplateDao.getAll({ company, page, perPage, search }),
        ]);

        return res.success({ count, templates });
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const data: ICampaignTemplate = req.body;

        const template = await TemplateDao.create({ ...data, company });

        return res.success(template);
    }

    async getActive(req: Request, res: Response) {
        const { company } = req.user;

        const templates = await TemplateDao.getActive({ company });

        return res.success(templates);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const template = await TemplateDao.getById({ id, company });

        if (!template) {
            return res.notFound(null, req.__('TEMPLATE_NOT_FOUND'));
        }

        return res.success(template);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: ICampaignTemplate = req.body;

        const template = await TemplateDao.getById({ id, company });

        if (!template) {
            return res.notFound(null, req.__('TEMPLATE_NOT_FOUND'));
        }

        await TemplateDao.updateById({ id, data, company });

        return res.success(null, req.__('TEMPLATE_UPDATE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: CommonStatus = req.body;

        const template = await TemplateDao.getById({ id, company });

        if (!template) {
            return res.notFound(null, req.__('TEMPLATE_NOT_FOUND'));
        }

        await TemplateDao.updateById({ id, data, company });

        return res.success(null, req.__('TEMPLATE_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: Partial<ICampaignTemplate> = {
            status: Status.ARCHIVED,
        };

        const template = await TemplateDao.getById({ id, company });

        if (!template) {
            return res.notFound(null, req.__('TEMPLATE_NOT_FOUND'));
        }

        await TemplateDao.updateById({ id, data, company });

        return res.success(null, req.__('TEMPLATE_DELETE_SUCCESS'));
    }
}

export default new TemplateService();
