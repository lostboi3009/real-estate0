import { commonValidations, joi, TemplateType } from '@homelead-shared-api';

const create = joi.object().keys({
    name: joi.string().trim().required(),
    templateType: joi
        .string()
        .trim()
        .valid(...Object.values(TemplateType))
        .required(),
    content: joi.string().min(3).trim().required(),
});

const getAll = joi.object().keys({
    search: joi.string().trim().optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

export default { create, getAll, updateStatus, requiredId };
