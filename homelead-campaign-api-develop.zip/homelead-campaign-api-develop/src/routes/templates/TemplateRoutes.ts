import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import TemplateValidations from './TemplateValidations';
import TemplateService from './TemplateService';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.CAMPAIGNS_TEMPLATES_LIST),
    validate(TemplateValidations.getAll, 'query'),
    TemplateService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.CAMPAIGNS_TEMPLATES_ADD),
    validate(TemplateValidations.create),
    TemplateService.create as RequestHandler
);

router.get('/active-templates', verifyToken(), TemplateService.getActive as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_TEMPLATES_VIEW),
    validate(TemplateValidations.requiredId, 'params'),
    TemplateService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_TEMPLATES_UPDATE),
    validate(TemplateValidations.requiredId, 'params'),
    validate(TemplateValidations.create),
    TemplateService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_TEMPLATES_DELETE),
    validate(TemplateValidations.requiredId, 'params'),
    TemplateService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.CAMPAIGNS_TEMPLATES_UPDATE),
    validate(TemplateValidations.requiredId, 'params'),
    validate(TemplateValidations.updateStatus),
    TemplateService.updateStatus as RequestHandler
);

export { router };
