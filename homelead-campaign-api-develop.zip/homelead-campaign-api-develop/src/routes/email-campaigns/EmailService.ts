import os from 'os';
import {
    CampaignStatus,
    CampaignType,
    CommonId,
    EmailStatus,
    ICampaign,
    IEmailTrack,
    Pagination,
    Status,
    TemplateType,
} from '@homelead-shared-api';
import { Request, Response } from 'express';
import { CampaignGetQueryParams, GetCampaign } from '@dto';
import CampaignDao from '../../dao/CampaignDao';
import ContactDao from '../../dao/ContactDao';
import EmailTrackDao from '../../dao/EmailTrackDao';
import TemplateDao from '../../dao/TemplateDao';
import { agenda } from '../../jobs';
import { prepareMessage } from '../../utils/common';
import Service from '../../jobs/send-email-campaign/Service';

class EmailService {
    async getCampaigns(req: Request, res: Response) {
        const { company } = req.user;

        const { campaignStatus, page, perPage, search, status, fromDate, toDate } =
            req.query as unknown as GetCampaign & Pagination;

        const [count, campaign] = await Promise.all([
            CampaignDao.count({
                campaignType: CampaignType.EMAIL,
                company,
                campaignStatus,
                search,
                status,
                fromDate,
                toDate,
            }),
            CampaignDao.getAll({
                campaignType: CampaignType.EMAIL,
                company,
                campaignStatus,
                search,
                status,
                page,
                perPage,
                fromDate,
                toDate,
            }),
        ]);

        return res.success({ count, campaign }, req.__('CAMPAIGN_DATA_SUCCESS'));
    }

    async createCampaign(req: Request, res: Response) {
        const { company } = req.user;
        const campaignData: ICampaign = req.body;
        const emailTracks: IEmailTrack[] = [];

        const template = await TemplateDao.getByTemplateType({
            id: campaignData.template,
            company,
            templateType: TemplateType.EMAIL,
        });

        if (!template) {
            return res.warn(null, req.__('TEMPLATE_NOT_FOUND'));
        }

        const targets = await ContactDao.getEmailTargets({ company, targets: campaignData.targets });

        if (targets.length !== campaignData.targets.length) {
            return res.warn(null, req.__('NO_CONTACTS_FOUND'));
        }

        const campaign = await CampaignDao.create({
            ...campaignData,
            company,
            campaignType: CampaignType.EMAIL,
            message: template.content,
        });

        for (const target of targets) {
            emailTracks.push({
                company,
                campaign: campaign._id,
                target: target._id,
                subject: campaignData.subject as string,
                email: target.email as string,
                message: prepareMessage({
                    data: { name: target.name, email: target.email },
                    message: template.content,
                }),
                emailStatus: EmailStatus.PENDING,
            });
        }

        await EmailTrackDao.bulkCreate(emailTracks);

        if (campaignData?.scheduleTime) {
            await agenda.schedule(
                campaignData?.scheduleTime as unknown as string,
                `${os.hostname}-send-email-campaign`,
                { campaign: campaign._id, company }
            );
        } else {
            Service.sendEmailCampaign({ campaign: campaign._id, company });
        }

        return res.success(campaign, req.__('CAMPAIGN_CREATE_SUCCESS'));
    }

    async getCampaignById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CampaignGetQueryParams;

        const campaign = await CampaignDao.getCampaignById({
            id,
            company,
            campaignType: CampaignType.EMAIL,
        });

        if (!campaign) {
            return res.notFound(null, req.__('CAMPAIGN_NOT_FOUND'));
        }

        return res.success(campaign, req.__('CAMPAIGN_DATA_SUCCESS'));
    }

    async updateCampaign(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const campaignData: ICampaign = req.body;
        const emailTracks: IEmailTrack[] = [];

        const campaign = await CampaignDao.getCampaignById({
            id,
            company,
            campaignType: CampaignType.EMAIL,
        });

        if (campaign?.campaignStatus !== CampaignStatus.PENDING) {
            return res.badRequest(null, req.__('CAMPAIGN_UPDATE_RESTRICTION'));
        }

        const template = await TemplateDao.getByTemplateType({
            id: campaignData.template,
            company,
            templateType: TemplateType.EMAIL,
        });

        if (!template) {
            return res.warn(null, req.__('TEMPLATE_NOT_FOUND'));
        }

        const targets = await ContactDao.getEmailTargets({ company, targets: campaignData.targets });

        if (targets.length !== campaignData.targets.length) {
            return res.warn(null, req.__('NO_CONTACTS_FOUND'));
        }

        await EmailTrackDao.deleteByCampaignId({
            id,
            company,
        });

        for (const target of targets) {
            emailTracks.push({
                company,
                campaign: id,
                target: target._id,
                subject: campaignData.subject as string,
                email: target.email as string,
                message: prepareMessage({
                    data: { name: target.name, email: target.email },
                    message: template.content,
                }),
                emailStatus: EmailStatus.PENDING,
            });
        }

        await EmailTrackDao.bulkCreate(emailTracks);

        await CampaignDao.updateCampaignById({
            company,
            id,
            data: campaignData,
        });

        if (campaignData?.scheduleTime) {
            await agenda.schedule(
                campaignData?.scheduleTime as unknown as string,
                `${os.hostname}-send-email-campaign`,
                { campaign: id, company }
            );
        } else {
            Service.sendEmailCampaign({ campaign: id, company });
        }

        return res.success(null, req.__('CAMPAIGN_UPDATE_SUCCESS'));
    }

    async deleteCampaign(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CampaignGetQueryParams;

        const campaign = await CampaignDao.getCampaignById({
            id,
            company,
            campaignType: CampaignType.EMAIL,
        });

        if (!campaign) {
            return res.notFound(null, req.__('CAMPAIGN_NOT_FOUND'));
        }

        await EmailTrackDao.deleteByCampaignId({ company, id });

        await CampaignDao.updateCampaignById({
            company,
            id,
            data: {
                status: Status.ARCHIVED,
            },
        });

        return res.success(null, req.__('CAMPAIGN_DELETE_SUCCESS'));
    }
}

export default new EmailService();
