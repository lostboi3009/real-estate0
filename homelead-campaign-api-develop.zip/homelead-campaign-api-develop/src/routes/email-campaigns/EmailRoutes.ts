import { RequestHandler, Router } from 'express';
import EmailService from './EmailService';
import EmailValidations from './EmailValidations';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.CAMPAIGNS_EMAIL_LIST),
    validate(EmailValidations.getAll, 'query'),
    EmailService.getCampaigns as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.CAMPAIGNS_EMAIL_ADD),
    validate(EmailValidations.createCampaign),
    EmailService.createCampaign as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_EMAIL_VIEW),
    validate(EmailValidations.requiredId, 'params'),
    EmailService.getCampaignById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_EMAIL_UPDATE),
    validate(EmailValidations.requiredId, 'params'),
    validate(EmailValidations.createCampaign),
    EmailService.updateCampaign as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_EMAIL_DELETE),
    validate(EmailValidations.requiredId, 'params'),
    EmailService.deleteCampaign as RequestHandler
);

export { router };
