import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import SmsService from './SmsService';
import SmsValidations from './SmsValidations';
import { validate } from '../../utils/validations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.CAMPAIGNS_SMS_LIST),
    validate(SmsValidations.getAll, 'query'),
    SmsService.getCampaigns as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.CAMPAIGNS_SMS_ADD),
    validate(SmsValidations.createCampaign),
    SmsService.createCampaign as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_SMS_VIEW),
    validate(SmsValidations.requiredId, 'params'),
    SmsService.getCampaignById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_SMS_UPDATE),
    validate(SmsValidations.requiredId, 'params'),
    validate(SmsValidations.createCampaign),
    SmsService.updateCampaign as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.CAMPAIGNS_SMS_DELETE),
    validate(SmsValidations.requiredId, 'params'),
    SmsService.deleteCampaign as RequestHandler
);

export { router };
