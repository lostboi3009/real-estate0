import { Request, Response } from 'express';
import {
    CampaignStatus,
    CampaignType,
    CommonId,
    ICampaign,
    ISmsTrack,
    Pagination,
    SmsStatus,
    Status,
    TemplateType,
} from '@homelead-shared-api';
import os from 'os';
import { CampaignGetQueryParams, GetCampaign } from '@dto';
import CampaignDao from '../../dao/CampaignDao';
import ContactDao from '../../dao/ContactDao';
import SmsTrackDao from '../../dao/SmsTrackDao';
import { prepareMessage } from '../../utils/common';
import TemplateDao from '../../dao/TemplateDao';
import { agenda } from '../../jobs';
import Service from '../../jobs/send-sms-campaign/Service';

class SmsService {
    async getCampaigns(req: Request, res: Response) {
        const { company } = req.user;

        const { campaignStatus, page, perPage, search, status, fromDate, toDate } =
            req.query as unknown as GetCampaign & Pagination;

        const [count, campaign] = await Promise.all([
            CampaignDao.count({
                campaignType: CampaignType.SMS,
                company,
                campaignStatus,
                search,
                status,
                fromDate,
                toDate,
            }),
            CampaignDao.getAll({
                campaignType: CampaignType.SMS,
                company,
                campaignStatus,
                search,
                status,
                page,
                perPage,
                fromDate,
                toDate,
            }),
        ]);

        return res.success({ count, campaign }, req.__('CAMPAIGN_DATA_SUCCESS'));
    }

    async getCampaignById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CampaignGetQueryParams;

        const campaign = await CampaignDao.getCampaignById({
            id,
            company,
            campaignType: CampaignType.SMS,
        });

        if (!campaign) {
            return res.notFound(null, req.__('CAMPAIGN_NOT_FOUND'));
        }

        return res.success(campaign, req.__('CAMPAIGN_DATA_SUCCESS'));
    }

    async createCampaign(req: Request, res: Response) {
        const { company } = req.user;
        const campaignData: ICampaign = req.body;
        const smsTracks: ISmsTrack[] = [];

        const template = await TemplateDao.getByTemplateType({
            id: campaignData?.template,
            company,
            templateType: TemplateType.SMS,
        });

        if (!template) {
            return res.warn(null, req.__('TEMPLATE_NOT_FOUND'));
        }

        const targets = await ContactDao.getSmsTargets({
            targets: campaignData.targets,
            company,
        });

        if (targets.length !== campaignData.targets.length) {
            return res.warn(null, req.__('NO_CONTACTS_FOUND'));
        }

        const campaign = await CampaignDao.create({
            ...campaignData,
            company,
            campaignType: CampaignType.SMS,
            message: template.content,
        });

        for (const target of targets) {
            smsTracks.push({
                company,
                campaign: campaign._id,
                target: target._id,
                countryCode: target.countryCode as string,
                phone: target.phone as string,
                message: prepareMessage({
                    data: { name: target.name, phone: `${target.countryCode as string}${target.phone as string}` },
                    message: template.content,
                }),
                smsStatus: SmsStatus.PENDING,
            });
        }

        await SmsTrackDao.bulkCreate(smsTracks);

        if (campaignData?.scheduleTime) {
            await agenda.schedule(campaignData?.scheduleTime as unknown as string, `${os.hostname}-send-sms-campaign`, {
                company,
                campaign: campaign._id,
            });
        } else {
            Service.sendSmsCampaign({ company, campaign: campaign._id });
        }

        return res.success(campaign, req.__('CAMPAIGN_CREATE_SUCCESS'));
    }

    async deleteCampaign(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CampaignGetQueryParams;

        const campaign = await CampaignDao.getCampaignById({
            id,
            company,
            campaignType: CampaignType.SMS,
        });

        if (!campaign) {
            return res.notFound(null, req.__('CAMPAIGN_NOT_FOUND'));
        }

        await SmsTrackDao.deleteByCampaignId({ company, id });

        await CampaignDao.updateCampaignById({
            company,
            id,
            data: {
                status: Status.ARCHIVED,
            },
        });

        return res.success(null, req.__('CAMPAIGN_DELETE_SUCCESS'));
    }

    async updateCampaign(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const campaignData: ICampaign = req.body;
        const smsTracks: ISmsTrack[] = [];

        const campaign = await CampaignDao.getCampaignById({
            id,
            company,
            campaignType: CampaignType.SMS,
        });

        if (campaign?.campaignStatus !== CampaignStatus.PENDING) {
            return res.badRequest(null, req.__('CAMPAIGN_UPDATE_RESTRICTION'));
        }

        const template = await TemplateDao.getByTemplateType({
            id: campaignData.template,
            company,
            templateType: TemplateType.SMS,
        });

        if (!template) {
            return res.warn(null, req.__('TEMPLATE_NOT_FOUND'));
        }

        const targets = await ContactDao.getSmsTargets({ company, targets: campaignData.targets });

        if (targets.length !== campaignData.targets.length) {
            return res.warn(null, req.__('NO_CONTACTS_FOUND'));
        }

        await SmsTrackDao.deleteByCampaignId({
            id,
            company,
        });

        for (const target of targets) {
            smsTracks.push({
                company,
                campaign: id,
                target: target._id,
                countryCode: target.countryCode as string,
                phone: target.phone as string,
                message: prepareMessage({
                    data: { name: target.name, phone: `${target.countryCode as string}${target.phone as string}` },
                    message: template.content,
                }),
                smsStatus: SmsStatus.PENDING,
            });
        }

        await SmsTrackDao.bulkCreate(smsTracks);

        await CampaignDao.updateCampaignById({
            company,
            id,
            data: campaignData,
        });

        if (campaignData?.scheduleTime) {
            await agenda.schedule(campaignData?.scheduleTime as unknown as string, `${os.hostname}-send-sms-campaign`, {
                company,
                campaign: id,
            });
        } else {
            Service.sendSmsCampaign({ company, campaign: id });
        }

        return res.success(null, req.__('CAMPAIGN_UPDATE_SUCCESS'));
    }
}

export default new SmsService();
