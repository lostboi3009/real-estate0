import moment from 'moment-timezone';
import { commonValidations, joi, CampaignService, CampaignRoute, CampaignStatus } from '@homelead-shared-api';

const createCampaign = joi.object().keys({
    service: joi.string().trim().valid(CampaignService.TWILIO).required(),
    name: joi.string().trim().required(),
    route: joi
        .string()
        .trim()
        .valid(...Object.values(CampaignRoute))
        .required(),
    targets: joi.array().items(commonValidations.id).min(1).required(),
    scheduleTime: joi.date().min(moment()).optional(),
    template: commonValidations.id,
});

const getAll = joi.object().keys({
    page: commonValidations.page,
    perPage: commonValidations.perPage,
    status: commonValidations.status.optional(),
    campaignStatus: joi
        .string()
        .trim()
        .valid(...Object.values(CampaignStatus))
        .optional(),
    search: joi.string().trim().optional(),
    fromDate: joi.date().optional(),
    toDate: joi.date().min(joi.ref('fromDate')).optional(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

export default { createCampaign, getAll, requiredId };
