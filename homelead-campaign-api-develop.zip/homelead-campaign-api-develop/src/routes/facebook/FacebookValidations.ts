import { joi } from '@homelead-shared-api';
import { PostType } from '@dto';

const createPost = joi.object().keys({
    pageId: joi.string().trim().required(),
    message: joi.string().trim().min(3).max(200).required(),
    postType: joi
        .string()
        .trim()
        .valid(...Object.values(PostType))
        .required(),
    url: joi.string().when('postType', {
        is: ['Image', 'Video'],
        then: joi.string().trim().required(),
        otherwise: joi.string().trim().optional(),
    }),
    scheduled_publish_time: joi.number().positive().optional(),
    pageAccessToken: joi.string().trim().required(),
});

const updatePost = joi.object().keys({
    postId: joi.string().trim().required(),
    message: joi.string().trim().min(3).max(200).required(),
    postType: joi
        .string()
        .trim()
        .valid(...Object.values(PostType))
        .required(),
    url: joi.string().when('postType', {
        is: ['Image', 'Video'],
        then: joi.string().trim().required(),
        otherwise: joi.string().trim().optional(),
    }),
    pageAccessToken: joi.string().trim().required(),
});

const getPosts = joi.object().keys({
    pageId: joi.string().trim().required(),
    pageAccessToken: joi.string().trim().required(),
});

const deletePost = joi.object().keys({
    postId: joi.string().trim().required(),
    pageAccessToken: joi.string().trim().required(),
});

export default {
    createPost,
    getPosts,
    updatePost,
    deletePost,
};
