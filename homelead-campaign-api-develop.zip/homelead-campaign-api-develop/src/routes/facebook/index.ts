export { router } from './FacebookRoutes';
