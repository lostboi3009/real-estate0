import { Request, Response } from 'express';
import axios from 'axios';
import UserDao from '../../dao/UserDao';
import { CreatePost, DeletePost, FacebookCallback, GetPosts, UpdatePost } from '@dto';

const FACEBOOK_APP_ID = process.env.FACEBOOK_APP_ID;
const FACEBOOK_APP_SECRET = process.env.FACEBOOK_APP_SECRET;
const FACEBOOK_REDIRECT_URI = process.env.FACEBOOK_REDIRECT_URI;

class FacebookService {
    async authFacebook(req: Request, res: Response) {
        const { authorization } = req.headers;
        const authUrl = `https://www.facebook.com/v12.0/dialog/oauth?client_id=${FACEBOOK_APP_ID}&scope=pages_manage_posts,pages_read_engagement&redirect_uri=${FACEBOOK_REDIRECT_URI}?state=${authorization}`;

        return res.success({ authUrl });
    }

    async facebookCallback(req: Request, res: Response) {
        const { authorization, code } = req.query as unknown as FacebookCallback;
        const { user } = req;

        const tokenResponse = await axios.get('https://graph.facebook.com/v12.0/oauth/access_token', {
            params: {
                client_id: FACEBOOK_APP_ID,
                client_secret: FACEBOOK_APP_SECRET,
                redirect_uri: `${FACEBOOK_REDIRECT_URI}?state=${authorization}`,
                code,
            },
        });

        const shortLivedToken = tokenResponse.data.access_token;

        const longLivedTokenResponse = await axios.get('https://graph.facebook.com/v12.0/oauth/access_token', {
            params: {
                grant_type: 'fb_exchange_token',
                client_id: FACEBOOK_APP_ID,
                client_secret: FACEBOOK_APP_SECRET,
                fb_exchange_token: shortLivedToken,
            },
        });

        const longLivedToken = longLivedTokenResponse.data.access_token;

        await UserDao.updateUser({
            id: user._id,
            company: user.company,
            data: {
                facebookToken: longLivedToken,
            },
        });

        return res.success(null, req.__('FACEBOOK_CONNECTED'));
    }

    async getPages(req: Request, res: Response) {
        const { user } = req;

        if (!user.facebookToken) {
            return res.warn(null, req.__('FACEBOOK_NOT_CONNECTED'));
        }

        const pagesResponse = await axios.get('https://graph.facebook.com/me/accounts', {
            params: {
                access_token: user.facebookToken,
            },
        });

        const pages = pagesResponse.data.data;

        return res.success({
            pages,
        });
    }

    async createPost(req: Request, res: Response) {
        const { pageId, message, url, postType, scheduled_publish_time, pageAccessToken }: CreatePost = req.body;

        if (postType === 'Text') {
            await axios.post(`https://graph.facebook.com/${pageId}/feed`, {
                message,
                access_token: pageAccessToken,
                scheduled_publish_time,
                published: !scheduled_publish_time,
            });
        } else if (postType === 'Image') {
            await axios.post(`https://graph.facebook.com/${pageId}/photos`, {
                message,
                url,
                access_token: pageAccessToken,
                scheduled_publish_time,
                published: !scheduled_publish_time,
            });
        }

        return res.success(null, req.__('FACEBOOK_POST_CREATED'));
    }

    async getPosts(req: Request, res: Response) {
        const { pageId, pageAccessToken } = req.query as unknown as GetPosts;

        const response = await axios.get(`https://graph.facebook.com/v12.0/${pageId}/feed`, {
            params: {
                access_token: pageAccessToken,
                fields: 'id,message,created_time,story,full_picture',
            },
        });

        return res.success(response.data);
    }

    async updatePost(req: Request, res: Response) {
        const { message, postId, postType, url, pageAccessToken }: UpdatePost = req.body;

        if (postType === 'Text') {
            await axios.post(`https://graph.facebook.com/v12.0/${postId}`, {
                message,
                access_token: pageAccessToken,
            });
        } else if (postType === 'Image') {
            await axios.post(`https://graph.facebook.com/v12.0/${postId}`, {
                message,
                url,
                access_token: pageAccessToken,
            });
        }

        return res.success(null, req.__('FACEBOOK_POST_UPDATED'));
    }

    async deletePost(req: Request, res: Response) {
        const { postId, pageAccessToken } = req.query as unknown as DeletePost;

        const response = await axios.delete(`https://graph.facebook.com/v12.0/${postId}`, {
            params: {
                access_token: pageAccessToken,
            },
        });

        if (response.status === 200) {
            return res.success(null, req.__('FACEBOOK_POST_DELETED'));
        }

        return res.warn(null, req.__('FACEBOOK_POST_DELETE_FAILED'));
    }
}

export default new FacebookService();
