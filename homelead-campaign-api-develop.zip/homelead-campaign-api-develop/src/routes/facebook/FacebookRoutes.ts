import { RequestHandler, Router } from 'express';
import FacebookService from './FacebookService';
import FacebookValidations from './FacebookValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/auth', verifyToken(), FacebookService.authFacebook as RequestHandler);

router.get('/auth-callback', verifyToken(), FacebookService.facebookCallback as RequestHandler);

router.get('/pages', verifyToken(), FacebookService.getPages as RequestHandler);

router.get(
    '/post',
    verifyToken(UserPermissions.CAMPAIGNS_FACEBOOK_LIST),
    validate(FacebookValidations.getPosts, 'query'),
    FacebookService.getPosts as RequestHandler
);

router.post(
    '/post',
    verifyToken(UserPermissions.CAMPAIGNS_FACEBOOK_ADD),
    validate(FacebookValidations.createPost),
    FacebookService.createPost as RequestHandler
);

router.put(
    '/post',
    verifyToken(UserPermissions.CAMPAIGNS_FACEBOOK_UPDATE),
    validate(FacebookValidations.updatePost),
    FacebookService.updatePost as RequestHandler
);

router.delete(
    '/post',
    verifyToken(UserPermissions.CAMPAIGNS_FACEBOOK_DELETE),
    validate(FacebookValidations.deletePost, 'query'),
    FacebookService.deletePost as RequestHandler
);

export { router };
