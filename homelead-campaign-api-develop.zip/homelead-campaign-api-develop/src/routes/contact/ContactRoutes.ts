import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import ContactService from './ContactService';
import ContactValidation from './ContactValidation';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.CONTACT_LIST),
    validate(ContactValidation.getAll, 'query'),
    ContactService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.CONTACT_ADD),
    validate(ContactValidation.create),
    ContactService.create as RequestHandler
);

router.get('/active-contacts', verifyToken(), ContactService.getActiveContacts as RequestHandler);

router.get(
    '/:id',
    verifyToken(UserPermissions.CONTACT_VIEW),
    validate(ContactValidation.requiredId, 'params'),
    ContactService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.CONTACT_UPDATE),
    validate(ContactValidation.requiredId, 'params'),
    validate(ContactValidation.create),
    ContactService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.CONTACT_DELETE),
    validate(ContactValidation.requiredId, 'params'),
    ContactService.deleteById as RequestHandler
);

router.patch(
    '/:id/status',
    verifyToken(UserPermissions.CONTACT_UPDATE),
    validate(ContactValidation.requiredId, 'params'),
    validate(ContactValidation.updateStatus),
    ContactService.updateStatus as RequestHandler
);

export { router };
