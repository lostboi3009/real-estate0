import { Request, Response } from 'express';
import ContactDao from '../../dao/ContactDao';
import { GetContacts } from '@dto';
import { CommonId, CommonStatus, IContact, Pagination, Status } from '@homelead-shared-api';

class ContactService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, search, status } = req.query as unknown as GetContacts & Pagination;

        const [count, contacts] = await Promise.all([
            ContactDao.countAll({ company, search, status }),
            ContactDao.getAll({ company, page, perPage, search, status }),
        ]);

        return res.success({
            count,
            contacts,
        });
    }

    async getActiveContacts(req: Request, res: Response) {
        const { company } = req.user;
        const contacts = await ContactDao.getActiveContacts({ company });

        return res.success(contacts);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const data: IContact = req.body;
        const response = await ContactDao.create({ ...data, company });

        return res.success(response);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const contact = await ContactDao.getById({ id, company });

        if (!contact) {
            return res.notFound(null, req.__('CONTACT_NOT_FOUND'));
        }

        return res.success(contact);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: IContact = req.body;

        const contact = await ContactDao.getById({ id, company });

        if (!contact) {
            return res.notFound(null, req.__('CONTACT_NOT_FOUND'));
        }

        await ContactDao.updateById({ id, company, data });

        return res.success(null, req.__('CONTACT_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<IContact> = {
            status: Status.ARCHIVED,
        };

        const contact = await ContactDao.getById({ id, company });

        if (!contact) {
            return res.notFound(null, req.__('CONTACT_NOT_FOUND'));
        }

        await ContactDao.updateById({ id, company, data });

        return res.success(null, req.__('CONTACT_DELETE_SUCCESS'));
    }

    async updateStatus(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CommonStatus = req.body;

        const contact = await ContactDao.getById({ id, company });

        if (!contact) {
            return res.notFound(null, req.__('CONTACT_NOT_FOUND'));
        }

        await ContactDao.updateById({ id, company, data });

        return res.success(null, req.__('CONTACT_STATUS_UPDATED'));
    }
}

export default new ContactService();
