import { joi, commonValidations, CampaignUserType } from '@homelead-shared-api';

const create = joi
    .object()
    .keys({
        company: commonValidations.id,
        name: joi.string().trim().min(3).max(30).required(),
        email: commonValidations.email.optional(),
        address: joi.string().trim().optional(),
        campaignUserType: joi
            .string()
            .trim()
            .valid(...Object.values(CampaignUserType))
            .required(),
        phone: commonValidations.phone.optional(),
        countryCode: commonValidations.countryCode.optional(),
    })
    .with('countryCode', 'phone')
    .or('email', 'phone');

const getAll = joi.object().keys({
    page: commonValidations.page,
    perPage: commonValidations.perPage,
    search: joi.string().trim().optional(),
    status: commonValidations.status.optional(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

export default {
    create,
    getAll,
    requiredId,
    updateStatus,
};
