import { RequestHandler, Router } from 'express';
import YoutubeService from './YoutubeService';
import YoutubeValidations from './YoutubeValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get('/auth', verifyToken(), YoutubeService.authYoutube as RequestHandler);

router.get('/auth-callback', verifyToken(), YoutubeService.youtubeCallback as RequestHandler);

router.post(
    '/post',
    verifyToken(UserPermissions.CAMPAIGNS_YOUTUBE_ADD),
    validate(YoutubeValidations.uploadValidation),
    YoutubeService.youtubeUpload.bind(YoutubeService) as RequestHandler
);

export { router };
