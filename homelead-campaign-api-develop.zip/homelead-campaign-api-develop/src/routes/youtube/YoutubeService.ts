import { YoutubeCallback, YoutubeUpload } from '@dto';
import { Request, Response } from 'express';
import { google } from 'googleapis';
import axios from 'axios';
import { Readable } from 'stream';

const YOUTUBE_CLIENT_ID = process.env.YOUTUBE_CLIENT_ID;
const YOUTUBE_CLIENT_SECRET = process.env.YOUTUBE_CLIENT_SECRET;
const YOUTUBE_REDIRECT_URI = process.env.YOUTUBE_REDIRECT_URI;

const SCOPES = [
    'https://www.googleapis.com/auth/youtube.upload',
    'https://www.googleapis.com/auth/youtube.force-ssl',
    'https://www.googleapis.com/auth/youtube.readonly',
];

class YoutubeService {
    async authYoutube(req: Request, res: Response) {
        const authorization = req.headers.authorization as unknown as string;
        const oauth2Client = new google.auth.OAuth2(YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REDIRECT_URI);

        let authUrl = oauth2Client.generateAuthUrl({
            access_type: 'offline',
            scope: SCOPES,
        });

        authUrl = `${authUrl}&state=${encodeURIComponent(authorization)}`;

        return res.success({ authUrl });
    }

    async youtubeCallback(req: Request, res: Response) {
        const { code } = req.query as unknown as YoutubeCallback;

        const oauth2Client = new google.auth.OAuth2(YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REDIRECT_URI);

        const { tokens } = await oauth2Client.getToken(code);

        return res.success({ tokens });
    }

    async youtubeUpload(req: Request, res: Response) {
        const { tokens, videoUrl, title, description, tags, privacyStatus }: YoutubeUpload = req.body;
        const oauth2Client = new google.auth.OAuth2(YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REDIRECT_URI);
        const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
        const videoStream = await this.fetchVideoStream(videoUrl);

        oauth2Client.setCredentials(tokens);

        const response = await youtube.videos.insert({
            part: ['snippet', 'status'],
            requestBody: {
                snippet: {
                    title,
                    description,
                    tags,
                    categoryId: '22',
                },
                status: {
                    privacyStatus,
                },
            },
            media: {
                body: videoStream,
            },
        });

        return res.success(null, req.__(`YOUTUBE_UPLOADED_SUCCESS: ${response.data.id}`));
    }

    private async fetchVideoStream(url: string): Promise<Readable> {
        const response = await axios.get(url, { responseType: 'stream' });

        if (response.status !== 200) {
            throw new Error('Failed to download video from URL');
        }

        return response.data;
    }
}

export default new YoutubeService();
