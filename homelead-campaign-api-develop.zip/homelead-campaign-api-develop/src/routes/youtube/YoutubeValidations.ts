import { joi } from '@homelead-shared-api';

const uploadValidation = joi.object().keys({
    tokens: joi.object({
        access_token: joi.string().trim().required(),
        scope: joi.string().trim().required(),
        token_type: joi.string().trim().required(),
        expiry_date: joi.number().required(),
    }),
    title: joi.string().trim().required(),
    description: joi.string().trim().required(),
    tags: joi.array().items(joi.string().required()).min(1).required(),
    privacyStatus: joi.string().valid('public', 'private').trim().required(),
    videoUrl: joi.string().trim().required(),
});

export default {
    uploadValidation,
};
