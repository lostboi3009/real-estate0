import sgMail from '@sendgrid/mail';
import { logger } from '@homelead-shared-api';
import { SendGridEmailConfig } from '@dto';

export const sendGridEmail = async ({ to, from, subject, body }: SendGridEmailConfig) => {
    sgMail.setApiKey(process.env.TWILIO_SENDGRID_API_KEY);

    const config = {
        to,
        from,
        subject,
        html: body,
    };
    sgMail
        .send(config)
        .then(response => {
            logger.info(`Email sent to ${to} successfully.`);
            return response[0].statusCode;
        })
        .catch(error => {
            logger.error(`Error while sending email to ${to}`, error);
            throw error;
        });
};
