import { SendCampaignEmailConfiguration } from '@dto';
import { sendGridEmail } from './twilio';

export const handleEmailSend = async ({ serviceType, from, to, subject, body }: SendCampaignEmailConfiguration) => {
    switch (serviceType) {
        case 'twilio':
            return await sendGridEmail({ to, from, subject, body });
        default:
            throw new Error('Invalid service type.');
    }
};
