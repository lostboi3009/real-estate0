import twilio from 'twilio';
import { logger } from '@homelead-shared-api';
import { SendSMSConfiguration } from '@dto';

const accountSid: string = process.env.TWILIO_SMS_ACCOUNT_SID;
const authToken: string = process.env.TWILIO_SMS_AUTH_TOKEN;
const client = twilio(accountSid, authToken);

export const twilioSms = async ({ msg, fromNumber, toNumber }: SendSMSConfiguration) => {
    client.messages
        .create({
            body: msg,
            from: fromNumber,
            to: toNumber,
        })
        .then(response => {
            logger.info(`SMS sent to ${toNumber} successfully.`);
            return response.status;
        })
        .catch(error => {
            logger.error(`Error while sending sms to ${toNumber}`, error);
            throw error;
        });
};
