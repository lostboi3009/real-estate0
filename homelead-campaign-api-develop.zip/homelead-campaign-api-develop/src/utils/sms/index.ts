import { SendCampaignSMSConfiguration } from '@dto';
import { twilioSms } from './twilio';

export const handleSmsSend = async ({ serviceType, fromNumber, toNumber, msg }: SendCampaignSMSConfiguration) => {
    switch (serviceType) {
        case 'twilio':
            return await twilioSms({ fromNumber, toNumber, msg });
        default:
            throw new Error('Invalid service type.');
    }
};
