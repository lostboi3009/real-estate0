declare global {
    namespace NodeJS {
        interface ProcessEnv {
            PORT: string;
            SITE_TITLE: string;
            SITE_URL: string;
            LOGO_PATH: string;
            NODE_ENV: 'development' | 'production';
            SERVER_MODE: 'http' | 'https';
            SERVER_NAME: string;
            SSL_KEY_PATH: string;
            SSL_CERT_PATH: string;
            SSL_CA_PATH: string;
            MONGO_URI: string;
            JWT_SECRET: string;
            VALIDATE_SESSION: string;
            VALIDATE_PERMISSION: string;
            SESSION_SECRET: string;
            SESSION_VALIDITY_DAYS: string;
            LOG_LEVEL: 'error' | 'warn' | 'info' | 'verbose' | 'debug' | 'silly';
            MONGOOSE_DEBUG: 'true' | 'false';
            LOG_REQUESTS: 'true' | 'false';
            FACEBOOK_APP_ID: string;
            FACEBOOK_APP_SECRET: string;
            FACEBOOK_REDIRECT_URI: string;
            INSTAGRAM_APP_ID: string;
            INSTAGRAM_APP_SECRET: string;
            INSTAGRAM_REDIRECT_URI: string;
            YOUTUBE_CLIENT_ID: string;
            YOUTUBE_CLIENT_SECRET: string;
            YOUTUBE_REDIRECT_URI: string;
            TWILIO_SENDGRID_API_KEY: string;
            TWILIO_FROM_EMAIL: string;
            TWILIO_FROM_PHONE: string;
            TWILIO_SMS_ACCOUNT_SID: string;
            TWILIO_SMS_AUTH_TOKEN: string;
        }
    }
}
export {};
