import { CompanyId, TypesObjectId } from '@homelead-shared-api';

export interface GetEmailTrackByCampaignAndTarget extends CompanyId {
    campaign: TypesObjectId;
    target: TypesObjectId;
}

export interface GetEmailTrackByCampaignId extends CompanyId {
    campaign: TypesObjectId;
}

export interface SendEmailTrack extends CompanyId {
    campaign: TypesObjectId;
}
