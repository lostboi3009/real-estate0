import { CompanyId, TypesObjectId } from '@homelead-shared-api';

export interface GetSmsTrackByCampaignAndTarget extends CompanyId {
    campaign: TypesObjectId;
    target: TypesObjectId;
}

export interface GetSmsTrackByCampaignId extends CompanyId {
    campaign: TypesObjectId;
}

export interface SendSmsTrack extends CompanyId {
    campaign: TypesObjectId;
}
