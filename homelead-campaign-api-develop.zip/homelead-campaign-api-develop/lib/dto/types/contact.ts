import { CompanyId, Status, TypesObjectId } from '@homelead-shared-api';

export interface ContactTargets extends CompanyId {
    targets: TypesObjectId[];
}

export interface GetContacts extends CompanyId {
    search?: string;
    status?: Status;
}
