import {
    CampaignService,
    CampaignStatus,
    CampaignType,
    CommonId,
    CompanyId,
    IUser,
    Status,
    TypesObjectId,
} from '@homelead-shared-api';

export enum PostType {
    TEXT = 'Text',
    IMAGE = 'Image',
    VIDEO = 'Video',
}

export interface UpdateUser extends CommonId {
    company?: TypesObjectId;
    data: Partial<IUser>;
}

export interface FacebookCallback {
    authorization: string;
    state?: string;
    code: string;
}

export interface CreatePost {
    pageId: string;
    message: string;
    url: string;
    postType: PostType;
    scheduled_publish_time: number;
    pageAccessToken: string;
}

export interface GetPosts {
    pageId: string;
    pageAccessToken: string;
}

export interface UpdatePost {
    message: string;
    postId: string;
    postType: PostType;
    url: string;
    pageAccessToken: string;
}

export interface DeletePost {
    postId: string;
    pageAccessToken: string;
}

export interface YoutubeCallback {
    code: string;
}

export interface YoutubeUpload {
    videoUrl: string;
    title: string;
    description: string;
    tags: string[];
    categoryId: string;
    privacyStatus: string;
    tokens: {
        access_token: string;
        scope: string;
        token_type: string;
        expiry_date: number;
    };
}

export interface SendCampaignEmailConfiguration {
    serviceType: CampaignService;
    to: string;
    from: string;
    subject?: string;
    body: string;
}

export interface SendCampaignSMSConfiguration {
    serviceType: CampaignService;
    msg: string;
    fromNumber: string;
    toNumber: string;
}

export interface SendSMSConfiguration extends Omit<SendCampaignSMSConfiguration, 'serviceType'> {}

export interface SendGridEmailConfig extends Omit<SendCampaignEmailConfiguration, 'serviceType'> {}

export interface GetCampaignName {
    name: string;
}

export interface CampaignById extends CompanyId, CommonId {
    campaignType?: CampaignType;
}

export interface CampaignTemplateFilter extends CompanyId {
    template: TypesObjectId;
    templateType: CampaignType;
}

export interface UpdateCampaignStatusById extends CompanyId {
    campaignId: TypesObjectId;
    campaignStatus: CampaignStatus;
}

export interface GetCampaign extends CompanyId {
    campaignStatus?: CampaignStatus;
    status?: Status;
    search?: string;
    campaignType?: CampaignType;
    fromDate?: Date;
    toDate?: Date;
}

export interface CampaignGetQueryParams {
    id: TypesObjectId;
}
