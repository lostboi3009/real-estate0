import { CompanyId, TemplateType, TypesObjectId } from '@homelead-shared-api';

export interface GetTemplates extends CompanyId {
    search?: string;
}

export interface GetTemplatesByTemplateType {
    id: TypesObjectId;
    company: TypesObjectId;
    templateType: TemplateType;
}
