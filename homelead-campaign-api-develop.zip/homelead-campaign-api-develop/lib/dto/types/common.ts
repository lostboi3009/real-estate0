export interface ExpressError extends Error {
    status: number;
}

export interface CreateMessage {
    message: string;
    data: Record<string, any>;
}
