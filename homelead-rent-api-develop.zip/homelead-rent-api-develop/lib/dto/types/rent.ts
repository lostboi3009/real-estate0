import {
    CommonId,
    CompanyId,
    IRentPayment,
    ITenant,
    PaymentMode,
    PropertyStatus,
    RentPaymentStatus,
    Status,
    TenantStatus,
    TypesObjectId,
} from '@homelead-shared-api';

export interface UpdateRent extends CommonId, CompanyId {
    data: Partial<ITenant>;
}

export interface GetTenants extends CompanyId {
    project: TypesObjectId;
    search?: string;
    status?: Status;
    tenantStatus?: TenantStatus;
    temporaryBookingPeriod: number;
}

export interface GetByPropertyId extends CompanyId {
    project: TypesObjectId;
    property: TypesObjectId;
}

export interface IRenewAgreement {
    rentAmount: number;
    rentAgreements: string[];
    rentAgreementStartDate: Date;
    rentAgreementEndDate: Date;
}

export interface ILeaveTenant {
    leavingDate: Date;
    adjustedDepositAmount: number;
    depositPaymentMode?: PaymentMode;
    depositReferenceNo?: string;
    depositRemarks?: string;
}

export interface IRentPaymentTenant {
    project: TypesObjectId;
    property: TypesObjectId;
    tenant: TypesObjectId;
    startDate: Date;
    endDate: Date;
    amount: number;
    paymentMode?: PaymentMode;
}

export interface GetAllRentPayments {
    project: TypesObjectId;
    tenant?: TypesObjectId;
    paymentStatus?: RentPaymentStatus;
}

export interface UpdateTotalRentAmountRequired extends CompanyId {
    id: TypesObjectId;
    dueAmount: number;
}

export interface UpdatetotalRentRevenue extends CompanyId {
    project: TypesObjectId;
    totalRentRevenue: number;
}

export interface IUpdateLeaveStatus extends CommonId, CompanyId {
    tenantStatus: TenantStatus;
}

export interface GetAvailableForRent extends CompanyId {
    project: TypesObjectId;
    temporaryBookingPeriod: number;
}

export interface ITenantData extends ITenant {
    paymentStatus: RentPaymentStatus;
    paymentMode: PaymentMode;
    referenceNo?: string;
    remarks?: string;
}

interface FormattedBlock {
    blocks: [];
}

export interface FormattedResponse {
    [propertyType: string]: FormattedBlock[];
}

export interface UpdatePropertyStatus extends CommonId, CompanyId {
    propertyStatus: PropertyStatus;
    bookingDate?: Date;
}

export interface UpdateTenantDueAmount extends CommonId, CompanyId {
    dueAmount: number;
}
export interface UpdateProjectRentRevenue extends CompanyId {
    project: TypesObjectId;
    totalRentAmountRequired: number;
    totalRentRevenue: number;
}

export interface IRentPaymentGeneratedOn {
    rentPaymentGeneratedOn: Date;
}

export interface IncreaseProjectTotalRentRevenueRequired extends CommonId, CompanyId {
    dueAmount: number;
}

export interface IncreaseProjectTotalRentRevenue extends CommonId, CompanyId {
    dueAmount: number;
}

export interface MarkAsPaid {
    paymentMode: PaymentMode;
    referenceNo: string;
    remarks: string;
    receivedOn: Date;
    amountPaid: number;
}

export interface IRentPayments extends IRentPayment {
    _id: TypesObjectId;
}

export interface PartialPayment {
    amount: number;
    tenant: TypesObjectId;
}

export interface GetTenantPayment {
    tenant: TypesObjectId;
    company: TypesObjectId;
    startDate: Date;
    endDate: Date;
}
