import Agenda from 'agenda';

export type DefineJob = (jobName: string, agenda: Agenda) => Promise<void>;

export interface Job {
    defineJob: DefineJob;
}
