import {
    CommonId,
    CompanyId,
    IRentPayment,
    IRentPaymentDoc,
    Pagination,
    Project,
    RentPayment,
    RentPaymentStatus,
    Status,
    TypesObjectId,
    mongoose,
} from '@homelead-shared-api';
import {
    GetAllRentPayments,
    GetTenantPayment,
    IncreaseProjectTotalRentRevenue,
    IncreaseProjectTotalRentRevenueRequired,
    MarkAsPaid,
    UpdateProjectRentRevenue,
} from '@dto';

type FilterQueryIRentPayment = mongoose.FilterQuery<IRentPayment>;

class RentPaymentDao {
    async getAll({
        company,
        page,
        perPage,
        tenant,
        project,
        paymentStatus,
    }: GetAllRentPayments & Pagination & CompanyId): Promise<IRentPaymentDoc[]> {
        const matchCriteria: FilterQueryIRentPayment = {
            company,
            project,
        };

        if (tenant) {
            matchCriteria.tenant = tenant;
        }

        if (paymentStatus) {
            matchCriteria.paymentStatus = paymentStatus;
        }

        return RentPayment.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .populate([
                {
                    path: 'tenant',
                    select: 'name depositAmount',
                },
                {
                    path: 'property',
                    select: 'propertyType propertyUnitSubType blockName floorName flatNo shopNo series',
                    populate: {
                        path: 'propertyUnitSubType',
                        select: 'name',
                    },
                },
            ])
            .sort({ _id: -1 });
    }

    async countAll({ company, tenant, project, paymentStatus }: GetAllRentPayments & CompanyId): Promise<number> {
        const matchCriteria: FilterQueryIRentPayment = {
            company,
            project,
        };

        if (tenant) {
            matchCriteria.tenant = tenant;
        }

        if (paymentStatus) {
            matchCriteria.paymentStatus = paymentStatus;
        }

        return RentPayment.countDocuments(matchCriteria);
    }

    async create(rentPayment: IRentPayment): Promise<IRentPaymentDoc> {
        return RentPayment.create(rentPayment);
    }

    async bulkCreate(rentPayments: IRentPayment[]): Promise<IRentPaymentDoc[]> {
        return RentPayment.insertMany(rentPayments);
    }

    async getById({ id }: CommonId): Promise<IRentPaymentDoc | null> {
        return RentPayment.findOne({
            _id: id,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getByTenantId({ company, tenant }: { tenant: TypesObjectId } & CompanyId): Promise<IRentPaymentDoc[]> {
        return RentPayment.find({
            company,
            tenant,
            paymentStatus: RentPaymentStatus.DUE,
        }).sort({ _id: 1 });
    }

    async getTenantPayment({ company, tenant, startDate, endDate }: GetTenantPayment): Promise<IRentPaymentDoc[]> {
        return RentPayment.find({
            company,
            tenant,
            $or: [
                {
                    startDate: { $lt: endDate },
                    endDate: { $gt: startDate },
                },
                {
                    startDate: { $lte: startDate },
                    endDate: { $gte: endDate },
                },
            ],
        });
    }

    async updateDuePaymentById({ company, id, data }: CommonId & CompanyId & { data: Partial<IRentPayment> }) {
        return RentPayment.updateOne(
            {
                _id: id,
                company,
                paymentStatus: RentPaymentStatus.DUE,
            },
            {
                $set: {
                    amountPaid: data.amountPaid,
                    paymentStatus: data.paymentStatus,
                },
            }
        );
    }

    async updateProjectRentRevenue({
        company,
        project,
        totalRentAmountRequired,
        totalRentRevenue,
    }: UpdateProjectRentRevenue) {
        return Project.updateOne(
            {
                _id: project,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    totalRentAmountRequired,
                    totalRentRevenue,
                },
            }
        );
    }

    async increaseProjectTotalRentRevenueRequired({ id, company, dueAmount }: IncreaseProjectTotalRentRevenueRequired) {
        const project = await Project.findOne({ _id: id, company, status: { $ne: Status.ARCHIVED } });

        if (project) {
            const totalRentAmountRequired = (project.totalRentAmountRequired || 0) + dueAmount;

            await Project.updateOne(
                { _id: id, company, status: { $ne: Status.ARCHIVED } },
                { $set: { totalRentAmountRequired } }
            );
        }
    }

    async increaseProjectTotalRentRevenue({ id, company, dueAmount }: IncreaseProjectTotalRentRevenue) {
        const project = await Project.findOne({ _id: id, company, status: { $ne: Status.ARCHIVED } });

        if (project) {
            const totalRentRevenue = (project.totalRentRevenue || 0) + dueAmount;

            await Project.updateOne(
                { _id: id, company, status: { $ne: Status.ARCHIVED } },
                { $set: { totalRentRevenue } }
            );
        }
    }

    async markAsPaid({
        id,
        paymentMode,
        referenceNo,
        remarks,
        receivedOn,
        amountPaid,
    }: MarkAsPaid & CommonId & CompanyId) {
        return RentPayment.updateOne(
            {
                _id: id,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    amountPaid,
                    paymentMode,
                    referenceNo,
                    remarks,
                    receivedOn,
                    paymentStatus: RentPaymentStatus.PAID,
                },
            }
        );
    }
}

export default new RentPaymentDao();
