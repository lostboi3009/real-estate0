import moment from 'moment-timezone';
import {
    FormattedResponse,
    GetAvailableForRent,
    IRentPaymentGeneratedOn,
    GetTenants,
    UpdatePropertyStatus,
    UpdateRent,
    UpdateTenantDueAmount,
    GetByPropertyId,
} from '@dto';

import {
    CompanyId,
    IProperty,
    ITenantDoc,
    ITenant,
    Property,
    PropertyStatus,
    Tenant,
    Status,
    CommonId,
    mongoose,
    getSearchRegex,
    TenantStatus,
    toObjectId,
    IProjectDoc,
    Project,
    IPropertyDoc,
    Pagination,
    TypesObjectId,
    RentBookingType,
} from '@homelead-shared-api';

type FilterQueryITenant = mongoose.FilterQuery<IProperty>;

class TenantDao {
    async getAll({
        project,
        company,
        page,
        perPage,
        search,
        status,
        tenantStatus,
        temporaryBookingPeriod,
    }: GetTenants & Pagination): Promise<ITenantDoc[]> {
        const temporaryBookingEndDate = moment().subtract(temporaryBookingPeriod, 'days').endOf('day');
        const matchCriteria: FilterQueryITenant = {
            project,
            company,
            status: { $ne: Status.ARCHIVED },
            $or: [
                { bookingType: RentBookingType.FINAL_BOOKING },
                {
                    $and: [
                        {
                            bookingType: RentBookingType.TEMPORARY_BOOKING,
                        },
                        {
                            bookingDate: {
                                $gte: temporaryBookingEndDate,
                            },
                        },
                    ],
                },
            ],
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (tenantStatus) {
            matchCriteria.tenantStatus = tenantStatus;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { name: { $regex: searchRegex } },
                { phone: { $regex: searchRegex } },
                { email: { $regex: searchRegex } },
            ];
        }

        return Tenant.find(matchCriteria)
            .skip((page - 1) * perPage)
            .limit(perPage)
            .populate([
                {
                    path: 'property',
                    select: 'propertyType propertyUnitSubType blockName floorName flatNo shopNo series',
                    populate: [
                        { path: 'propertyUnitSubType', select: 'name' },
                        { path: 'bhk', select: 'name' },
                    ],
                },
            ])
            .sort({
                _id: -1,
            });
    }

    async countAll({
        project,
        company,
        search,
        status,
        tenantStatus,
        temporaryBookingPeriod,
    }: GetTenants): Promise<number> {
        const temporaryBookingEndDate = moment().subtract(temporaryBookingPeriod, 'days').endOf('day');
        const matchCriteria: FilterQueryITenant = {
            project,
            company,
            status: { $ne: Status.ARCHIVED },
            $or: [
                { bookingType: RentBookingType.FINAL_BOOKING },
                {
                    $and: [
                        {
                            bookingType: RentBookingType.TEMPORARY_BOOKING,
                        },
                        {
                            bookingDate: {
                                $gte: temporaryBookingEndDate,
                            },
                        },
                    ],
                },
            ],
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (tenantStatus) {
            matchCriteria.tenantStatus = tenantStatus;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { name: { $regex: searchRegex } },
                { flatNo: { $regex: searchRegex } },
                { shopNo: { $regex: searchRegex } },
                { phone: { $regex: searchRegex } },
            ];
        }

        return Tenant.countDocuments(matchCriteria);
    }

    async create(tenant: ITenant): Promise<ITenantDoc> {
        return Tenant.create(tenant);
    }

    async getAvailableForRent({ company, project, temporaryBookingPeriod }: GetAvailableForRent) {
        const temporaryBookingEndDate = moment().subtract(temporaryBookingPeriod, 'days').endOf('day');

        const pipeline = [
            {
                $match: {
                    company: toObjectId(company as unknown as string),
                    project: toObjectId(project as unknown as string),
                    status: { $ne: Status.ARCHIVED },
                    $or: [
                        {
                            propertyStatus: {
                                $in: [
                                    PropertyStatus.AVAILABLE,
                                    PropertyStatus.TEMPORARY_BOOKED_FOR_RENT,
                                    PropertyStatus.ON_RENT,
                                    PropertyStatus.ON_RENT_TEMPORARY_BOOKED,
                                ],
                            },
                        },
                        {
                            $and: [
                                {
                                    propertyStatus: PropertyStatus.TEMPORARY_BOOKED,
                                },
                                {
                                    bookingDate: {
                                        $lte: temporaryBookingEndDate,
                                    },
                                },
                            ],
                        },
                    ],
                },
            },
            {
                $lookup: {
                    from: 'tenants',
                    let: { propertyId: '$_id' },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ['$property', '$$propertyId'] },
                                        { $in: ['$tenantStatus', [TenantStatus.STAYING, TenantStatus.TEMP_STAYING]] },
                                    ],
                                },
                            },
                        },
                    ],
                    as: 'tenants',
                },
            },
            {
                $group: {
                    _id: {
                        propertyId: '$_id',
                        flatNo: '$flatNo',
                        shopNo: '$shopNo',
                        propertyType: '$propertyType',
                        blockName: '$blockName',
                        floorName: '$floorName',
                    },
                    tenant: {
                        $first: {
                            id: { $arrayElemAt: ['$tenants._id', 0] },
                            name: { $arrayElemAt: ['$tenants.name', 0] },
                            phone: { $arrayElemAt: ['$tenants.phone', 0] },
                            rentAmount: { $arrayElemAt: ['$tenants.rentAmount', 0] },
                            rentStartDate: { $arrayElemAt: ['$tenants.rentStartDate', 0] },
                            bookingDate: { $arrayElemAt: ['$tenants.bookingDate', 0] },
                            tenantStatus: { $arrayElemAt: ['$tenants.tenantStatus', 0] },
                        },
                    },
                    propertyStatus: {
                        $first: '$propertyStatus',
                    },
                },
            },
            {
                $group: {
                    _id: {
                        propertyType: '$_id.propertyType',
                        blockName: '$_id.blockName',
                        floorName: '$_id.floorName',
                    },
                    units: {
                        $push: {
                            flatNo: '$_id.flatNo',
                            shopNo: '$_id.shopNo',
                            propertyId: '$_id.propertyId',
                            tenant: '$tenant',
                            propertyStatus: '$propertyStatus',
                        },
                    },
                },
            },
            {
                $group: {
                    _id: {
                        propertyType: '$_id.propertyType',
                        blockName: '$_id.blockName',
                    },
                    floors: {
                        $push: {
                            floorName: '$_id.floorName',
                            units: '$units',
                        },
                    },
                },
            },
            {
                $group: {
                    _id: '$_id.propertyType',
                    blocks: {
                        $push: {
                            blockName: '$_id.blockName',
                            floors: '$floors',
                        },
                    },
                },
            },
            {
                $project: {
                    propertyType: '$_id',
                    blocks: 1,
                    _id: 0,
                },
            },
        ];

        const result = await Property.aggregate(pipeline);

        const formattedResponse: FormattedResponse = result.reduce((acc, item) => {
            acc[item.propertyType] = acc[item.propertyType] || [];
            acc[item.propertyType].push({
                blocks: item.blocks,
            });
            return acc;
        }, {});

        return formattedResponse;
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<ITenantDoc | null> {
        return Tenant.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        }).populate({
            path: 'property',
        });
    }

    async getByPropertyId({ company, project, property }: GetByPropertyId): Promise<ITenantDoc | null> {
        return Tenant.findOne({
            company,
            project,
            property,
            tenantStatus: TenantStatus.STAYING,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, company, data }: UpdateRent) {
        return Tenant.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    async getProjectById({ id, company }: CommonId & CompanyId): Promise<IProjectDoc | null> {
        return Project.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getPropertyById({ id, company }: CommonId & CompanyId): Promise<IPropertyDoc | null> {
        return Property.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async UpdatePropertyStatus({ id, company, propertyStatus, bookingDate }: UpdatePropertyStatus) {
        return Property.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: { propertyStatus, bookingDate },
            }
        );
    }

    async decrementTotalRentedUnits({ id, company }: CommonId & CompanyId) {
        const project = await Project.findOne({ _id: id, company, status: { $ne: Status.ARCHIVED } });

        if (project && project.totalRentedUnits > 0) {
            await Project.updateOne(
                { _id: id, company, status: { $ne: Status.ARCHIVED } },
                { $set: { totalRentedUnits: project.totalRentedUnits - 1 } }
            );
        }
    }

    async incrementTotalRentedUnits({ id, company }: CommonId & CompanyId) {
        return Project.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $inc: { totalRentedUnits: 1 },
            }
        );
    }

    async increaseTenantDueAmount({ id, company, dueAmount }: UpdateTenantDueAmount) {
        const tenant = await Tenant.findOne({ _id: id, company, status: { $ne: Status.ARCHIVED } });

        if (tenant) {
            const dueRentAmount = (tenant.dueRentAmount || 0) + dueAmount;

            await Tenant.updateOne({ _id: id, company, status: { $ne: Status.ARCHIVED } }, { $set: { dueRentAmount } });
        }
    }

    async decreaseTenantDueAmount({ id, company, dueAmount }: UpdateTenantDueAmount) {
        const tenant = await Tenant.findOne({ _id: id, company, status: { $ne: Status.ARCHIVED } });

        if (tenant) {
            const dueRentAmount = tenant.dueRentAmount - dueAmount;

            await Tenant.updateOne({ _id: id, company, status: { $ne: Status.ARCHIVED } }, { $set: { dueRentAmount } });
        }
    }

    async getDueRentTenants({ rentPaymentGeneratedOn }: IRentPaymentGeneratedOn): Promise<ITenantDoc[]> {
        return Tenant.find({
            rentPaymentGeneratedOn: {
                $lte: rentPaymentGeneratedOn,
            },
            tenantStatus: { $in: [TenantStatus.STAYING] },
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateRentPaymentGeneratedOn({
        ids,
        rentPaymentGeneratedOn,
    }: IRentPaymentGeneratedOn & { ids: TypesObjectId[] }) {
        return Tenant.updateMany(
            {
                _id: { $in: ids },
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    rentPaymentGeneratedOn,
                },
            }
        );
    }
}

export default new TenantDao();
