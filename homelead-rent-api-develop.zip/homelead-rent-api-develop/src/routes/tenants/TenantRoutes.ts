import { RequestHandler, Router } from 'express';
import TenantService from './TenantService';
import TenantValidations from './TenantValidations';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.TENANTS_LIST),
    validate(TenantValidations.getAll, 'query'),
    TenantService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.TENANTS_ADD),
    validate(TenantValidations.create),
    TenantService.create as RequestHandler
);

router.get(
    '/available-for-rent',
    verifyToken(),
    validate(TenantValidations.getAvailableForRent, 'query'),
    TenantService.getAvailableForRent as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.TENANTS_VIEW),
    validate(TenantValidations.requiredId, 'params'),
    TenantService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.TENANTS_UPDATE),
    validate(TenantValidations.requiredId, 'params'),
    validate(TenantValidations.update),
    TenantService.updateById as RequestHandler
);

router.put(
    '/renew-agreement/:id',
    verifyToken(UserPermissions.TENANTS_RENEW_AGREEMENT),
    validate(TenantValidations.renewAgreement),
    TenantService.renewAgreement as RequestHandler
);

router.put(
    '/leave-tenant/:id',
    verifyToken(UserPermissions.TENANTS_LEAVE),
    validate(TenantValidations.leaveTenant),
    TenantService.leaveTenant as RequestHandler
);

export { router };
