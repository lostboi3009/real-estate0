export { router } from './TenantRoutes';
