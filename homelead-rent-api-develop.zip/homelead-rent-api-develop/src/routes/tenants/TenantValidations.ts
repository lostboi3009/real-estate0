import {
    joi,
    RentBookingType,
    commonValidations,
    PaymentMode,
    Relation,
    RentPaymentStatus,
    TenantStatus,
} from '@homelead-shared-api';

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const getAll = joi.object().keys({
    project: commonValidations.id,
    page: commonValidations.page,
    perPage: commonValidations.perPage,
    search: joi.string().trim().optional(),
    status: commonValidations.status.optional(),
    tenantStatus: joi
        .string()
        .trim()
        .valid(...Object.values(TenantStatus))
        .optional(),
});

const getAvailableForRent = joi.object().keys({
    project: commonValidations.id,
});

const create = joi.object().keys({
    project: commonValidations.id,
    property: commonValidations.id,
    name: joi.string().trim().min(3).max(30).required(),
    countryCode: commonValidations.countryCode.required(),
    phone: commonValidations.phone,
    email: commonValidations.email,
    aadharNo: joi.string().trim().length(12).required(),
    panNo: joi.string().trim().length(10).required(),
    avatar: joi.string().trim().optional(),
    totalMember: joi.number().positive().required(),
    members: joi
        .array()
        .items(
            joi.object().keys({
                name: joi.string().trim().required(),
                age: joi.number().positive().required(),
                relation: joi
                    .string()
                    .trim()
                    .valid(...Object.values(Relation))
                    .required(),
            })
        )
        .required(),
    isPets: joi.boolean().optional(),
    bookingDate: joi.date().required(),
    bookingType: joi
        .string()
        .trim()
        .valid(...Object.values(RentBookingType))
        .required(),
    rentAmount: joi.number().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    rentIncrement: joi.number().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    depositAmount: joi.number().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    isMaintenanceIncluded: joi.boolean().optional(),
    isPoliceVerificationDone: joi.boolean().optional(),
    rentStartDate: joi.date().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi.date().required(),
        otherwise: joi.date().optional(),
    }),
    rentAgreements: joi.array().items(joi.string().trim().required()).optional(),
    paymentStatus: joi.string().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(RentPaymentStatus))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    paymentMode: joi.string().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(PaymentMode))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    referenceNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
});

const update = joi.object().keys({
    name: joi.string().trim().min(3).max(30).required(),
    countryCode: commonValidations.countryCode.required(),
    phone: commonValidations.phone,
    email: commonValidations.email,
    aadharNo: joi.string().trim().length(12).required(),
    panNo: joi.string().trim().length(10).required(),
    avatar: joi.string().trim().optional(),
    totalMember: joi.number().positive().required(),
    members: joi
        .array()
        .items(
            joi.object().keys({
                name: joi.string().trim().required(),
                age: joi.number().positive().required(),
                relation: joi
                    .string()
                    .trim()
                    .valid(...Object.values(Relation))
                    .required(),
            })
        )
        .required(),
    isPets: joi.boolean().optional(),
    bookingType: joi
        .string()
        .trim()
        .valid(...Object.values(RentBookingType))
        .required(),
    rentAmount: joi.number().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    rentIncrement: joi.number().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    depositAmount: joi.number().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    isMaintenanceIncluded: joi.boolean().optional(),
    isPoliceVerificationDone: joi.boolean().optional(),
    rentStartDate: joi.date().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi.date().required(),
        otherwise: joi.date().optional(),
    }),
    rentAgreements: joi.array().items(joi.string().trim().required()).optional(),
    paymentStatus: joi.string().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(RentPaymentStatus))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    paymentMode: joi.string().when('bookingType', {
        is: [RentBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(PaymentMode))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    referenceNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
});

const updateStatus = joi.object().keys({
    status: commonValidations.status,
});

const renewAgreement = joi.object().keys({
    rentAmount: joi.number().required(),
    rentAgreements: joi.array().items(joi.string().trim().required()).required(),
    rentAgreementStartDate: joi.date().required(),
    rentAgreementEndDate: joi.date().greater(joi.ref('rentAgreementStartDate')).required(),
});

const leaveTenant = joi.object().keys({
    leavingDate: joi.date().required(),
    adjustedDepositAmount: joi.number().positive().required(),
    depositPaymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .optional(),
    depositReferenceNo: joi.string().trim().optional(),
    depositRemarks: joi.string().trim().optional(),
});

export default {
    requiredId,
    getAll,
    getAvailableForRent,
    create,
    update,
    updateStatus,
    renewAgreement,
    leaveTenant,
};
