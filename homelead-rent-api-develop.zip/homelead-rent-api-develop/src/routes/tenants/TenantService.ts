import { Request, Response } from 'express';
import TenantDao from '../../dao/TenantDao';
import {
    RentBookingType,
    CommonId,
    Pagination,
    PropertyStatus,
    RentPaymentStatus,
    TenantStatus,
    TypesObjectId,
} from '@homelead-shared-api';
import { ITenantData, GetTenants, ILeaveTenant, IRenewAgreement } from '@dto';
import moment from 'moment-timezone';
import RentPaymentDao from '../../dao/RentPaymentDao';
import UserDao from '../../dao/UserDao';

class TenantService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { project, page, perPage, search, status, tenantStatus } = req.query as unknown as GetTenants &
            Pagination;
        const settings = await UserDao.getCompanySettings({ company });
        const temporaryBookingPeriod = settings?.general?.tempRentBookingPeriod || 7;

        const [count, tenants] = await Promise.all([
            TenantDao.countAll({
                project,
                company,
                search,
                status,
                tenantStatus,
                temporaryBookingPeriod,
            }),
            TenantDao.getAll({
                project,
                company,
                page,
                perPage,
                search,
                status,
                tenantStatus,
                temporaryBookingPeriod,
            }),
        ]);

        return res.success({ count, tenants });
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const data: ITenantData = req.body;
        let propertyStatus = PropertyStatus.ON_RENT;
        let tenantStatus = TenantStatus.STAYING;

        const property = await TenantDao.getPropertyById({ id: data.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const existingTenant = await TenantDao.getByPropertyId({
            company,
            project: data.project,
            property: data.property,
        });

        if (existingTenant) {
            return res.notFound(null, req.__('TENANT_ALREADY_STAYING'));
        }

        if (
            [
                PropertyStatus.ON_RENT,
                PropertyStatus.ON_RENT_TEMPORARY_BOOKED,
                PropertyStatus.BOOKED,
                PropertyStatus.SOLD,
            ].includes(property.propertyStatus)
        ) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }
        const settings = await UserDao.getCompanySettings({ company });

        if (property.propertyStatus === PropertyStatus.TEMPORARY_BOOKED_FOR_RENT) {
            const temporaryBookingPeriod = settings?.general?.tempRentBookingPeriod || 7;
            const temporaryBookingEndDate = moment().subtract(temporaryBookingPeriod, 'days').endOf('day');
            if (temporaryBookingEndDate.isBefore(moment(property.bookingDate))) {
                return res.warn(null, req.__('PROPERTY_TEMPORARILY_BOOKED'));
            }
        }

        if (property.propertyStatus === PropertyStatus.TEMPORARY_BOOKED) {
            const temporaryBookingPeriod = settings?.general?.tempPropertyBookingPeriod || 7;
            const temporaryBookingEndDate = moment().subtract(temporaryBookingPeriod, 'days').endOf('day');
            if (temporaryBookingEndDate.isBefore(moment(property.bookingDate))) {
                return res.warn(null, req.__('PROPERTY_TEMPORARILY_BOOKED'));
            }
        }

        const project = await TenantDao.getProjectById({ id: data.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        if (data.bookingType === RentBookingType.TEMPORARY_BOOKING) {
            propertyStatus = PropertyStatus.TEMPORARY_BOOKED_FOR_RENT;
            tenantStatus = TenantStatus.TEMP_STAYING;
        }

        const tenant = await TenantDao.create({
            ...data,
            company,
            rentAgreementStartDate: data.rentStartDate,
            tenantStatus,
            dueRentAmount:
                data.bookingType === RentBookingType.FINAL_BOOKING && data.paymentStatus === RentPaymentStatus.DUE
                    ? data.rentAmount || 0
                    : 0,
            rentPaymentGeneratedOn: moment().toDate(),
        });

        await TenantDao.UpdatePropertyStatus({
            id: data.property,
            company,
            propertyStatus,
            bookingDate: data.bookingDate,
        });

        if (data.bookingType === RentBookingType.FINAL_BOOKING) {
            await RentPaymentDao.create({
                company,
                project: data.project,
                property: data.property,
                tenant: tenant._id,
                startDate: moment(data.rentStartDate).toDate(),
                endDate: moment(data.rentStartDate).add(1, 'month').toDate(),
                amount: data.rentAmount || 0,
                amountPaid: data.paymentStatus === RentPaymentStatus.PAID ? data.rentAmount || 0 : 0,
                paymentStatus: data.paymentStatus,
                paymentMode: data.paymentMode,
                receivedOn: moment().toDate(),
                referenceNo: data.referenceNo,
                remarks: data.remarks,
            });

            await TenantDao.incrementTotalRentedUnits({ id: data.project, company });

            const totalRentAmountRequired = (project.totalRentAmountRequired || 0) + (data.rentAmount || 0);
            let totalRentRevenue = project.totalRentRevenue || 0;

            if (data.paymentStatus === RentPaymentStatus.PAID) {
                totalRentRevenue += data.rentAmount || 0;
            }

            await RentPaymentDao.updateProjectRentRevenue({
                company,
                project: data.project,
                totalRentAmountRequired,
                totalRentRevenue,
            });
        }

        return res.success(tenant);
    }

    async getAvailableForRent(req: Request, res: Response) {
        const { company } = req.user;
        const project = req.query.project as unknown as TypesObjectId;
        const settings = await UserDao.getCompanySettings({ company });
        const temporaryBookingPeriod = settings?.general?.tempPropertyBookingPeriod || 7;

        const availableForRent = await TenantDao.getAvailableForRent({ company, project, temporaryBookingPeriod });

        return res.success(availableForRent);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const tenant = await TenantDao.getById({ id, company });

        if (!tenant) {
            return res.notFound(null, req.__('TENANT_NOT_FOUND'));
        }

        return res.success(tenant);
    }

    async updateById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Omit<ITenantData, 'project' | 'property'> = req.body;

        const tenant = await TenantDao.getById({ id, company });

        if (!tenant) {
            return res.notFound(null, req.__('TENANT_NOT_FOUND'));
        }

        if (tenant.tenantStatus === TenantStatus.TEMP_STAYING) {
            const settings = await UserDao.getCompanySettings({ company });
            const temporaryBookingPeriod = settings?.general?.tempRentBookingPeriod || 7;

            const temporaryBookingEndDate = moment(tenant.bookingDate).add(temporaryBookingPeriod, 'days').endOf('day');

            if (temporaryBookingEndDate.isBefore(moment())) {
                return res.notFound(null, req.__('TENANT_NOT_FOUND'));
            }
        }

        const property = await TenantDao.getPropertyById({ id: tenant.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        if (
            [PropertyStatus.TEMPORARY_BOOKED, PropertyStatus.BOOKED, PropertyStatus.SOLD].includes(
                property.propertyStatus
            )
        ) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const project = await TenantDao.getProjectById({ id: tenant.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        if (
            tenant.tenantStatus === TenantStatus.STAYING ||
            (tenant.tenantStatus === TenantStatus.TEMP_STAYING &&
                data.bookingType === RentBookingType.TEMPORARY_BOOKING)
        ) {
            await TenantDao.updateById({
                id,
                company,
                data: {
                    name: data.name,
                    countryCode: data.countryCode,
                    phone: data.phone,
                    email: data.email,
                    aadharNo: data.aadharNo,
                    panNo: data.panNo,
                    avatar: data.avatar,
                    totalMember: data.totalMember,
                    members: data.members,
                    isPets: data.isPets,
                    rentIncrement: data.rentIncrement,
                    isMaintenanceIncluded: data.isMaintenanceIncluded,
                    isPoliceVerificationDone: data.isPoliceVerificationDone,
                    rentStartDate: data.rentStartDate,
                    rentAgreements: data.rentAgreements,
                },
            });
        }

        if (tenant.tenantStatus === TenantStatus.TEMP_STAYING && data.bookingType === RentBookingType.FINAL_BOOKING) {
            await TenantDao.updateById({
                id,
                company,
                data: {
                    ...data,
                    rentAgreementStartDate: data.rentStartDate,
                    tenantStatus: TenantStatus.STAYING,
                    dueRentAmount: data.paymentStatus === RentPaymentStatus.DUE ? data.rentAmount : 0,
                    rentPaymentGeneratedOn: moment().toDate(),
                },
            });

            await TenantDao.UpdatePropertyStatus({
                id: tenant.property,
                company,
                propertyStatus: PropertyStatus.ON_RENT,
            });

            await RentPaymentDao.create({
                company,
                project: tenant.project,
                property: tenant.property,
                tenant: tenant._id,
                startDate: moment(data.rentStartDate).toDate(),
                endDate: moment(data.rentStartDate).add(1, 'month').toDate(),
                amount: data.rentAmount || 0,
                amountPaid: data.paymentStatus === RentPaymentStatus.PAID ? data.rentAmount || 0 : 0,
                paymentStatus: data.paymentStatus,
                paymentMode: data.paymentMode,
                receivedOn: moment().toDate(),
                referenceNo: data.referenceNo,
                remarks: data.remarks,
            });

            await TenantDao.incrementTotalRentedUnits({ id: tenant.project, company });

            const totalRentAmountRequired = (project.totalRentAmountRequired || 0) + (data.rentAmount || 0);
            let totalRentRevenue = project.totalRentRevenue || 0;

            if (data.paymentStatus === RentPaymentStatus.PAID) {
                totalRentRevenue += data.rentAmount || 0;
            }

            await RentPaymentDao.updateProjectRentRevenue({
                company,
                project: tenant.project,
                totalRentAmountRequired,
                totalRentRevenue,
            });
        }

        return res.success(null, req.__('TENANT_UPDATE_SUCCESS'));
    }

    async renewAgreement(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: IRenewAgreement = req.body;

        const tenant = await TenantDao.getById({ id, company });

        if (!tenant) {
            return res.notFound(null, req.__('TENANT_NOT_FOUND'));
        }

        if (tenant.tenantStatus !== TenantStatus.STAYING) {
            return res.notFound(null, req.__('TENANT_NOT_STAYING'));
        }

        await TenantDao.updateById({ id, company, data });

        return res.success(null, req.__('RENEW_AGREEMENT_SUCCESSFUL'));
    }

    async leaveTenant(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: ILeaveTenant = req.body;

        const tenant = await TenantDao.getById({ id, company });

        if (!tenant) {
            return res.notFound(null, req.__('TENANT_NOT_FOUND'));
        }

        if (tenant.tenantStatus !== TenantStatus.STAYING) {
            return res.notFound(null, req.__('TENANT_NOT_STAYING'));
        }

        await TenantDao.updateById({
            id,
            company,
            data: {
                ...data,
                tenantStatus: TenantStatus.LEFT,
            },
        });

        await TenantDao.UpdatePropertyStatus({
            id: tenant.property,
            company,
            propertyStatus: PropertyStatus.AVAILABLE,
        });

        await TenantDao.decrementTotalRentedUnits({ id: tenant.project, company });

        return res.success(null, req.__('LEAVE_TENANT_SUCCESSFUL'));
    }
}

export default new TenantService();
