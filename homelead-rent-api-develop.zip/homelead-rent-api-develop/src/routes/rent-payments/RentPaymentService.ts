import { Request, Response } from 'express';
import { CommonId, IRentPayment, Pagination, RentPaymentStatus, TenantStatus } from '@homelead-shared-api';
import RentPaymentDao from '../../dao/RentPaymentDao';
import TenantDao from '../../dao/TenantDao';
import { GetAllRentPayments, MarkAsPaid, PartialPayment } from '@dto';
import moment from 'moment-timezone';

class RentPaymentService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, tenant, project, paymentStatus } = req.query as unknown as GetAllRentPayments &
            Pagination;

        const [count, rentPayments] = await Promise.all([
            RentPaymentDao.countAll({
                company,
                tenant,
                project,
                paymentStatus,
            }),
            RentPaymentDao.getAll({
                company,
                page,
                perPage,
                tenant,
                project,
                paymentStatus,
            }),
        ]);

        return res.success({ count, rentPayments });
    }

    async createRentPayment(req: Request, res: Response) {
        const { company } = req.user;
        const rentPaymentData: IRentPayment = req.body;

        const tenant = await TenantDao.getById({ id: rentPaymentData.tenant, company });

        if (!tenant) {
            return res.notFound(null, req.__('TENANT_NOT_FOUND'));
        }

        if (tenant.tenantStatus !== TenantStatus.STAYING) {
            return res.notFound(null, req.__('TENANT_NOT_STAYING'));
        }

        const project = await TenantDao.getProjectById({ id: rentPaymentData.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const existingPayments = await RentPaymentDao.getTenantPayment({
            company,
            tenant: rentPaymentData.tenant,
            startDate: rentPaymentData.startDate,
            endDate: rentPaymentData.endDate,
        });

        if (existingPayments.length) {
            return res.badRequest(null, req.__('EXISTING_DATE_ERROR'));
        }

        const rentPayment = await RentPaymentDao.create({
            ...rentPaymentData,
            company,
            property: tenant.property,
            paymentStatus: RentPaymentStatus.PAID,
            amountPaid: tenant.rentAmount || 0,
        });

        const rentPaymentGeneratedOn = moment().endOf('day').toDate();
        const totalRentAmountRequired = (project.totalRentAmountRequired || 0) + rentPaymentData.amount;
        const totalRentRevenue = (project.totalRentRevenue || 0) + rentPaymentData.amount;

        await TenantDao.updateById({
            id: rentPaymentData.tenant,
            company,
            data: {
                rentPaymentGeneratedOn,
            },
        });

        await RentPaymentDao.updateProjectRentRevenue({
            company,
            project: rentPaymentData.project,
            totalRentAmountRequired,
            totalRentRevenue,
        });

        return res.success(rentPayment);
    }

    async getRentPaymentById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;

        const rentPayment = await RentPaymentDao.getById({ id });

        if (!rentPayment) {
            return res.warn(null, req.__('RENT_NOT_FOUND'));
        }

        return res.success(rentPayment);
    }

    async markAsPaid(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const data: MarkAsPaid = req.body;
        const { company } = req.user;

        const rentPayment = await RentPaymentDao.getById({ id });

        if (!rentPayment) {
            return res.notFound(null, req.__('RENT_PAYMENT_NOT_FOUND'));
        }

        if (rentPayment.paymentStatus === RentPaymentStatus.PAID) {
            return res.badRequest(null, req.__('RENT_PAYMENT_ALREADY_PAID'));
        }

        const tenant = await TenantDao.getById({ id: rentPayment.tenant, company });

        if (!tenant) {
            return res.notFound(null, req.__('TENANT_NOT_FOUND'));
        }

        await RentPaymentDao.markAsPaid({
            ...data,
            id,
            company,
            amountPaid: rentPayment.amount,
        });

        await TenantDao.decreaseTenantDueAmount({
            id: rentPayment.tenant,
            company,
            dueAmount: rentPayment.amount,
        });

        await RentPaymentDao.increaseProjectTotalRentRevenue({
            company,
            id: rentPayment.project,
            dueAmount: rentPayment.amount,
        });

        return res.success(null, req.__('PAYMENT_MARKED_AS_COMPLETED'));
    }

    async partialPayments(req: Request, res: Response) {
        const { company } = req.user;
        const { amount, tenant }: PartialPayment = req.body;
        let updatedAmount = amount;

        const tenantData = await TenantDao.getById({ id: tenant, company });

        if (!tenantData) {
            return res.notFound(null, req.__('TENANT_NOT_FOUND'));
        }

        if (tenantData.tenantStatus !== TenantStatus.STAYING) {
            return res.notFound(null, req.__('TENANT_NOT_STAYING'));
        }

        if (amount > tenantData.dueRentAmount) {
            return res.warn(null, req.__('PAID_AMOUNT_EXCEEDS_DUE_AMOUNT'));
        }

        const project = await TenantDao.getProjectById({ id: tenantData.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const dueRentPayments = await RentPaymentDao.getByTenantId({
            company,
            tenant,
        });

        if (!dueRentPayments.length) {
            return res.notFound(null, req.__('NO_DUE_PAYMENTS_FOUND'));
        }

        const updatedRentPaymentsPromises = dueRentPayments.map(rent => {
            if (updatedAmount > 0) {
                const dueAmount = rent.amount - rent.amountPaid;
                if (dueAmount > 0) {
                    const amountPaid = updatedAmount > dueAmount ? dueAmount : updatedAmount;
                    updatedAmount -= amountPaid;

                    return RentPaymentDao.updateDuePaymentById({
                        company,
                        id: rent._id,
                        data: {
                            amountPaid,
                            paymentStatus: amountPaid === dueAmount ? RentPaymentStatus.PAID : RentPaymentStatus.DUE,
                        },
                    });
                }
            }
        });

        await Promise.all(updatedRentPaymentsPromises);

        const totalRentAmountRequired = project.totalRentAmountRequired || 0;
        const totalRentRevenue = project.totalRentRevenue || 0 + amount;

        await TenantDao.decreaseTenantDueAmount({
            id: tenantData._id,
            company,
            dueAmount: amount,
        });

        await RentPaymentDao.updateProjectRentRevenue({
            company,
            project: tenantData.project,
            totalRentAmountRequired,
            totalRentRevenue,
        });

        return res.success(null, req.__('PAYMENTS_SUCCESSFUL'));
    }
}

export default new RentPaymentService();
