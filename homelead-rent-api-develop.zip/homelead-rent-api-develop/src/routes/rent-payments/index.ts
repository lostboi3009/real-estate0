export { router } from './RentPaymentRoutes';
