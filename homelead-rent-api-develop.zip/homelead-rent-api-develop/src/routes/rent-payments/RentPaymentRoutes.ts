import { RequestHandler, Router } from 'express';
import RentPaymentService from './RentPaymentService';
import RentPaymentValidations from './RentPaymentValidations';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.RENTS_PAYMENTS_LIST),
    validate(RentPaymentValidations.getAll, 'query'),
    RentPaymentService.getAll as unknown as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.RENTS_PAYMENTS_ADD),
    validate(RentPaymentValidations.create),
    RentPaymentService.createRentPayment as unknown as RequestHandler
);

router.post(
    '/partial-payment',
    verifyToken(UserPermissions.RENTS_PAYMENTS_PARTIAL_PAYMENTS),
    validate(RentPaymentValidations.partialPayment),
    RentPaymentService.partialPayments
);

router.get(
    '/:id',
    verifyToken(UserPermissions.RENTS_PAYMENTS_VIEW),
    RentPaymentService.getRentPaymentById as unknown as RequestHandler
);

router.put(
    '/mark-as-paid/:id',
    verifyToken(UserPermissions.RENTS_PAYMENTS_MARK_AS_PAID),
    validate(RentPaymentValidations.requiredId, 'params'),
    validate(RentPaymentValidations.markAsPaid),
    RentPaymentService.markAsPaid as unknown as RequestHandler
);

export { router };
