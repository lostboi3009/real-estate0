import { joi, commonValidations, RentPaymentStatus, PaymentMode } from '@homelead-shared-api';

const create = joi.object().keys({
    project: commonValidations.id,
    tenant: commonValidations.id,
    startDate: joi.date().required(),
    endDate: joi.date().greater(joi.ref('startDate')).required(),
    amount: joi.number().positive().required(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .required(),
    referenceNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
    receivedOn: joi.date().optional(),
});

const getAll = joi.object().keys({
    page: commonValidations.page,
    perPage: commonValidations.perPage,
    project: commonValidations.id,
    tenant: commonValidations.id.optional(),
    paymentStatus: joi
        .string()
        .trim()
        .valid(...Object.values(RentPaymentStatus))
        .optional(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const markAsPaid = joi.object().keys({
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .required(),
    referenceNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
    receivedOn: joi.date().optional(),
});

const partialPayment = joi.object().keys({
    amount: joi.number().positive().required(),
    tenant: commonValidations.id,
});

export default {
    create,
    getAll,
    requiredId,
    markAsPaid,
    partialPayment,
};
