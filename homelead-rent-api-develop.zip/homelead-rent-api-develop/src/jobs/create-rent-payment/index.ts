import Agenda from 'agenda';
import { logger } from '@homelead-shared-api';
import { DefineJob, Job } from '@dto';
import Service from './Service';

const JOB_INTERVAL = process.env.CREATE_RENT_PAYMENT_INTERVAL;

const defineJob: DefineJob = async (jobName: string, agenda: Agenda) => {
    if (JOB_INTERVAL) {
        agenda.define(jobName, { priority: 0 }, async (job, done) => {
            logger.info(`:: JOB "${jobName}" STARTED ::`);
            try {
                await Service.createRentPayments();
                done();
            } catch (e) {
                logger.error(`:: JOB "${jobName}" FAILED WITH ERROR`, e);
                throw e;
            }
        });
        await agenda.every(JOB_INTERVAL, jobName, undefined, {
            skipImmediate: false,
        });
    }
};

const job: Job = {
    defineJob,
};

export default job;
