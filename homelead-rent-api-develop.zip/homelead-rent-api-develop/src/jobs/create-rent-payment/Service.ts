import {
    RentPaymentStatus,
    TypesObjectId,
    PaymentMode,
    isDevEnv,
    sendMail,
    logger,
    mongoose,
} from '@homelead-shared-api';
import RentPaymentDao from '../../dao/RentPaymentDao';
import TenantDao from '../../dao/TenantDao';
import moment from 'moment-timezone';
import { IRentPayments, languages, UpdateTotalRentAmountRequired } from '@dto';
import { __ } from '@lib/i18n';

const RENT_PAYMENT_BASE_URL = process.env.RENT_PAYMENT_BASE_URL;

class Service {
    async createRentPayments() {
        const rentPaymentGeneratedOn = moment().subtract(30, 'days').startOf('day').toDate();
        const totalRentAmountRequiredObj: Record<string, UpdateTotalRentAmountRequired> = {};
        const increaseTenantDueAmountPromises = [];
        const totalRentAmountRequirePromises = [];

        const tenants = await TenantDao.getDueRentTenants({
            rentPaymentGeneratedOn,
        });

        const tenantIds: TypesObjectId[] = [];
        const rentPayments: IRentPayments[] = [];
        const paymentId = new mongoose.Types.ObjectId();

        for (const tenant of tenants) {
            rentPayments.push({
                _id: paymentId,
                company: tenant.company,
                project: tenant.project,
                property: tenant.property,
                tenant: tenant._id,
                startDate: new Date(),
                endDate: moment(tenant.rentStartDate).add(1, 'month').toDate(),
                amount: tenant.rentAmount || 0,
                amountPaid: 0,
                paymentStatus: RentPaymentStatus.DUE,
                paymentMode: PaymentMode.ONLINE,
            });

            tenantIds.push(tenant._id);

            increaseTenantDueAmountPromises.push(
                TenantDao.increaseTenantDueAmount({
                    id: tenant._id,
                    company: tenant.company,
                    dueAmount: tenant.rentAmount || 0,
                })
            );

            totalRentAmountRequiredObj[tenant.project as unknown as string] = {
                id: tenant.project,
                company: tenant.company,
                dueAmount:
                    (totalRentAmountRequiredObj[tenant.project as unknown as string]?.dueAmount || 0) +
                    (tenant.rentAmount || 0),
            };

            if (!isDevEnv) {
                sendMail('rent-payment-due', __('en','RENT_PAYMENT_DUE'), tenant.email as unknown as string, {
                    tenantName: tenant.name,
                    startDate: new Date(),
                    endDate: moment(tenant.rentStartDate).add(1, 'month').toDate(),
                    paymentLink: `${RENT_PAYMENT_BASE_URL}/${paymentId}`,
                }).catch(error => {
                    logger.error(`createRentPayments:: failed to send email to ${tenant.email}`, error);
                });
            }
        }

        for (const key in totalRentAmountRequiredObj) {
            if (totalRentAmountRequiredObj[key]) {
                totalRentAmountRequirePromises.push(
                    RentPaymentDao.increaseProjectTotalRentRevenueRequired(totalRentAmountRequiredObj[key])
                );
            }
        }

        await RentPaymentDao.bulkCreate(rentPayments);
        await TenantDao.updateRentPaymentGeneratedOn({ ids: tenantIds, rentPaymentGeneratedOn });
        await Promise.all(increaseTenantDueAmountPromises);
        await Promise.all(totalRentAmountRequirePromises);
    }
}

export default new Service();
