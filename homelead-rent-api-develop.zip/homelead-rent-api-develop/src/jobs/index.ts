import Agenda from 'agenda';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { logger } from '@homelead-shared-api';
import { Job } from '@dto';

const setupJobs = async () => {
    const nodeAppInstance = process.env.NODE_APP_INSTANCE ?? '0';

    if (nodeAppInstance === '0') {
        try {
            const jobs: string[] = fs.readdirSync(path.join(__dirname));
            const agenda: Agenda = new Agenda({
                db: {
                    address: process.env.MONGO_URI,
                    collection: 'agenda-jobs',
                },
                defaultConcurrency: 5,
                maxConcurrency: 10,
            });

            await agenda.start();

            for (const i of jobs) {
                if (fs.lstatSync(`${__dirname}/${i}`).isDirectory()) {
                    const job: Job = require(`./${i}`).default;
                    const jobName = `${os.hostname}-${i}`;
                    await job.defineJob(jobName, agenda);
                }
            }

            logger.info('🔥 Jobs set up successful. 🔥');
        } catch (e) {
            logger.error('Failed to set up jobs with error', e);
            throw e;
        }
    }
};

export default setupJobs;
