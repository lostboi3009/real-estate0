declare global {
    namespace NodeJS {
        interface ProcessEnv {
            PORT: string;
            SITE_TITLE: string;
            SITE_URL: string;
            LOGO_PATH: string;
            NODE_ENV: 'development' | 'production';
            SERVER_MODE: 'http' | 'https';
            SERVER_NAME: string;
            SSL_KEY_PATH: string;
            SSL_CERT_PATH: string;
            SSL_CA_PATH: string;
            MONGO_URI: string;
            MAIL_SERVICE: string;
            FROM_MAIL: string;
            SENDGRID_API_KEY: string;
            SMTP_HOST: string;
            SMTP_PORT: number;
            SMTP_SECURE: 'true' | 'false';
            TLS_CHECK: 'true' | 'false';
            SMTP_SERVICE: string;
            SMTP_USERNAME: string;
            SMTP_PASSWORD: string;
            VALIDATE_SESSION: string;
            VALIDATE_PERMISSION: string;
            JWT_SECRET: string;
            SESSION_SECRET: string;
            SESSION_VALIDITY_DAYS: string;
            LOG_LEVEL: 'error' | 'warn' | 'info' | 'verbose' | 'debug' | 'silly';
            MONGOOSE_DEBUG: 'true' | 'false';
            LOG_REQUESTS: 'true' | 'false';
        }
    }
}
export {};
