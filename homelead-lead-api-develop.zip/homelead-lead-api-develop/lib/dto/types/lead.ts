import {
    PropertyType,
    Status,
    TypesObjectId,
    SourceType,
    BuyingTimeLine,
    LeadStatus,
    CompanyId,
    ILeadAssignee,
    ILeadNote,
    ILead,
    ILeadDoc,
} from '@homelead-shared-api';

export interface GetLeads extends CompanyId {
    search?: string;
    status?: Status;
    sourceType?: SourceType;
    project?: TypesObjectId;
    propertyType?: PropertyType;
    bhk?: TypesObjectId;
    bhkType?: TypesObjectId;
    buyingTimeline?: BuyingTimeLine;
    leadStatus?: LeadStatus;
    fromDate?: Date;
    toDate?: Date;
    tags?: string[];
    assignees?: string[];
    broker?: TypesObjectId;
}

export interface ILeadId {
    lead: TypesObjectId;
}

export interface GetOnGoingLeadsByIds extends CompanyId {
    ids: TypesObjectId[];
}

export interface BulkLeadAssign {
    leads: TypesObjectId[];
    team?: TypesObjectId;
    assignees: ILeadAssignee[];
}

export interface ArchiveLeadAssignmentsByLeadIds extends CompanyId {
    ids: TypesObjectId[];
}

export interface BulkDelete {
    ids: TypesObjectId[];
}

export interface ILeadNoteData extends ILeadNote {
    leadStatus: LeadStatus;
}

export interface IDirectLead extends Omit<ILead, 'leadNo' | 'sourceType' | 'project'> {
    company: TypesObjectId;
    project: TypesObjectId;
}

export interface LeadGetAndCount {
    count: number;
    leads: ILeadDoc[];
}

export interface CreateAndAssignLead extends ILead {
    team?: TypesObjectId;
    assignees?: ILeadAssignee[];
}
