import {
    CommonId,
    CompanyId,
    Counter,
    getSearchRegex,
    ILead,
    ILeadAssignment,
    ILeadAssignmentDoc,
    ILeadDoc,
    Lead,
    LeadAssignment,
    mongoose,
    Status,
    ICounterDoc,
    Pagination,
    LeadStatus,
    TypesObjectId,
    toObjectId,
    Project,
    IProjectDoc,
    IBrokerDoc,
    Broker,
} from '@homelead-shared-api';
import { ArchiveLeadAssignmentsByLeadIds, BulkDelete, GetLeads, GetOnGoingLeadsByIds } from '@dto';
import { PipelineStage } from 'mongoose';

type FilterQueryILead = mongoose.FilterQuery<ILeadDoc>;

class LeadDao {
    async getAndCount({
        company,
        search,
        status,
        page,
        perPage,
        sourceType,
        project,
        propertyType,
        bhk,
        bhkType,
        buyingTimeline,
        leadStatus,
        fromDate,
        toDate,
        tags,
        assignees,
        broker,
    }: GetLeads & Pagination) {
        const matchCriteria: FilterQueryILead = {
            company,
            status: { $ne: Status.ARCHIVED },
        };

        if (status) {
            matchCriteria.status = status;
        }

        if (sourceType) {
            matchCriteria.sourceType = sourceType;
        }

        if (project) {
            matchCriteria.project = project;
        }

        if (propertyType) {
            matchCriteria.propertyType = propertyType;
        }

        if (bhk) {
            matchCriteria.bhk = bhk;
        }

        if (bhkType) {
            matchCriteria.bhkType = bhkType;
        }

        if (buyingTimeline) {
            matchCriteria.buyingTimeline = buyingTimeline;
        }

        if (leadStatus) {
            matchCriteria.leadStatus = leadStatus;
        }

        if (fromDate && toDate) {
            matchCriteria.createdAt = {
                $gte: new Date(fromDate),
                $lte: new Date(toDate),
            };
        }

        if (broker) {
            matchCriteria.broker = broker;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [
                { name: { $regex: searchRegex } },
                { phone: { $regex: searchRegex } },
                { secondaryPhone: { $regex: searchRegex } },
                { email: { $regex: searchRegex } },
                { whatsAppNumber: { $regex: searchRegex } },
                { financialQualification: { $regex: searchRegex } },
            ];
        }

        const pipeline: PipelineStage[] = [
            {
                $match: matchCriteria,
            },
        ];

        if (tags?.length) {
            pipeline.push({
                $lookup: {
                    from: 'lead-notes',
                    localField: '_id',
                    foreignField: 'lead',
                    as: 'lead-notes',
                },
            });

            pipeline.push({
                $unwind: {
                    path: '$lead-notes',
                },
            });

            pipeline.push({
                $match: {
                    'lead-notes.tag': {
                        $in: tags.map(tag => toObjectId(tag)),
                    },
                },
            });

            pipeline.push({
                $project: {
                    'lead-notes': 0,
                },
            });
        }

        if (assignees?.length) {
            pipeline.push({
                $lookup: {
                    from: 'lead-assignments',
                    localField: '_id',
                    foreignField: 'lead',
                    as: 'lead-assignments',
                },
            });

            pipeline.push({
                $unwind: {
                    path: '$lead-assignments',
                },
            });

            pipeline.push({
                $match: {
                    'lead-assignments.assignees.user': {
                        $in: assignees.map(assignee => toObjectId(assignee)),
                    },
                },
            });

            pipeline.push({
                $project: {
                    'lead-assignments': 0,
                },
            });
        }

        pipeline.push({
            $sort: {
                _id: -1,
            },
        });

        pipeline.push(
            {
                $group: {
                    _id: null,
                    leads: {
                        $push: '$$ROOT',
                    },
                    count: {
                        $sum: 1,
                    },
                },
            },
            {
                $project: {
                    leads: { $slice: ['$leads', (page - 1) * perPage, perPage] },
                    count: 1,
                },
            }
        );

        return Lead.aggregate(pipeline);
    }

    async create(data: ILead): Promise<ILeadDoc> {
        return Lead.create(data);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<ILeadDoc | null> {
        return Lead.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getByIds({ ids, company }: { ids: TypesObjectId[] } & CompanyId): Promise<ILead[]> {
        return Lead.find({
            _id: {
                $in: ids,
            },
            company,
            status: { $ne: Status.ARCHIVED },
        }).select('_id leadStatus');
    }

    async getOnGoingLeadById({ id, company }: CommonId & CompanyId): Promise<ILeadDoc | null> {
        return Lead.findOne({
            _id: id,
            company,
            leadStatus: LeadStatus.ON_GOING,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getOnGoingLeadsByIds({ ids, company }: GetOnGoingLeadsByIds): Promise<ILeadDoc[]> {
        return Lead.find({
            _id: {
                $in: ids,
            },
            company,
            leadStatus: LeadStatus.ON_GOING,
            status: { $ne: Status.ARCHIVED },
        }).select('_id leadStatus');
    }

    async updateById({ id, company, data }: CommonId & CompanyId & { data: Partial<ILeadDoc> }) {
        return Lead.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    async archiveLeadsByIds({ ids, company }: BulkDelete & CompanyId) {
        return Lead.updateMany(
            {
                _id: {
                    $in: ids,
                },
                company,
                status: { $ne: Status.ARCHIVED },
            },
            { $set: { status: Status.ARCHIVED } }
        );
    }

    async createLeadAssignment(leadAssignment: ILeadAssignment): Promise<ILeadAssignmentDoc> {
        return LeadAssignment.create(leadAssignment);
    }

    async createLeadAssignments(leadAssignments: Partial<ILeadAssignment>[]) {
        return LeadAssignment.insertMany(leadAssignments);
    }

    async getLeadAssignmentByLeadId({ id, company }: CommonId & CompanyId): Promise<ILeadAssignmentDoc | null> {
        return LeadAssignment.findOne({
            lead: id,
            company,
            status: { $ne: Status.ARCHIVED },
        }).sort({
            _id: -1,
        });
    }

    async archiveLeadAssignmentsByLeadIds({ ids, company }: ArchiveLeadAssignmentsByLeadIds) {
        return LeadAssignment.updateMany(
            {
                lead: {
                    $in: ids,
                },
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    status: Status.ARCHIVED,
                },
            }
        );
    }

    async getNextLeadNumber(): Promise<ICounterDoc> {
        return Counter.findOneAndUpdate({}, { $inc: { 'counts.lead': 1 } }, { new: true, upsert: true });
    }

    async getProjectById({ id, company }: CommonId & CompanyId): Promise<IProjectDoc | null> {
        return Project.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getBrokerById({ id, company }: CommonId & CompanyId): Promise<IBrokerDoc | null> {
        return Broker.findOne({
            _id: id,
            company,
            status: Status.ACTIVE,
        });
    }
}

export default new LeadDao();
