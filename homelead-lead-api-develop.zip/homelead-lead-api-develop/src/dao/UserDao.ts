import {
    User,
    CommonId,
    CompanyId,
    IUserDoc,
    Status,
    AccountType,
    TypesObjectId,
    ICompanyDoc,
    Company,
} from '@homelead-shared-api';

class UserDao {
    getUserById({ id, company, accountType }: CommonId & CompanyId & AccountType): Promise<IUserDoc | null> {
        return User.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: {
                $in: accountType,
            },
        }).populate({
            path: 'company',
            match: {
                status: Status.ACTIVE,
            },
        });
    }

    async getCompanyById({ company }: CompanyId): Promise<ICompanyDoc | null> {
        return Company.findOne({
            _id: company,
            status: Status.ACTIVE,
        });
    }

    getUsersById({ ids, company }: { ids: TypesObjectId[] } & CompanyId): Promise<IUserDoc[] | null> {
        return User.find({
            _id: {
                $in: ids,
            },
            company,
            status: { $ne: Status.ARCHIVED },
        }).select('_id');
    }
}

export default new UserDao();
