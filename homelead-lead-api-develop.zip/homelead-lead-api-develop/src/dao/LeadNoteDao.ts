import { CompanyId, ILeadNoteDoc, ILeadNote, Status, LeadNote, Pagination, CommonId } from '@homelead-shared-api';
import { ILeadId } from '@dto';

class LeadNoteDao {
    async getAll({ lead, company, page, perPage }: ILeadId & CompanyId & Pagination): Promise<ILeadNoteDoc[]> {
        return LeadNote.find({
            lead,
            company,
            status: { $ne: Status.ARCHIVED },
        })
            .populate([{ path: 'lead', select: 'name' }])
            .skip((page - 1) * perPage)
            .limit(perPage)
            .sort({ _id: -1 });
    }

    async countAll({ lead, company }: ILeadId & CompanyId): Promise<number> {
        return LeadNote.countDocuments({
            lead,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async create(leadNote: ILeadNote): Promise<ILeadNoteDoc> {
        return LeadNote.create(leadNote);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<ILeadNoteDoc | null> {
        return LeadNote.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateNoteById({ id, data, company }: CommonId & CompanyId & { data: Partial<ILeadNote> }) {
        return LeadNote.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new LeadNoteDao();
