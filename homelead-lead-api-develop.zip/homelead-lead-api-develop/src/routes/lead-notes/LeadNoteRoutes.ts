import { RequestHandler, Router } from 'express';
import LeadNoteValidations from './LeadNoteValidations';
import LeadService from './LeadNoteService';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.LEADS_NOTES_LIST),
    validate(LeadNoteValidations.getAll, 'query'),
    LeadService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.LEADS_NOTES_ADD),
    validate(LeadNoteValidations.create),
    LeadService.create as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.LEADS_NOTES_VIEW),
    validate(LeadNoteValidations.requiredId, 'params'),
    LeadService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.LEADS_NOTES_UPDATE),
    validate(LeadNoteValidations.requiredId, 'params'),
    validate(LeadNoteValidations.update),
    LeadService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.LEADS_NOTES_DELETE),
    validate(LeadNoteValidations.requiredId, 'params'),
    LeadService.deleteById as RequestHandler
);

export { router };
