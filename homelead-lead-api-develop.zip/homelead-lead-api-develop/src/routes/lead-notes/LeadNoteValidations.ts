import { joi, commonValidations, SiteVisitStatus, CommunicationType, LeadStatus } from '@homelead-shared-api';

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const create = joi.object().keys({
    lead: commonValidations.id,
    communicationType: joi
        .string()
        .trim()
        .valid(...Object.values(CommunicationType))
        .required(),
    meetingDateTime: joi.date().optional(),
    siteVisitStatus: joi
        .string()
        .trim()
        .valid(...Object.values(SiteVisitStatus))
        .required(),
    siteVisitScheduledDate: joi.date().optional(),
    nextSiteVisitScheduledDate: joi.date().optional(),
    tag: commonValidations.id,
    remarks: joi.string().trim().optional(),
    callDuration: joi.string().trim().optional(),
    fileLink: joi.string().trim().optional(),
    leadStatus: joi
        .string()
        .trim()
        .valid(...Object.values(LeadStatus))
        .required(),
});

const update = joi.object().keys({
    communicationType: joi
        .string()
        .trim()
        .valid(...Object.values(CommunicationType))
        .required(),
    meetingDateTime: joi.date().optional(),
    siteVisitStatus: joi
        .string()
        .trim()
        .valid(...Object.values(SiteVisitStatus))
        .required(),
    siteVisitScheduledDate: joi.date().optional(),
    nextSiteVisitScheduledDate: joi.date().optional(),
    tag: commonValidations.id,
    remarks: joi.string().trim().optional(),
    callDuration: joi.string().trim().optional(),
    fileLink: joi.string().trim().optional(),
    leadStatus: joi
        .string()
        .trim()
        .valid(...Object.values(LeadStatus))
        .required(),
});

const getAll = joi.object().keys({
    lead: commonValidations.id,
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

export default {
    create,
    update,
    getAll,
    requiredId,
};
