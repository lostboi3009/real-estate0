import { Request, Response } from 'express';
import { ILeadNote, Pagination, Status, CommonId } from '@homelead-shared-api';
import { ILeadId, ILeadNoteData } from '@dto';
import LeadNoteDao from '../../dao/LeadNoteDao';
import LeadDao from '../../dao/LeadDao';

class LeadNoteService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { lead, page, perPage } = req.query as unknown as ILeadId & Pagination;

        const [count, leadNotes] = await Promise.all([
            LeadNoteDao.countAll({
                lead,
                company,
            }),
            LeadNoteDao.getAll({
                lead,
                company,
                page,
                perPage,
            }),
        ]);

        return res.success({ count, leadNotes });
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const data: ILeadNoteData = req.body;

        const lead = await LeadDao.getOnGoingLeadById({ id: data.lead, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        const leadNote = await LeadNoteDao.create({
            ...data,
            company,
        });

        await LeadDao.updateById({
            id: data.lead,
            company,
            data: {
                leadStatus: data.leadStatus,
            },
        });

        return res.success(leadNote);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const leadNote = await LeadNoteDao.getById({ id, company });

        if (!leadNote) {
            return res.notFound(null, req.__('LEAD_NOTE_NOT_FOUND'));
        }

        return res.success(leadNote);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: Omit<ILeadNoteData, 'lead'> = req.body;

        const leadNote = await LeadNoteDao.getById({ id, company });

        if (!leadNote) {
            return res.notFound(null, req.__('LEAD_NOTE_NOT_FOUND'));
        }

        const lead = await LeadDao.getOnGoingLeadById({ id: leadNote.lead, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        await LeadNoteDao.updateNoteById({ id, data, company });

        await LeadDao.updateById({
            id: leadNote.lead,
            company,
            data: {
                leadStatus: data.leadStatus,
            },
        });

        return res.success(null, req.__('LEAD_NOTE_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<ILeadNote> = {
            status: Status.ARCHIVED,
        };

        const leadNote = await LeadNoteDao.getById({ id, company });

        if (!leadNote) {
            return res.notFound(null, req.__('LEAD_NOTE_NOT_FOUND'));
        }

        await LeadNoteDao.updateNoteById({ id, data, company });

        return res.success(null, req.__('LEAD_NOTE_DELETE_SUCCESS'));
    }
}

export default new LeadNoteService();
