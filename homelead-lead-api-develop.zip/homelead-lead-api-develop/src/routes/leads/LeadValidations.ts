import { joi, commonValidations, SourceType, BuyingTimeLine, PropertyType, LeadStatus } from '@homelead-shared-api';

const getAll = joi
    .object()
    .keys({
        search: joi.string().trim().optional(),
        status: commonValidations.status.optional(),
        page: commonValidations.page,
        perPage: commonValidations.perPage,
        sourceType: joi
            .string()
            .trim()
            .valid(...Object.values(SourceType))
            .optional(),
        project: commonValidations.id.optional(),
        propertyType: joi
            .string()
            .trim()
            .valid(...Object.values(PropertyType))
            .optional(),
        bhk: commonValidations.id.optional(),
        bhkType: commonValidations.id.optional(),
        buyingTimeline: joi
            .string()
            .trim()
            .valid(...Object.values(BuyingTimeLine))
            .optional(),
        leadStatus: joi
            .string()
            .trim()
            .valid(...Object.values(LeadStatus))
            .optional(),
        fromDate: joi.date().optional(),
        toDate: joi.date().min(joi.ref('fromDate')).optional(),
        tags: joi
            .alternatives()
            .try(commonValidations.id.optional(), joi.array().items(commonValidations.id.optional())),
        assignees: joi
            .alternatives()
            .try(commonValidations.id.optional(), joi.array().items(commonValidations.id.optional())),
    })
    .with('fromDate', 'toDate')
    .with('toDate', 'fromDate');

const create = joi.object().keys({
    name: joi.string().trim().min(3).max(30).required(),
    countryCode: commonValidations.countryCode,
    phone: commonValidations.phone,
    secondaryCountryCode: commonValidations.countryCode.optional(),
    secondaryPhone: commonValidations.phone.optional(),
    email: commonValidations.email.optional(),
    whatsAppCountryCode: commonValidations.countryCode.optional(),
    whatsAppNumber: commonValidations.phone.optional(),
    sourceType: joi
        .string()
        .trim()
        .valid(
            SourceType.BROKER,
            SourceType.DIRECT,
            SourceType.HOUSING_COM,
            SourceType.MAGIC_BRICKS,
            SourceType.NINETY_NINE_ACRES,
            SourceType.PROPTIGER,
            SourceType.SQUARE_YARD
        )
        .required(),
    project: commonValidations.id.optional(),
    broker: commonValidations.id.optional(),
    commissionPercent: joi.number().positive().optional(),
    propertyType: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyType))
        .optional(),
    bhk: commonValidations.id.optional(),
    bhkType: commonValidations.id.optional(),
    financialQualification: joi.string().trim().optional(),
    minBudget: joi.number().positive().required(),
    maxBudget: joi.number().min(joi.ref('minBudget')).required(),
    buyingTimeline: joi
        .string()
        .trim()
        .valid(...Object.values(BuyingTimeLine))
        .required(),
    otherRequirements: joi.string().trim().max(400).optional(),
    leadStatus: joi
        .string()
        .trim()
        .valid(...Object.values(LeadStatus))
        .optional(),
    team: joi.string().trim().optional(),
    assignees: joi.array().items(
        joi.object().keys({
            user: commonValidations.id.optional(),
            isPrimary: joi.boolean().optional(),
            isSecondary: joi.boolean().optional(),
        })
    ),
});

const directLead = joi.object().keys({
    company: commonValidations.id,
    name: joi.string().trim().min(3).max(30).required(),
    countryCode: commonValidations.countryCode,
    phone: commonValidations.phone,
    secondaryCountryCode: commonValidations.countryCode.optional(),
    secondaryPhone: commonValidations.phone.optional(),
    email: commonValidations.email.optional(),
    whatsAppCountryCode: commonValidations.countryCode.optional(),
    whatsAppNumber: commonValidations.phone.optional(),
    project: commonValidations.id,
    propertyType: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyType))
        .optional(),
    bhk: commonValidations.id.optional(),
    bhkType: commonValidations.id.optional(),
    financialQualification: joi.string().trim().optional(),
    minBudget: joi.number().positive().required(),
    maxBudget: joi.number().min(joi.ref('minBudget')).required(),
    buyingTimeline: joi
        .string()
        .trim()
        .valid(...Object.values(BuyingTimeLine))
        .required(),
    otherRequirements: joi.string().trim().max(400).optional(),
});

const assign = joi.object().keys({
    lead: commonValidations.id,
    team: commonValidations.id.optional(),
    assignees: joi
        .array()
        .items(
            joi.object().keys({
                user: commonValidations.id,
                isPrimary: joi.boolean().optional(),
                isSecondary: joi.boolean().optional(),
            })
        )
        .required()
        .max(10),
});

const bulkAssign = joi.object().keys({
    leads: joi.array().items(commonValidations.id).required(),
    team: commonValidations.id.optional(),
    assignees: joi
        .array()
        .items(
            joi.object().keys({
                user: commonValidations.id,
                isPrimary: joi.boolean().optional(),
                isSecondary: joi.boolean().optional(),
            })
        )
        .required()
        .max(10),
});

const bulkDelete = joi.object().keys({
    ids: joi.array().items(commonValidations.id).required(),
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

export default {
    getAll,
    create,
    assign,
    bulkAssign,
    bulkDelete,
    requiredId,
    directLead,
};
