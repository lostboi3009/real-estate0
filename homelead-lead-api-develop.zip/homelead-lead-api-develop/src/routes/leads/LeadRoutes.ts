import { RequestHandler, Router } from 'express';
import LeadService from './LeadService';
import LeadValidations from './LeadValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.LEADS_LIST),
    validate(LeadValidations.getAll, 'query'),
    LeadService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.LEADS_ADD),
    validate(LeadValidations.create),
    LeadService.create as RequestHandler
);

router.post('/direct-lead', validate(LeadValidations.directLead), LeadService.directLead as RequestHandler);

router.post(
    '/assign',
    verifyToken(UserPermissions.LEADS_ASSIGN),
    validate(LeadValidations.assign),
    LeadService.assign as RequestHandler
);

router.post(
    '/bulk-assign',
    verifyToken(UserPermissions.LEADS_BULK_ASSIGN),
    validate(LeadValidations.bulkAssign),
    LeadService.bulkAssign as RequestHandler
);

router.post(
    '/bulk-delete',
    verifyToken(UserPermissions.LEADS_BULK_DELETE),
    validate(LeadValidations.bulkDelete),
    LeadService.bulkDelete as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.LEADS_VIEW),
    validate(LeadValidations.requiredId, 'params'),
    LeadService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.LEADS_UPDATE),
    validate(LeadValidations.requiredId, 'params'),
    validate(LeadValidations.create),
    LeadService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.LEADS_DELETE),
    validate(LeadValidations.requiredId, 'params'),
    LeadService.deleteById as RequestHandler
);

router.get(
    '/:id/assignment',
    verifyToken(UserPermissions.LEADS_ASSIGNMENT),
    validate(LeadValidations.requiredId, 'params'),
    LeadService.getLeadAssignmentByLeadId as RequestHandler
);

router.get(
    '/:id/send-microsite-link',
    verifyToken(UserPermissions.LEADS_LIST),
    validate(LeadValidations.requiredId, 'params'),
    LeadService.sendMicrositeLink as RequestHandler
);

export { router };
