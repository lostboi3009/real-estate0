import { Request, Response } from 'express';
import {
    CommonId,
    ILead,
    ILeadAssignment,
    Status,
    Pagination,
    SourceType,
    sendMail,
    isDevEnv,
    logger,
} from '@homelead-shared-api';
import { BulkDelete, BulkLeadAssign, CreateAndAssignLead, GetLeads, IDirectLead, LeadGetAndCount } from '@dto';
import LeadDao from '../../dao/LeadDao';
import UserDao from '../../dao/UserDao';

class LeadService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const {
            search,
            status,
            page,
            perPage,
            sourceType,
            project,
            propertyType,
            bhk,
            bhkType,
            buyingTimeline,
            leadStatus,
            fromDate,
            toDate,
            tags = [],
            assignees = [],
            broker,
        } = req.query as unknown as GetLeads & Pagination;

        const tagIds = (!Array.isArray(tags) ? [tags] : tags) as unknown as string[];
        const assigneeIds = (!Array.isArray(assignees) ? [assignees] : assignees) as unknown as string[];

        if (broker) {
            const brokerData = await LeadDao.getBrokerById({
                id: broker,
                company,
            });

            if (!brokerData) {
                return res.warn(null, req.__('BROKER_NOT_FOUND'));
            }
        }

        const data = await LeadDao.getAndCount({
            company,
            search,
            status,
            page,
            perPage,
            sourceType,
            project,
            propertyType,
            bhk,
            bhkType,
            buyingTimeline,
            leadStatus,
            fromDate,
            toDate,
            tags: tagIds,
            assignees: assigneeIds,
            broker,
        });

        const results = data[0] as unknown as LeadGetAndCount;

        if (!results) {
            return res.success({ count: 0, leads: [] });
        }

        const { count, leads } = results;

        return res.success({ count, leads });
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const data: CreateAndAssignLead = req.body;

        if (data.assignees) {
            const leadAssigneeIds = data.assignees?.map(assignee => assignee.user);

            const leadAssignees = await UserDao.getUsersById({
                ids: leadAssigneeIds,
                company,
            });

            if (leadAssignees?.length !== data.assignees.length) {
                return res.warn(null, req.__('LEAD_ASSIGNEE_NOT_FOUND'));
            }
        }

        if (data.broker) {
            const brokerData = await LeadDao.getBrokerById({
                id: data.broker,
                company,
            });

            if (!brokerData) {
                return res.warn(null, req.__('BROKER_NOT_FOUND'));
            }
        }

        const leadCount = await LeadDao.getNextLeadNumber();

        const lead = await LeadDao.create({
            ...data,
            company,
            leadNo: `#${leadCount?.counts?.lead || 0}`,
        });

        if (data?.assignees?.length) {
            await LeadDao.createLeadAssignment({
                company,
                assignees: data.assignees,
                lead: lead._id,
                team: data.team,
                status: Status.ACTIVE,
            });
        }

        return res.success(lead);
    }

    async directLead(req: Request, res: Response) {
        const data: IDirectLead = req.body;

        const project = await LeadDao.getProjectById({ id: data.project, company: data.company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const leadCount = await LeadDao.getNextLeadNumber();

        const lead = await LeadDao.create({
            ...data,
            company: project.company,
            sourceType: SourceType.DIRECT,
            leadNo: `#${leadCount?.counts?.lead || 0}`,
        });

        return res.success(lead);
    }

    async assign(req: Request, res: Response) {
        const { company } = req.user;
        const data: ILeadAssignment = req.body;

        const leadAssigneeIds = data.assignees.map(assignee => assignee.user);

        const leadAssignees = await UserDao.getUsersById({
            ids: leadAssigneeIds,
            company,
        });

        if (leadAssignees?.length !== data.assignees.length) {
            return res.warn(null, req.__('LEAD_ASSIGNEE_NOT_FOUND'));
        }

        const lead = await LeadDao.getOnGoingLeadById({ id: data.lead, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        await LeadDao.archiveLeadAssignmentsByLeadIds({ ids: [data.lead], company });

        const leadAssignment = await LeadDao.createLeadAssignment({
            ...data,
            company,
        });

        return res.success(leadAssignment);
    }

    async bulkAssign(req: Request, res: Response) {
        const { company } = req.user;
        const data: BulkLeadAssign = req.body;
        const leadAssignmentData: Partial<ILeadAssignment>[] = data.leads.map(i => ({
            lead: i,
            company,
            team: data.team,
            assignees: data.assignees,
        }));

        const leads = await LeadDao.getOnGoingLeadsByIds({ ids: data.leads, company });

        if (data.leads.length !== leads.length) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        await LeadDao.archiveLeadAssignmentsByLeadIds({ ids: data.leads, company });

        const leadAssignments = await LeadDao.createLeadAssignments(leadAssignmentData);

        return res.success(leadAssignments);
    }

    async bulkDelete(req: Request, res: Response) {
        const { company } = req.user;
        const data: BulkDelete = req.body;

        const leads = await LeadDao.getByIds({ ids: data.ids, company });

        if (leads.length !== data.ids.length) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        await LeadDao.archiveLeadsByIds({ ids: data.ids, company });

        return res.success(null, req.__('LEAD_DELETE_SUCCESS'));
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const lead = await LeadDao.getById({ id, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        return res.success(lead);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: ILead = req.body;

        const lead = await LeadDao.getOnGoingLeadById({ id, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        await LeadDao.updateById({ id, company, data });

        return res.success(null, req.__('LEAD_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: Partial<ILead> = {
            status: Status.ARCHIVED,
        };

        const lead = await LeadDao.getById({ id, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        await LeadDao.updateById({ id, data, company });

        return res.success(null, req.__('LEAD_DELETE_SUCCESS'));
    }

    async getLeadAssignmentByLeadId(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const leadAssignment = await LeadDao.getLeadAssignmentByLeadId({ id, company });

        if (!leadAssignment) {
            return res.notFound(null, req.__('LEAD_ASSIGNMENT_NOT_FOUND'));
        }

        return res.success(leadAssignment);
    }

    async sendMicrositeLink(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const companyData = await UserDao.getCompanyById({ company });

        if (!companyData) {
            return res.warn(null, req.__('USER_NOT_FOUND'));
        }

        const lead = await LeadDao.getById({ id, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        if (!lead.email) {
            return res.notFound(null, req.__('EMAIL_NOT_FOUND'));
        }

        if (!lead.project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const projectData = await LeadDao.getProjectById({ id: lead.project, company });

        if (!projectData) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        if (!isDevEnv) {
            sendMail('microsite-link', req.__('MICROSITE_LINK_SHARED', companyData.clientName), lead.email, {
                clientName: companyData.clientName,
                leadName: lead.name,
                micrositeLink: `${companyData.subDomain}/projects/${projectData.slug}`,
            }).catch(error => {
                logger.error(`Microsite::failed to send the microsite link ${lead.email}`, error);
                throw error;
            });
        }

        return res.success(null, req.__('MICROSITE_LINK_SEND_SUCCESS'));
    }
}

export default new LeadService();
