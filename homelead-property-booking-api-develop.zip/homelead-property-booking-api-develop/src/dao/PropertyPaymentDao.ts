import {
    IPropertyPaymentDoc,
    IPropertyPayment,
    PropertyPayment,
    Project,
    Status,
    PropertyPaymentType,
    Pagination,
    mongoose,
    getSearchRegex,
    PropertyPaymentStatus,
} from '@homelead-shared-api';
import {
    GetBookingAmountPaymentByBookingId,
    GetPayments,
    DeletePropertyPayment,
    UpdateCancelAndRefund,
    UpdateProjectFinanceDeptStatus,
    UpdateProjectSaleRevenue,
} from '@dto';

type FilterQueryIPropertyPayment = mongoose.FilterQuery<IPropertyPayment>;

class PropertyPaymentDao {
    async create(propertyPayment: IPropertyPayment): Promise<IPropertyPaymentDoc> {
        return PropertyPayment.create(propertyPayment);
    }

    async bulkCreate(propertyPayments: IPropertyPayment[]): Promise<IPropertyPaymentDoc[]> {
        return PropertyPayment.insertMany(propertyPayments);
    }

    async removeDueClpPayments({ company, project, property, booking, ordinals, dueFrom }: DeletePropertyPayment) {
        return PropertyPayment.deleteMany({
            company,
            project,
            property,
            booking,
            dueFrom,
            ordinal: { $in: ordinals },
            paymentStatus: PropertyPaymentStatus.DUE,
        });
    }

    async updateFinanceDeptStatus({ company, id, financeDeptStatus }: UpdateProjectFinanceDeptStatus) {
        return PropertyPayment.updateOne(
            {
                booking: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    paymentStatus: PropertyPaymentStatus.PAID,
                    financeDeptStatus,
                },
            }
        );
    }

    async updateProjectSaleRevenue({
        company,
        project,
        totalSaleAmountRequired,
        totalSaleRevenue,
    }: UpdateProjectSaleRevenue) {
        return Project.updateOne(
            {
                _id: project,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    totalSaleAmountRequired,
                    totalSaleRevenue,
                },
            }
        );
    }

    async updateProjectRefundedAmount({ company, project, totalRefundedAmount }: UpdateCancelAndRefund) {
        return Project.updateOne(
            {
                _id: project,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    totalRefundedAmount,
                },
            }
        );
    }

    async getBookingAmountPaymentByBookingId({
        booking,
        company,
    }: GetBookingAmountPaymentByBookingId): Promise<IPropertyPaymentDoc | null> {
        return PropertyPayment.findOne({
            booking,
            company,
            paymentType: PropertyPaymentType.BOOKING_AMOUNT,
        });
    }

    async getAll({
        company,
        booking,
        search,
        paymentType,
        transactionType,
        dueFrom,
        paymentStatus,
        financeDeptStatus,
        paymentMode,
        page,
        perPage,
    }: GetPayments & Pagination): Promise<IPropertyPaymentDoc[]> {
        const matchCriteria: FilterQueryIPropertyPayment = {
            company,
            paymentType,
            status: { $ne: Status.ARCHIVED },
        };

        if (booking) {
            matchCriteria.booking = booking;
        }

        if (transactionType) {
            matchCriteria.transactionType = transactionType;
        }

        if (dueFrom) {
            matchCriteria.dueFrom = dueFrom;
        }

        if (paymentStatus) {
            matchCriteria.paymentStatus = paymentStatus;
        }

        if (financeDeptStatus) {
            matchCriteria.financeDeptStatus = financeDeptStatus;
        }

        if (paymentMode) {
            matchCriteria.paymentMode = paymentMode;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ referenceNo: { $regex: searchRegex } }];
        }

        return PropertyPayment.find(matchCriteria)
            .populate({
                path: 'booking',
                select: 'lead bookingDate panNumber aadharNumber bookingAmount refundAmount saleablePrice paymentTerm basicPrice taxPercent taxAmount extraCharges',
                populate: [
                    {
                        path: 'lead',
                        select: 'leadNo name countryCode phone email',
                    },
                    {
                        path: 'property',
                        select: 'flatNo shopNo blockName bhk propertyType',
                        populate: [
                            { path: 'bhk', select: 'name' },
                            { path: 'bhkType', select: 'name' },
                        ],
                    },
                ],
            })
            .skip((page - 1) * perPage)
            .limit(perPage)
            .sort({ _id: -1 });
    }

    async countAll({
        booking,
        company,
        search,
        paymentType,
        transactionType,
        dueFrom,
        paymentStatus,
        financeDeptStatus,
        paymentMode,
    }: GetPayments): Promise<number> {
        const matchCriteria: FilterQueryIPropertyPayment = {
            company,
            paymentType,
            status: { $ne: Status.ARCHIVED },
        };

        if (booking) {
            matchCriteria.booking = booking;
        }

        if (transactionType) {
            matchCriteria.transactionType = transactionType;
        }

        if (dueFrom) {
            matchCriteria.dueFrom = dueFrom;
        }

        if (paymentStatus) {
            matchCriteria.paymentStatus = paymentStatus;
        }

        if (financeDeptStatus) {
            matchCriteria.financeDeptStatus = financeDeptStatus;
        }

        if (paymentMode) {
            matchCriteria.paymentMode = paymentMode;
        }

        if (search) {
            const searchRegex = getSearchRegex(search);
            matchCriteria.$or = [{ referenceNo: { $regex: searchRegex } }];
        }

        return PropertyPayment.countDocuments(matchCriteria);
    }
}

export default new PropertyPaymentDao();
