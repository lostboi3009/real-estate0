import {
    User,
    CommonId,
    CompanyId,
    IUserDoc,
    Status,
    AccountType,
    Setting,
    ISettingDoc,
    ICompanyDoc,
    Company,
} from '@homelead-shared-api';

class UserDao {
    async getUserById({ id, company, accountType }: CommonId & CompanyId & AccountType): Promise<IUserDoc | null> {
        return User.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
            accountType: {
                $in: accountType,
            },
        }).populate({
            path: 'company',
            match: {
                status: Status.ACTIVE,
            },
        });
    }

    async getCompanySettings({ company }: CompanyId): Promise<ISettingDoc | null> {
        return Setting.findOne({
            company,
        }).sort({
            _id: -1,
        });
    }

    async getCompanyById({ company }: CompanyId): Promise<ICompanyDoc | null> {
        return Company.findOne({
            _id: company,
            status: Status.ACTIVE,
        });
    }
}

export default new UserDao();
