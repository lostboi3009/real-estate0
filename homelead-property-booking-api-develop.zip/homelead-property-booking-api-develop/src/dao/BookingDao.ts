import moment from 'moment-timezone';
import {
    CommonId,
    CompanyId,
    IPropertyBookingDoc,
    IPropertyBooking,
    Status,
    PropertyBooking,
    Pagination,
    IPropertyDoc,
    Property,
    IProjectDoc,
    Project,
    Tenant,
    TenantStatus,
    IProperty,
    PropertyStatus,
    toObjectId,
    mongoose,
    PropertyBookingType,
    getSearchRegex,
    ITimeLineDocument,
} from '@homelead-shared-api';
import { UpdatePropertyStatus, UpdateTenantStatus, AvailableBooking, GetBookings } from '@dto';

type FilterQueryIProperty = mongoose.FilterQuery<IProperty>;

class BookingDao {
    async getAndCount({
        page,
        perPage,
        company,
        project,
        search,
        temporaryBookingPeriod,
    }: GetBookings & CompanyId & Pagination) {
        const temporaryBookingEndDate = moment().subtract(temporaryBookingPeriod, 'days').endOf('day').toDate();
        const matchCriteria: FilterQueryIProperty = {
            company: toObjectId(company as unknown as string),
            status: { $ne: Status.ARCHIVED },
            $or: [
                { bookingType: PropertyBookingType.FINAL_BOOKING },
                {
                    $and: [
                        {
                            bookingType: PropertyBookingType.TEMPORARY_BOOKING,
                        },
                        {
                            bookingDate: {
                                $gte: temporaryBookingEndDate,
                            },
                        },
                    ],
                },
            ],
        };

        if (project) {
            matchCriteria.project = toObjectId(project as unknown as string);
        }

        const pipeline: mongoose.PipelineStage[] = [
            {
                $match: matchCriteria,
            },
            {
                $lookup: {
                    from: 'leads',
                    let: { leadId: '$lead' },
                    pipeline: [
                        { $match: { $expr: { $eq: ['$_id', '$$leadId'] } } },
                        {
                            $project: {
                                _id: 1,
                                name: 1,
                                phone: 1,
                                secondaryPhone: 1,
                                whatsAppNumber: 1,
                                email: 1,
                                leadNo: 1,
                            },
                        },
                    ],
                    as: 'lead',
                },
            },
            {
                $lookup: {
                    from: 'properties',
                    localField: 'property',
                    foreignField: '_id',
                    as: 'property',
                    pipeline: [
                        {
                            $project: {
                                _id: 1,
                                flatNo: 1,
                                shopNo: 1,
                                blockName: 1,
                                propertyType: 1,
                                propertyUnitSubType: 1,
                                bhk: 1,
                            },
                        },
                        {
                            $lookup: {
                                from: 'property-unit-sub-types',
                                localField: 'propertyUnitSubType',
                                foreignField: '_id',
                                as: 'propertyUnitSubType',
                                pipeline: [
                                    {
                                        $project: {
                                            name: 1,
                                        },
                                    },
                                ],
                            },
                        },
                        {
                            $lookup: {
                                from: 'bhk',
                                localField: 'bhk',
                                foreignField: '_id',
                                as: 'bhk',
                                pipeline: [
                                    {
                                        $project: {
                                            name: 1,
                                        },
                                    },
                                ],
                            },
                        },
                        {
                            $lookup: {
                                from: 'bhkType',
                                localField: 'bhkType',
                                foreignField: '_id',
                                as: 'bhkType',
                                pipeline: [
                                    {
                                        $project: {
                                            name: 1,
                                        },
                                    },
                                ],
                            },
                        },
                        {
                            $unwind: {
                                path: '$bhk',
                                preserveNullAndEmptyArrays: true,
                            },
                        },
                        {
                            $unwind: {
                                path: '$bhkType',
                                preserveNullAndEmptyArrays: true,
                            },
                        },
                    ],
                },
            },
            {
                $unwind: {
                    path: '$lead',
                    preserveNullAndEmptyArrays: true,
                },
            },
        ];

        if (search) {
            const searchRegex = getSearchRegex(search);
            pipeline.push({
                $match: {
                    $or: [
                        {
                            'lead.name': { $regex: searchRegex },
                            'lead.phone': { $regex: searchRegex },
                            'lead.secondaryPhone': { $regex: searchRegex },
                            'lead.whatsAppNumber': { $regex: searchRegex },
                            'lead.email': { $regex: searchRegex },
                        },
                    ],
                },
            });
        }

        pipeline.push(
            {
                $group: {
                    _id: null,
                    bookings: {
                        $push: '$$ROOT',
                    },
                    count: {
                        $sum: 1,
                    },
                },
            },
            {
                $project: {
                    bookings: { $slice: ['$bookings', (page - 1) * perPage, perPage] },
                    count: 1,
                },
            }
        );

        return PropertyBooking.aggregate(pipeline);
    }

    async availableForBooking({
        company,
        project,
        propertyType,
        propertyUnitSubType,
        bhk,
        bhkType,
    }: AvailableBooking & CompanyId): Promise<IPropertyDoc[]> {
        const matchConditions: FilterQueryIProperty = {
            company,
            $or: [
                {
                    propertyStatus: {
                        $in: [
                            PropertyStatus.AVAILABLE,
                            PropertyStatus.TEMPORARY_BOOKED_FOR_RENT,
                            PropertyStatus.ON_RENT,
                            PropertyStatus.ON_RENT_TEMPORARY_BOOKED,
                            PropertyStatus.TEMPORARY_BOOKED,
                        ],
                    },
                },
            ],
        };

        if (project) {
            matchConditions.project = toObjectId(project as unknown as string);
        }

        if (propertyType) {
            matchConditions.propertyType = propertyType;
        }

        if (propertyUnitSubType) {
            matchConditions.propertyUnitSubType = toObjectId(propertyUnitSubType as unknown as string);
        }

        if (bhk) {
            matchConditions.bhk = toObjectId(bhk as unknown as string);
        }

        if (bhkType) {
            matchConditions.bhkType = toObjectId(bhkType as unknown as string);
        }

        return Property.aggregate([
            {
                $match: matchConditions,
            },
            {
                $lookup: {
                    from: 'projects',
                    localField: 'project',
                    foreignField: '_id',
                    as: 'projectDetails',
                },
            },
            {
                $unwind: {
                    path: '$projectDetails',
                    preserveNullAndEmptyArrays: true,
                },
            },
            {
                $lookup: {
                    from: 'bhk',
                    localField: 'bhk',
                    foreignField: '_id',
                    as: 'bhk',
                },
            },
            {
                $unwind: {
                    path: '$bhk',
                    preserveNullAndEmptyArrays: true,
                },
            },
            {
                $lookup: {
                    from: 'bhkType',
                    localField: 'bhkType',
                    foreignField: '_id',
                    as: 'bhkType',
                },
            },
            {
                $unwind: {
                    path: '$bhkType',
                    preserveNullAndEmptyArrays: true,
                },
            },
            {
                $lookup: {
                    from: 'leads',
                    let: { leadId: '$lead' },
                    pipeline: [
                        { $match: { $expr: { $eq: ['$_id', '$$leadId'] } } },
                        {
                            $project: {
                                _id: 1,
                                name: 1,
                                phone: 1,
                                secondaryPhone: 1,
                                whatsAppNumber: 1,
                                email: 1,
                            },
                        },
                    ],
                    as: 'lead',
                },
            },
            {
                $unwind: {
                    path: '$lead',
                    preserveNullAndEmptyArrays: true,
                },
            },
            {
                $project: {
                    _id: 1,
                    lead: 1,
                    project: 1,
                    flatNo: 1,
                    shopNo: 1,
                    floorName: 1,
                    blockName: 1,
                    propertyType: 1,
                    propertyStatus: 1,
                    minBudget: 1,
                    maxBudget: 1,
                    bhk: 1,
                    bhkType: 1,
                    projectName: '$projectDetails.name',
                    carpetArea: 1,
                    builtUpArea: 1,
                    superBuiltUpArea: 1,
                    facing: 1,
                    bookingDate: 1,
                },
            },
            {
                $sort: {
                    _id: -1,
                },
            },
        ]);
    }

    async create(propertyBooking: IPropertyBooking): Promise<IPropertyBookingDoc> {
        return PropertyBooking.create(propertyBooking);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IPropertyBookingDoc | null> {
        return PropertyBooking.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data, company }: CommonId & CompanyId & { data: Partial<IPropertyBooking> }) {
        return PropertyBooking.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }

    async updateTimelineDocument({ id, data, company }: CommonId & CompanyId & { data: ITimeLineDocument[] }) {
        return PropertyBooking.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $push: {
                    timelineDocuments: data,
                },
            }
        );
    }

    async getPropertyById({ id, company }: CommonId & CompanyId): Promise<IPropertyDoc | null> {
        return Property.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getProjectById({ id, company }: CommonId & CompanyId): Promise<IProjectDoc | null> {
        return Project.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateTenantStatus({ property, company }: UpdateTenantStatus) {
        return Tenant.updateOne(
            {
                property,
                company,
                tenantStatus: TenantStatus.STAYING,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: {
                    tenantStatus: TenantStatus.LEFT,
                },
            }
        );
    }

    async decrementTotalRentedUnits({ id, company }: CommonId & CompanyId) {
        const project = await Project.findOne({ _id: id, company, status: { $ne: Status.ARCHIVED } });

        if (project && project.totalRentedUnits > 0) {
            await Project.updateOne(
                { _id: id, company, status: { $ne: Status.ARCHIVED } },
                { $set: { totalRentedUnits: project.totalRentedUnits - 1 } }
            );
        }
    }

    async updatePropertyStatus({ id, company, propertyStatus, bookingDate }: UpdatePropertyStatus) {
        return Property.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: { propertyStatus, bookingDate },
            }
        );
    }

    async incrementTotalBookedUnits({ id, company }: CommonId & CompanyId) {
        return Project.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $inc: { totalBookedUnits: 1 },
            }
        );
    }

    async decrementTotalBookedUnits({ id, company }: CommonId & CompanyId) {
        return Project.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $inc: { totalBookedUnits: -1 },
            }
        );
    }

    async incrementTotalBookingCancelledUnits({ id, company }: CommonId & CompanyId) {
        return Project.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $inc: { totalBookingCancelled: 1 },
            }
        );
    }
}

export default new BookingDao();
