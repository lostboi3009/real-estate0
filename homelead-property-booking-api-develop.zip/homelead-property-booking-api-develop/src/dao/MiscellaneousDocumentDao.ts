import {
    CommonId,
    CompanyId,
    IMiscellaneousDocument,
    IMiscellaneousDocumentDoc,
    MiscellaneousDocument,
    Status,
} from '@homelead-shared-api';
import { GetMiscellaneousDocuments } from '@dto';

class MiscellaneousDocumentDao {
    async getAll({
        company,
        project,
        property,
        booking,
    }: GetMiscellaneousDocuments): Promise<IMiscellaneousDocumentDoc[]> {
        return MiscellaneousDocument.find({
            company,
            project,
            property,
            booking,
            status: { $ne: Status.ARCHIVED },
        }).sort({ _id: -1 });
    }

    async create(documents: IMiscellaneousDocument): Promise<IMiscellaneousDocumentDoc> {
        return MiscellaneousDocument.create(documents);
    }

    async getById({ id, company }: CommonId & CompanyId): Promise<IMiscellaneousDocumentDoc | null> {
        return MiscellaneousDocument.findOne({
            _id: id,
            company,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, data, company }: CommonId & CompanyId & { data: Partial<IMiscellaneousDocumentDoc> }) {
        return MiscellaneousDocument.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new MiscellaneousDocumentDao();
