import { CommonId, CompanyId, ILeadDoc, Lead, Status, LeadStatus } from '@homelead-shared-api';

class LeadDao {
    async getConvertedLeadById({ id, company }: CommonId & CompanyId): Promise<ILeadDoc | null> {
        return Lead.findOne({
            _id: id,
            company,
            leadStatus: LeadStatus.CONVERTED,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async getOnGoingLeadById({ id, company }: CommonId & CompanyId): Promise<ILeadDoc | null> {
        return Lead.findOne({
            _id: id,
            company,
            leadStatus: LeadStatus.ON_GOING,
            status: { $ne: Status.ARCHIVED },
        });
    }

    async updateById({ id, company, data }: CommonId & CompanyId & { data: Partial<ILeadDoc> }) {
        return Lead.updateOne(
            {
                _id: id,
                company,
                status: { $ne: Status.ARCHIVED },
            },
            {
                $set: data,
            }
        );
    }
}

export default new LeadDao();
