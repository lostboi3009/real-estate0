import {
    DocumentAndPriority,
    IDocumentAndPriority,
    IDocumentAndPriorityDoc,
    Status,
    mongoose,
} from '@homelead-shared-api';
import { IPaymentTerm } from '@dto';

type FilterQueryIProperty = mongoose.FilterQuery<IDocumentAndPriority>;

class DocumentAndPriorityDao {
    async getByPaymentTerm({
        company,
        propertyType,
        paymentTerm,
        documentType,
    }: IPaymentTerm): Promise<IDocumentAndPriorityDoc[]> {
        const matchCriteria: FilterQueryIProperty = {
            company,
            propertyType,
            paymentTerm,
            status: { $ne: Status.ARCHIVED },
        };

        if (documentType) {
            matchCriteria.documentType = documentType;
        }

        return DocumentAndPriority.find(matchCriteria);
    }
}

export default new DocumentAndPriorityDao();
