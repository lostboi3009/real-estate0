import { RequestHandler, Router } from 'express';
import BookingService from './BookingService';
import BookingValidations from './BookingValidations';
import { validate } from '../../utils/validations';
import { verifyToken } from '../../utils/auth';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.BOOKINGS_LIST),
    validate(BookingValidations.getAll, 'query'),
    BookingService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.BOOKINGS_ADD),
    validate(BookingValidations.create),
    BookingService.create as RequestHandler
);

router.get(
    '/available-for-booking',
    verifyToken(UserPermissions.BOOKINGS_AVAILABLE_FOR_BOOKINGS),
    validate(BookingValidations.availableForBooking, 'query'),
    BookingService.availableForBooking as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.BOOKINGS_VIEW),
    validate(BookingValidations.requiredId, 'params'),
    BookingService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.BOOKINGS_UPDATE),
    validate(BookingValidations.requiredId, 'params'),
    validate(BookingValidations.update),
    BookingService.updateById as RequestHandler
);

router.put(
    '/cancel-refund/:id',
    verifyToken(UserPermissions.BOOKINGS_CANCEL_REFUND),
    validate(BookingValidations.requiredId, 'params'),
    validate(BookingValidations.cancelAndRefund),
    BookingService.cancelAndRefund as RequestHandler
);

router.put(
    '/:id/accept-payment',
    verifyToken(UserPermissions.BOOKINGS_ACCEPT_REJECT),
    validate(BookingValidations.requiredId, 'params'),
    BookingService.acceptPaymentById as RequestHandler
);

router.put(
    '/:id/reject-payment',
    verifyToken(UserPermissions.BOOKINGS_ACCEPT_REJECT),
    validate(BookingValidations.requiredId, 'params'),
    validate(BookingValidations.rejectPayment),
    BookingService.rejectPaymentById as RequestHandler
);

export { router };
