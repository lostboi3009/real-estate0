import { Request, Response } from 'express';
import moment from 'moment-timezone';
import {
    CommonId,
    Pagination,
    PropertyPaymentType,
    TransactionType,
    PropertyBookingType,
    LeadStatus,
    PropertyStatus,
    PropertyPaymentStatus,
    PropertyBookingPaymentStatus,
    PropertyFinanceDeptStatus,
    ITimeLineDocument,
    DocumentPaymentTerm,
    ICompanyDoc,
    ILeadDoc,
    isDevEnv,
    sendMail,
    DocumentType,
} from '@homelead-shared-api';
import {
    IPropertyBookingData,
    AvailableBooking,
    CancelRefund,
    RejectPayment,
    GetBookings,
    PropertyBookingsGetAndCount,
    GenrateDocument,
} from '@dto';
import BookingDao from '../../dao/BookingDao';
import PropertyPaymentDao from '../../dao/PropertyPaymentDao';
import LeadDao from '../../dao/LeadDao';
import UserDao from '../../dao/UserDao';
import DocumentAndPriorityDao from '../../dao/DocumentAndPriorityDao';
import { generateDocument } from '../../utils/document';

class BookingService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { page, perPage, project, search } = req.query as unknown as GetBookings & Pagination;
        const settings = await UserDao.getCompanySettings({ company });
        const temporaryBookingPeriod = settings?.general?.tempPropertyBookingPeriod || 7;
        const data = await BookingDao.getAndCount({
            company,
            project,
            search,
            page,
            perPage,
            temporaryBookingPeriod,
        });

        const results = data[0] as unknown as PropertyBookingsGetAndCount;

        if (!results) {
            return res.success({ count: 0, bookings: [] });
        }

        const { count, bookings } = results;

        return res.success({ count, bookings });
    }

    async availableForBooking(req: Request, res: Response) {
        const { company } = req.user;
        const { project, propertyType, propertyUnitSubType, bhk, bhkType } = req.query as unknown as AvailableBooking;

        const properties = await BookingDao.availableForBooking({
            company,
            project,
            propertyType,
            propertyUnitSubType,
            bhk,
            bhkType,
        });

        return res.success(properties);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const data: IPropertyBookingData = req.body;
        let propertyStatus = PropertyStatus.BOOKED;
        let leadStatus = LeadStatus.CONVERTED;
        const totalExtraCharges = (data.extraCharges || []).reduce((sum, i) => sum + i.amount, 0);

        const companyData = await UserDao.getCompanyById({ company });

        if (!companyData) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        if (
            data.bookingType === PropertyBookingType.FINAL_BOOKING &&
            (data?.bookingAmount || 0) + (data?.basicPrice || 0) + (totalExtraCharges || 0) + (data.taxAmount || 0) !==
                (data.saleablePrice || 0)
        ) {
            return res.notFound(null, req.__('INVALID_SALEABLE_PRICE'));
        }

        const lead = await LeadDao.getOnGoingLeadById({ id: data.lead, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        const project = await BookingDao.getProjectById({ id: data.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const property = await BookingDao.getPropertyById({ id: data.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        if (data.bookingType === PropertyBookingType.FINAL_BOOKING && (data.saleablePrice || 0) < property.minBudget) {
            return res.warn(null, req.__('OUT_OF_MIN_BUDGET'));
        }

        if ([PropertyStatus.BOOKED, PropertyStatus.SOLD].includes(property.propertyStatus)) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        if (
            [PropertyStatus.TEMPORARY_BOOKED, PropertyStatus.ON_RENT_TEMPORARY_BOOKED].includes(property.propertyStatus)
        ) {
            const settings = await UserDao.getCompanySettings({ company });
            const temporaryBookingPeriod = settings?.general?.tempPropertyBookingPeriod || 7;
            const temporaryBookingEndDate = moment().subtract(temporaryBookingPeriod, 'days').endOf('day');
            if (temporaryBookingEndDate.isBefore(moment(property.bookingDate))) {
                return res.warn(null, req.__('PROPERTY_TEMPORARILY_BOOKED'));
            }
        }

        if (data.bookingType === PropertyBookingType.TEMPORARY_BOOKING) {
            propertyStatus = PropertyStatus.TEMPORARY_BOOKED;
            leadStatus = LeadStatus.TEMPORARY_CONVERTED;

            if ([PropertyStatus.ON_RENT, PropertyStatus.ON_RENT_TEMPORARY_BOOKED].includes(property.propertyStatus)) {
                propertyStatus = PropertyStatus.ON_RENT_TEMPORARY_BOOKED;
            }
        }

        if (data.bookingType === PropertyBookingType.FINAL_BOOKING) {
            const bookingDocuments = await DocumentAndPriorityDao.getByPaymentTerm({
                company,
                propertyType: property.propertyType,
                paymentTerm: DocumentPaymentTerm.ON_THE_TIME_OF_BOOKING,
            });

            const timelineDocuments = (await Promise.all(
                bookingDocuments.map(async item => {
                    const documentLink = await generateDocument({
                        document: item.document || '',
                        project,
                        propertyType: item.propertyType,
                        documentType: item.documentType,
                        propertyBooking: data,
                        lead,
                        property,
                        company: companyData as unknown as ICompanyDoc,
                    });

                    return {
                        propertyType: lead.propertyType,
                        templateName: item.templateName,
                        documentType: item.documentType,
                        priority: item.priority,
                        document: documentLink,
                    };
                })
            )) as unknown as ITimeLineDocument[];

            if (!isDevEnv) {
                for (const item of timelineDocuments) {
                    sendMail(
                        item.documentType === DocumentType.RECEIPT ? 'booking-receipt' : 'welcome-letter',
                        item.documentType === DocumentType.RECEIPT
                            ? req.__('BOOKING_RECEIPT')
                            : req.__('WELCOME_LETTER'),
                        lead?.email as unknown as string,
                        {
                            customerName: lead?.name,
                            companyName: companyData?.name,
                            documentLink: item.document,
                        }
                    );
                }
            }

            data.timelineDocuments = timelineDocuments;
        }

        const booking = await BookingDao.create({
            ...data,
            company,
            bookingPaymentStatus:
                data.paymentStatus === PropertyPaymentStatus.PAID
                    ? PropertyBookingPaymentStatus.PAID
                    : PropertyBookingPaymentStatus.DUE,
        });

        await BookingDao.updatePropertyStatus({
            id: data.property,
            company,
            propertyStatus,
            bookingDate: data.bookingDate,
        });

        await LeadDao.updateById({
            id: data.lead,
            company,
            data: {
                leadStatus,
            },
        });

        if (data.bookingType === PropertyBookingType.FINAL_BOOKING) {
            await PropertyPaymentDao.create({
                company,
                project: data.project,
                property: data.property,
                booking: booking._id,
                paymentType: PropertyPaymentType.BOOKING_AMOUNT,
                transactionType: TransactionType.CREDIT,
                amount: data.bookingAmount || 0,
                paymentStatus: data.paymentStatus,
                financeDeptStatus: PropertyFinanceDeptStatus.PENDING,
                paymentMode: data.paymentMode,
                referenceNo: data.referenceNo,
                remarks: data.remarks,
                receivedOn: moment().toDate(),
            });

            if ([PropertyStatus.ON_RENT, PropertyStatus.ON_RENT_TEMPORARY_BOOKED].includes(property.propertyStatus)) {
                await BookingDao.updateTenantStatus({
                    property: data.property,
                    company,
                });
                await BookingDao.decrementTotalRentedUnits({
                    id: data.project,
                    company,
                });
            }

            await BookingDao.incrementTotalBookedUnits({ id: data.project, company });

            const totalSaleAmountRequired = (project.totalSaleAmountRequired || 0) + (data.bookingAmount || 0);
            let totalSaleRevenue = project.totalSaleRevenue || 0;

            if (data.paymentStatus === PropertyPaymentStatus.PAID) {
                totalSaleRevenue += data.bookingAmount || 0;
            }

            await PropertyPaymentDao.updateProjectSaleRevenue({
                company,
                project: data.project,
                totalSaleAmountRequired,
                totalSaleRevenue,
            });
        }

        return res.success(booking);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;

        const booking = await BookingDao.getById({ id, company });

        if (!booking) {
            return res.notFound(null, req.__('BOOKING_NOT_FOUND'));
        }

        return res.success(booking);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: Omit<IPropertyBookingData, 'lead' | 'project' | 'property' | 'bookingDate'> = req.body;
        const totalExtraCharges = (data.extraCharges || []).reduce((sum, i) => sum + i.amount, 0);

        if (
            data.bookingType === PropertyBookingType.FINAL_BOOKING &&
            (data?.bookingAmount || 0) + (data?.basicPrice || 0) + (totalExtraCharges || 0) + (data.taxAmount || 0) !==
                (data.saleablePrice || 0)
        ) {
            return res.notFound(null, req.__('INVALID_SALEABLE_PRICE'));
        }

        const booking = await BookingDao.getById({ id, company });

        if (!booking) {
            return res.notFound(null, req.__('BOOKING_NOT_FOUND'));
        }

        if (booking.bookingType === PropertyBookingType.TEMPORARY_BOOKING) {
            const settings = await UserDao.getCompanySettings({ company });
            const temporaryBookingPeriod = settings?.general?.tempPropertyBookingPeriod || 7;
            const temporaryBookingEndDate = moment(booking.bookingDate)
                .add(temporaryBookingPeriod, 'days')
                .endOf('day');
            if (temporaryBookingEndDate.isBefore(moment())) {
                return res.notFound(null, req.__('BOOKING_NOT_FOUND'));
            }
        }

        const property = await BookingDao.getPropertyById({ id: booking.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        if (data.bookingType === PropertyBookingType.FINAL_BOOKING && (data.saleablePrice || 0) < property.minBudget) {
            return res.warn(null, req.__('OUT_OF_MIN_BUDGET'));
        }

        const project = await BookingDao.getProjectById({ id: booking.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        if (
            booking.bookingType === PropertyBookingType.FINAL_BOOKING ||
            (booking.bookingType === PropertyBookingType.TEMPORARY_BOOKING &&
                data.bookingType === PropertyBookingType.TEMPORARY_BOOKING)
        ) {
            await BookingDao.updateById({
                id,
                company,
                data: {
                    panNumber: data.panNumber,
                    aadharNumber: data.aadharNumber,
                    documents: data.documents,
                },
            });
        }

        if (
            booking.bookingType === PropertyBookingType.TEMPORARY_BOOKING &&
            data.bookingType === PropertyBookingType.FINAL_BOOKING
        ) {
            data.bookingPaymentStatus =
                data.paymentStatus === PropertyPaymentStatus.PAID
                    ? PropertyBookingPaymentStatus.PAID
                    : PropertyBookingPaymentStatus.DUE;

            await BookingDao.updateById({
                id,
                data,
                company,
            });

            await BookingDao.updatePropertyStatus({
                id: booking.property,
                company,
                propertyStatus: PropertyStatus.BOOKED,
                bookingDate: booking.bookingDate,
            });

            await LeadDao.updateById({
                id: booking.lead,
                company,
                data: {
                    leadStatus: LeadStatus.CONVERTED,
                },
            });

            await PropertyPaymentDao.create({
                company,
                project: booking.project,
                property: booking.property,
                booking: booking._id,
                paymentType: PropertyPaymentType.BOOKING_AMOUNT,
                transactionType: TransactionType.CREDIT,
                amount: data.bookingAmount || 0,
                paymentStatus: data.paymentStatus,
                financeDeptStatus: PropertyFinanceDeptStatus.PENDING,
                paymentMode: data.paymentMode,
                referenceNo: data.referenceNo,
                remarks: data.remarks,
                receivedOn: moment().toDate(),
            });

            if (property.propertyStatus === PropertyStatus.ON_RENT_TEMPORARY_BOOKED) {
                await BookingDao.updateTenantStatus({
                    property: booking.property,
                    company,
                });
                await BookingDao.decrementTotalRentedUnits({
                    id: booking.project,
                    company,
                });
            }

            await BookingDao.incrementTotalBookedUnits({ id: booking.project, company });

            const totalSaleAmountRequired = (project.totalSaleAmountRequired || 0) + (data.bookingAmount || 0);
            let totalSaleRevenue = project.totalSaleRevenue || 0;

            if (data.paymentStatus === PropertyPaymentStatus.PAID) {
                totalSaleRevenue += data.bookingAmount || 0;
            }

            await PropertyPaymentDao.updateProjectSaleRevenue({
                company,
                project: booking.project,
                totalSaleAmountRequired,
                totalSaleRevenue,
            });
        }

        return res.success(null, req.__('BOOKING_UPDATE_SUCCESS'));
    }

    async cancelAndRefund(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: CancelRefund = req.body;

        const booking = await BookingDao.getById({ id, company });

        if (!booking) {
            return res.notFound(null, req.__('BOOKING_NOT_FOUND'));
        }

        if (booking.bookingType !== PropertyBookingType.FINAL_BOOKING) {
            return res.notFound(null, req.__('ONLY_FINAL_BOOKING_CAN_BE_ACCEPTED_REJECTED'));
        }

        if (!booking.bookingAmount) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_FOUND'));
        }

        const bookingPayment = await PropertyPaymentDao.getBookingAmountPaymentByBookingId({
            booking: booking._id,
            company,
        });

        if (!bookingPayment) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_FOUND'));
        }

        if (bookingPayment.paymentStatus === PropertyPaymentStatus.DUE && data.amount) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_MADE'));
        }

        const property = await BookingDao.getPropertyById({ id: booking.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const project = await BookingDao.getProjectById({ id: booking.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        await BookingDao.updateById({
            id,
            data: { bookingPaymentStatus: PropertyBookingPaymentStatus.REFUNDED },
            company,
        });

        await BookingDao.updatePropertyStatus({
            id: booking.property,
            company,
            propertyStatus: PropertyStatus.AVAILABLE,
        });

        if (data.amount) {
            await PropertyPaymentDao.create({
                company,
                project: booking.project,
                property: booking.property,
                booking: booking._id,
                paymentType: PropertyPaymentType.BOOKING_AMOUNT_REFUND,
                transactionType: TransactionType.DEBIT,
                amount: data.amount,
                paymentStatus: PropertyPaymentStatus.PAID,
                financeDeptStatus: PropertyFinanceDeptStatus.ACCEPTED,
                paymentMode: data.paymentMode,
                referenceNo: data.referenceNo,
                remarks: data.remarks,
                receivedOn: data.refundDate,
            });

            const totalSaleAmountRequired = (project.totalSaleAmountRequired || 0) - (data.amount || 0);
            const totalSaleRevenue = (project.totalSaleRevenue || 0) - (data.amount || 0);
            const totalRefundedAmount = (project.totalRefundedAmount || 0) + (data.amount || 0);

            await PropertyPaymentDao.updateProjectSaleRevenue({
                company,
                project: booking.project,
                totalSaleAmountRequired,
                totalSaleRevenue,
            });

            await PropertyPaymentDao.updateProjectRefundedAmount({
                company,
                project: booking.project,
                totalRefundedAmount,
            });
        }

        await BookingDao.decrementTotalBookedUnits({ id: booking.project, company });

        await BookingDao.incrementTotalBookingCancelledUnits({ id: booking.project, company });

        return res.success(null, req.__('BOOKING_CANCELLED'));
    }

    async acceptPaymentById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;

        const bookingPayment = await PropertyPaymentDao.getBookingAmountPaymentByBookingId({
            booking: id,
            company,
        });

        const companyData = await UserDao.getCompanyById({ company });

        if (!companyData) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        if (!bookingPayment) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_FOUND'));
        }

        if (bookingPayment.paymentType !== PropertyPaymentType.BOOKING_AMOUNT) {
            return res.notFound(null, req.__('ONLY_BOOKING_AMOUNT_CAN_BE_ACCEPTED'));
        }

        if (bookingPayment.financeDeptStatus !== PropertyFinanceDeptStatus.PENDING) {
            return res.notFound(null, req.__('BOOKING_PAYMENT_CANT_BE_MODIFIED'));
        }

        const booking = await BookingDao.getById({ id: bookingPayment.booking, company });

        if (!booking) {
            return res.notFound(null, req.__('BOOKING_NOT_FOUND'));
        }

        if (booking.bookingType !== PropertyBookingType.FINAL_BOOKING) {
            return res.notFound(null, req.__('ONLY_FINAL_BOOKING_CAN_BE_ACCEPTED_REJECTED'));
        }

        if (!booking.bookingAmount) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_FOUND'));
        }

        const property = await BookingDao.getPropertyById({ id: booking.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const project = await BookingDao.getProjectById({ id: booking.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const lead = await LeadDao.getConvertedLeadById({ id: booking.lead, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        await BookingDao.updateById({
            id,
            data: { financeDeptStatus: PropertyFinanceDeptStatus.ACCEPTED },
            company,
        });

        await PropertyPaymentDao.updateFinanceDeptStatus({
            company,
            id,
            financeDeptStatus: PropertyFinanceDeptStatus.ACCEPTED,
        });

        const amountRecivedDocuments = await DocumentAndPriorityDao.getByPaymentTerm({
            company,
            propertyType: property.propertyType,
            paymentTerm: DocumentPaymentTerm.ONCE_BOOKING_AMOUNT_RECEIVED,
        });

        if (!amountRecivedDocuments.length) {
            return res.notFound(null, req.__('BOOKING_DOCUMENTS_NOT_FOUND'));
        }

        const timelineDocuments = (await Promise.all(
            amountRecivedDocuments.map(async item => {
                const documentLink = await generateDocument({
                    document: item.document || '',
                    project,
                    propertyType: item.propertyType,
                    documentType: item.documentType,
                    propertyBooking: booking,
                    lead: lead as unknown as ILeadDoc,
                    property,
                    company: companyData as unknown as ICompanyDoc,
                });

                return {
                    propertyType: lead?.propertyType,
                    templateName: item.templateName,
                    documentType: item.documentType,
                    priority: item.priority,
                    document: documentLink,
                };
            })
        )) as unknown as ITimeLineDocument[];

        if (!isDevEnv) {
            for (const item of timelineDocuments) {
                sendMail(
                    item.documentType === DocumentType.ALLOTMENT_LETTER ? 'allotment-letter' : 'agreement',
                    item.documentType === DocumentType.ALLOTMENT_LETTER
                        ? req.__('ALLOTMENT_LETTER')
                        : req.__('AGREEMENT'),
                    lead?.email as unknown as string,
                    {
                        customerName: lead?.name,
                        companyName: companyData?.name,
                        documentLink: item.document,
                    }
                );
            }
        }

        await BookingDao.updateTimelineDocument({ id: booking._id, company, data: timelineDocuments });

        return res.success(null, req.__('BOOKING_ACCEPTED_SUCCESS'));
    }

    async rejectPaymentById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: RejectPayment = req.body;

        const bookingPayment = await PropertyPaymentDao.getBookingAmountPaymentByBookingId({
            booking: id,
            company,
        });

        if (!bookingPayment) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_FOUND'));
        }

        if (bookingPayment.paymentType !== PropertyPaymentType.BOOKING_AMOUNT) {
            return res.notFound(null, req.__('ONLY_BOOKING_AMOUNT_CAN_BE_REJECTED'));
        }

        if (bookingPayment.financeDeptStatus !== PropertyFinanceDeptStatus.PENDING) {
            return res.notFound(null, req.__('BOOKING_PAYMENT_CANT_BE_MODIFIED'));
        }

        const booking = await BookingDao.getById({ id: bookingPayment.booking, company });

        if (!booking) {
            return res.notFound(null, req.__('BOOKING_NOT_FOUND'));
        }

        if (booking.bookingType !== PropertyBookingType.FINAL_BOOKING) {
            return res.notFound(null, req.__('ONLY_FINAL_BOOKING_CAN_BE_ACCEPTED_REJECTED'));
        }

        if (!booking.bookingAmount) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_FOUND'));
        }

        const property = await BookingDao.getPropertyById({ id: booking.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const project = await BookingDao.getProjectById({ id: booking.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        await BookingDao.updateById({
            id,
            company,
            data: {
                bookingPaymentStatus: PropertyBookingPaymentStatus.REFUNDED,
                financeDeptStatus: PropertyFinanceDeptStatus.REJECTED,
            },
        });

        await BookingDao.updatePropertyStatus({
            id: booking.property,
            company,
            propertyStatus: PropertyStatus.AVAILABLE,
        });

        await BookingDao.decrementTotalBookedUnits({ id: booking.project, company });

        await BookingDao.incrementTotalBookingCancelledUnits({ id: booking.project, company });

        if (bookingPayment.paymentStatus == PropertyPaymentStatus.PAID) {
            await PropertyPaymentDao.create({
                company,
                project: booking.project,
                property: booking.property,
                booking: booking._id,
                paymentType: PropertyPaymentType.BOOKING_AMOUNT_REFUND,
                transactionType: TransactionType.DEBIT,
                amount: bookingPayment.amount,
                paymentStatus: PropertyPaymentStatus.PAID,
                financeDeptStatus: PropertyFinanceDeptStatus.ACCEPTED,
                paymentMode: data.paymentMode,
                remarks: data.remarks,
                receivedOn: new Date(),
            });

            const totalSaleAmountRequired = (project.totalSaleAmountRequired || 0) - (booking.bookingAmount || 0);
            let totalSaleRevenue = project.totalSaleRevenue || 0;

            if (bookingPayment.paymentStatus == PropertyPaymentStatus.PAID) {
                totalSaleRevenue -= booking.bookingAmount || 0;
            }

            await PropertyPaymentDao.updateProjectSaleRevenue({
                company,
                project: booking.project,
                totalSaleAmountRequired,
                totalSaleRevenue,
            });
        }

        return res.success(null, req.__('BOOKING_REJECTED_SUCCESS'));
    }
}

export default new BookingService();
