import {
    joi,
    commonValidations,
    PropertyBookingType,
    PropertyBookingExtraCharges,
    PropertyBookingPaymentTerm,
    PaymentMode,
    PropertyPaymentStatus,
} from '@homelead-shared-api';

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const getAll = joi.object().keys({
    page: commonValidations.page,
    perPage: commonValidations.perPage,
    project: commonValidations.id.optional(),
    search: joi.string().trim().optional(),
});

const availableForBooking = joi.object().keys({
    project: commonValidations.id.optional(),
    propertyType: joi.string().trim().optional(),
    propertyUnitSubType: joi.string().trim().optional(),
    bhk: commonValidations.id.optional(),
    bhkType: commonValidations.id.optional(),
});

const create = joi.object({
    lead: commonValidations.id,
    project: commonValidations.id,
    property: commonValidations.id,
    bookingDate: joi.date().required(),
    panNumber: joi.string().trim().length(10).required(),
    aadharNumber: joi.string().trim().length(12).required(),
    documents: joi
        .array()
        .items(
            joi.object({
                title: joi.string().trim().required(),
                document: joi.string().trim().required(),
            })
        )
        .required(),
    bookingType: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyBookingType))
        .required(),
    saleablePrice: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    bookingAmount: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    basicPrice: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    taxPercent: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    taxAmount: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    extraCharges: joi
        .array()
        .items(
            joi.object({
                chargeFor: joi
                    .string()
                    .trim()
                    .valid(...Object.values(PropertyBookingExtraCharges))
                    .required(),
                amount: joi.number().positive().required(),
            })
        )
        .optional(),
    paymentTerm: joi.string().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(PropertyBookingPaymentTerm))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    paymentStatus: joi.string().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(PropertyPaymentStatus))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    paymentMode: joi.string().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(PaymentMode))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    referenceNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
});

const update = joi.object({
    panNumber: joi.string().trim().length(10).required(),
    aadharNumber: joi.string().trim().length(12).required(),
    documents: joi
        .array()
        .items(
            joi.object({
                title: joi.string().trim().required(),
                document: joi.string().trim().required(),
            })
        )
        .required(),
    bookingType: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyBookingType))
        .required(),
    saleablePrice: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    bookingAmount: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    basicPrice: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    taxPercent: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    taxAmount: joi.number().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi.number().positive().required(),
        otherwise: joi.number().positive().optional(),
    }),
    extraCharges: joi
        .array()
        .items(
            joi.object({
                chargeFor: joi
                    .string()
                    .trim()
                    .valid(...Object.values(PropertyBookingExtraCharges))
                    .required(),
                amount: joi.number().positive().required(),
            })
        )
        .optional(),
    paymentTerm: joi.string().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(PropertyBookingPaymentTerm))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    paymentStatus: joi.string().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(PropertyPaymentStatus))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    paymentMode: joi.string().when('bookingType', {
        is: [PropertyBookingType.FINAL_BOOKING],
        then: joi
            .string()
            .trim()
            .valid(...Object.values(PaymentMode))
            .required(),
        otherwise: joi.string().trim().optional(),
    }),
    referenceNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
});

const cancelAndRefund = joi.object({
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .optional(),
    amount: joi.number().min(0).optional(),
    refundDate: joi.date().required(),
    remarks: joi.string().trim().optional(),
    referenceNo: joi.string().trim().optional(),
});

const rejectPayment = joi.object({
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .required(),
    remarks: joi.string().trim().optional(),
});

export default {
    requiredId,
    getAll,
    availableForBooking,
    create,
    update,
    cancelAndRefund,
    rejectPayment,
};
