import moment from 'moment-timezone';
import { CreateClpPayment, GetPayments } from '@dto';
import { Request, Response } from 'express';
import {
    ClpContributor,
    IBookingClpPhase,
    IPropertyPayment,
    Pagination,
    PropertyBookingType,
    PropertyFinanceDeptStatus,
    PropertyPaymentStatus,
    PropertyPaymentType,
    TransactionType,
    PropertyPaymentDueFrom,
    PropertyBookingPaymentStatus,
    PropertyStatus,
    DocumentPaymentTerm,
    ICompanyDoc,
    ITimeLineDocument,
    PropertyType,
    DocumentType,
    ILeadDoc,
    IPropertyDoc,
    IPropertyBooking,
    isDevEnv,
    sendMail,
} from '@homelead-shared-api';
import PropertyPaymentDao from '../../dao/PropertyPaymentDao';
import BookingDao from '../../dao/BookingDao';
import DocumentAndPriorityDao from '../../dao/DocumentAndPriorityDao';
import { generateDocument } from '../../utils/document';
import UserDao from '../../dao/UserDao';
import LeadDao from '../../dao/LeadDao';

class PaymentService {
    async create(req: Request, res: Response) {
        const { company } = req.user;
        const { booking, ordinals, contributor, amount, paymentMode, referenceNo, remarks } =
            req.body as unknown as CreateClpPayment;
        let updatedAmount = amount;
        const clpPaymentsPromises: IPropertyPayment[] = [];
        const minClpValue = Math.min(...ordinals);
        const previousClpPhaseOrdinal = minClpValue === 0 ? 0 : minClpValue - 1;

        const bookingData = await BookingDao.getById({ id: booking, company });

        if (!bookingData) {
            return res.notFound(null, req.__('BOOKING_NOT_FOUND'));
        }

        if (bookingData.bookingType !== PropertyBookingType.FINAL_BOOKING) {
            return res.notFound(null, req.__('ONLY_FINAL_BOOKING_CAN_HAVE_PAYMENT'));
        }

        if (bookingData.bookingPaymentStatus !== PropertyBookingPaymentStatus.PAID) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_MADE'));
        }

        if (bookingData.financeDeptStatus !== PropertyFinanceDeptStatus.ACCEPTED) {
            return res.notFound(null, req.__('FINANCE_DEPARTMENT_NOT_ACCEPTED'));
        }

        let clpPhases = bookingData.clpPhases;

        if (!clpPhases?.length) {
            return res.notFound(null, req.__('CLP_NOT_DEFINED'));
        }

        const previousClpPhase = clpPhases.find(i => i.ordinal === previousClpPhaseOrdinal);

        if (!previousClpPhase) {
            return res.success(null, req.__('CLP_NOT_FOUND'));
        }

        const previousClpContributorStatus =
            contributor === ClpContributor.BANK
                ? previousClpPhase?.bankPaymentStatus
                : previousClpPhase?.customerPaymentStatus;

        if (minClpValue && previousClpContributorStatus !== PropertyPaymentStatus.PAID) {
            return res.success(null, req.__('PREVIOUS_CLP_PHASE_SHOULD_PAID_FIRST'));
        }

        const isAnyClpAlreadyPaid = clpPhases.some((i: IBookingClpPhase) => {
            const contributorStatus =
                contributor === ClpContributor.BANK ? i.bankPaymentStatus : i.customerPaymentStatus;
            if (ordinals.includes(i.ordinal || 0) && contributorStatus === PropertyPaymentStatus.PAID) {
                return true;
            }
        });

        if (isAnyClpAlreadyPaid) {
            return res.notFound(null, req.__('ALREADY_PAID_FOR_ONE_OF_THE_CLP_PHASES'));
        }

        const totalDueAmount = clpPhases.reduce((acc: number, i: IBookingClpPhase) => {
            if (ordinals.includes(i.ordinal || 0)) {
                const amount = contributor === ClpContributor.BANK ? i.bankAmount : i.customerAmount;
                const amountReceived =
                    contributor === ClpContributor.BANK ? i.bankAmountReceived : i.customerAmountReceived;
                const dueAmount = (amount || 0) - (amountReceived || 0);
                return acc + dueAmount;
            }

            return acc;
        }, 0);

        if (amount > totalDueAmount) {
            return res.notFound(null, req.__('AMOUNT_EXCEEDS_TOTAL_DUE_AMOUNT'));
        }
        const property = await BookingDao.getPropertyById({ id: bookingData.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const lead = await LeadDao.getConvertedLeadById({ id: bookingData.lead, company });

        if (!lead) {
            return res.notFound(null, req.__('LEAD_NOT_FOUND'));
        }

        const companyData = await UserDao.getCompanyById({ company });

        if (!companyData) {
            return res.notFound(null, req.__('COMPANY_NOT_FOUND'));
        }

        const project = await BookingDao.getProjectById({ id: bookingData.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        clpPhases = clpPhases.map(async (i: IBookingClpPhase) => {
            if (!ordinals.includes(i.ordinal || 0)) {
                return i;
            }

            if (updatedAmount <= 0) {
                return i;
            }

            const paymentData = {
                company,
                project: bookingData.project,
                property: bookingData.property,
                booking,
                paymentType: PropertyPaymentType.CLP_PAYMENT,
                transactionType: TransactionType.CREDIT,
                paymentStatus: PropertyPaymentStatus.DUE,
                financeDeptStatus: PropertyFinanceDeptStatus.PENDING,
                paymentMode,
                ordinal: i?.ordinal,
                referenceNo,
                remarks,
                receivedOn: moment().toDate(),
            };

            if (contributor === ClpContributor.BANK) {
                const dueAmount = (i.bankAmount || 0) - (i.bankAmountReceived || 0);

                if (dueAmount > 0) {
                    const bankAmountReceived = updatedAmount > dueAmount ? dueAmount : updatedAmount;
                    updatedAmount -= bankAmountReceived;
                    i.bankAmountReceived = (i.bankAmountReceived || 0) + bankAmountReceived;
                    i.bankPaymentStatus =
                        i.bankAmountReceived === i.bankAmount ? PropertyPaymentStatus.PAID : PropertyPaymentStatus.DUE;

                    clpPaymentsPromises.push({
                        ...paymentData,
                        dueFrom: PropertyPaymentDueFrom.BANK,
                        amount: bankAmountReceived,
                        paymentStatus: PropertyPaymentStatus.PAID,
                        financeDeptStatus: PropertyFinanceDeptStatus.ACCEPTED,
                    });

                    const paymentReceiptDocuments = await DocumentAndPriorityDao.getByPaymentTerm({
                        documentType: DocumentType.BANK_PAYMENT_RECEIPT,
                        company,
                        propertyType: property?.propertyType as unknown as PropertyType,
                        paymentTerm: DocumentPaymentTerm.ON_PAYMENT_RECEIVED,
                    });

                    const timelineDocuments = (await Promise.all(
                        paymentReceiptDocuments.map(async item => {
                            const documentLink = await generateDocument({
                                document: item.document || '',
                                project,
                                propertyType: item.propertyType,
                                documentType: DocumentType.BANK_PAYMENT_RECEIPT,
                                propertyBooking: booking as unknown as IPropertyBooking,
                                lead: lead as unknown as ILeadDoc,
                                property: property as unknown as IPropertyDoc,
                                company: companyData as unknown as ICompanyDoc,
                            });

                            return {
                                propertyType: lead?.propertyType,
                                templateName: item.templateName,
                                documentType: item.documentType,
                                priority: item.priority,
                                document: documentLink,
                            };
                        })
                    )) as unknown as ITimeLineDocument[];

                    if (!isDevEnv) {
                        for (const item of timelineDocuments) {
                            sendMail(
                                'bank-payment-receipt',
                                req.__('BANK_PAYMENT_RECEIPT'),
                                lead?.email as unknown as string,
                                {
                                    customerName: lead?.name,
                                    companyName: companyData?.name,
                                    documentLink: item.document,
                                }
                            );
                        }
                    }

                    await BookingDao.updateTimelineDocument({ id: booking._id, company, data: timelineDocuments });

                    if (dueAmount - bankAmountReceived) {
                        clpPaymentsPromises.push({
                            ...paymentData,
                            dueFrom: PropertyPaymentDueFrom.BANK,
                            amount: dueAmount - bankAmountReceived,
                            paymentStatus: PropertyPaymentStatus.DUE,
                            financeDeptStatus: PropertyFinanceDeptStatus.PENDING,
                        });
                    }
                }
            } else if (contributor === ClpContributor.CUSTOMER) {
                const dueAmount = (i.customerAmount || 0) - (i.customerAmountReceived || 0);

                if (dueAmount > 0) {
                    const customerAmountReceived = updatedAmount > dueAmount ? dueAmount : updatedAmount;
                    updatedAmount -= customerAmountReceived;
                    i.customerAmountReceived = (i.customerAmountReceived || 0) + customerAmountReceived;
                    i.customerPaymentStatus =
                        i.customerAmountReceived === i.customerAmount
                            ? PropertyPaymentStatus.PAID
                            : PropertyPaymentStatus.DUE;

                    clpPaymentsPromises.push({
                        ...paymentData,
                        dueFrom: PropertyPaymentDueFrom.USER,
                        amount: customerAmountReceived,
                        paymentStatus: PropertyPaymentStatus.PAID,
                        financeDeptStatus: PropertyFinanceDeptStatus.ACCEPTED,
                    });

                    const paymentReceiptDocuments = await DocumentAndPriorityDao.getByPaymentTerm({
                        documentType: DocumentType.CUSTOMER_PAYMENT_RECEIPT,
                        company,
                        propertyType: property?.propertyType as unknown as PropertyType,
                        paymentTerm: DocumentPaymentTerm.ON_PAYMENT_RECEIVED,
                    });

                    const timelineDocuments = (await Promise.all(
                        paymentReceiptDocuments.map(async item => {
                            const documentLink = await generateDocument({
                                document: item.document || '',
                                project,
                                propertyType: item.propertyType,
                                documentType: DocumentType.CUSTOMER_PAYMENT_RECEIPT,
                                propertyBooking: booking as unknown as IPropertyBooking,
                                lead: lead as unknown as ILeadDoc,
                                property: property as unknown as IPropertyDoc,
                                company: companyData as unknown as ICompanyDoc,
                            });

                            return {
                                propertyType: lead?.propertyType,
                                templateName: item.templateName,
                                documentType: item.documentType,
                                priority: item.priority,
                                document: documentLink,
                            };
                        })
                    )) as unknown as ITimeLineDocument[];

                    if (!isDevEnv) {
                        for (const item of timelineDocuments) {
                            sendMail(
                                'customer-payment-receipt',
                                req.__('CUSTOMER_PAYMENT_RECEIPT'),
                                lead?.email as unknown as string,
                                {
                                    customerName: lead?.name,
                                    companyName: companyData?.name,
                                    documentLink: item.document,
                                }
                            );
                        }
                    }

                    await BookingDao.updateTimelineDocument({ id: booking._id, company, data: timelineDocuments });

                    if (dueAmount - customerAmountReceived) {
                        clpPaymentsPromises.push({
                            ...paymentData,
                            dueFrom: PropertyPaymentDueFrom.USER,
                            amount: dueAmount - customerAmountReceived,
                            paymentStatus: PropertyPaymentStatus.DUE,
                            financeDeptStatus: PropertyFinanceDeptStatus.PENDING,
                        });
                    }
                }
            }

            return i;
        }) as unknown as IBookingClpPhase[];

        await BookingDao.updateById({
            id: booking,
            company,
            data: {
                clpPhases,
            },
        });

        await PropertyPaymentDao.removeDueClpPayments({
            company,
            booking,
            ordinals,
            dueFrom: contributor === ClpContributor.BANK ? PropertyPaymentDueFrom.BANK : PropertyPaymentDueFrom.USER,
            project: bookingData.project,
            property: bookingData.property,
        });

        await PropertyPaymentDao.bulkCreate(clpPaymentsPromises);

        const totalSaleAmountRequired = project.totalSaleAmountRequired || 0;
        let totalSaleRevenue = project.totalSaleRevenue || 0;

        totalSaleRevenue += amount || 0;

        await PropertyPaymentDao.updateProjectSaleRevenue({
            company,
            project: bookingData.project,
            totalSaleAmountRequired,
            totalSaleRevenue,
        });

        const isAllPaymentsCompleted = clpPhases.every(
            i =>
                i.bankPaymentStatus === PropertyPaymentStatus.PAID &&
                i.customerPaymentStatus === PropertyPaymentStatus.PAID
        );

        if (isAllPaymentsCompleted) {
            await BookingDao.updatePropertyStatus({
                id: bookingData.property,
                company,
                propertyStatus: PropertyStatus.SOLD,
            });

            const fullPaymentDocuments = await DocumentAndPriorityDao.getByPaymentTerm({
                company,
                propertyType: property.propertyType,
                paymentTerm: DocumentPaymentTerm.AFTER_FULL_PAYMENT_RECEIVED,
            });

            const timelineDocuments = (await Promise.all(
                fullPaymentDocuments.map(async item => {
                    const documentLink = await generateDocument({
                        document: item.document || '',
                        project,
                        propertyType: item.propertyType,
                        documentType: item.documentType,
                        propertyBooking: bookingData,
                        lead,
                        property,
                        company: companyData as unknown as ICompanyDoc,
                    });

                    return {
                        propertyType: lead.propertyType,
                        templateName: item.templateName,
                        documentType: item.documentType,
                        priority: item.priority,
                        document: documentLink,
                    };
                })
            )) as unknown as ITimeLineDocument[];

            if (!isDevEnv) {
                for (const item of timelineDocuments) {
                    sendMail(
                        'full-and-final-settlement',
                        req.__('FULL_AND_FINAL_SETTLEMENT'),
                        lead?.email as unknown as string,
                        {
                            customerName: lead?.name,
                            companyName: companyData?.name,
                            documentLink: item.document,
                        }
                    );
                }
            }

            await BookingDao.updateTimelineDocument({ id: booking._id, company, data: timelineDocuments });
        }

        return res.success(null, req.__('PAYMENT_COMPLETED'));
    }

    async getAllClpPayments(req: Request, res: Response) {
        const { company } = req.user;
        const { booking, search, paymentStatus, dueFrom, paymentMode, page, perPage } =
            req.query as unknown as GetPayments & Pagination;

        const [count, payments] = await Promise.all([
            PropertyPaymentDao.countAll({
                paymentType: PropertyPaymentType.CLP_PAYMENT,
                company,
                booking,
                search,
                paymentStatus,
                dueFrom,
                paymentMode,
            }),
            PropertyPaymentDao.getAll({
                paymentType: PropertyPaymentType.CLP_PAYMENT,
                company,
                booking,
                search,
                paymentStatus,
                dueFrom,
                paymentMode,
                page,
                perPage,
            }),
        ]);

        return res.success({ count, payments });
    }

    async getAllBookingPayments(req: Request, res: Response) {
        const { company } = req.user;
        const { booking, search, financeDeptStatus, paymentStatus, paymentMode, page, perPage } =
            req.query as unknown as GetPayments & Pagination;

        const [count, payments] = await Promise.all([
            PropertyPaymentDao.countAll({
                paymentType: PropertyPaymentType.BOOKING_AMOUNT,
                company,
                booking,
                search,
                financeDeptStatus,
                paymentStatus,
                paymentMode,
            }),
            PropertyPaymentDao.getAll({
                paymentType: PropertyPaymentType.BOOKING_AMOUNT,
                company,
                booking,
                search,
                financeDeptStatus,
                paymentStatus,
                paymentMode,
                page,
                perPage,
            }),
        ]);

        return res.success({ count, payments });
    }

    async getAllBookingRefundPayments(req: Request, res: Response) {
        const { company } = req.user;
        const { booking, search, financeDeptStatus, paymentStatus, transactionType, paymentMode, page, perPage } =
            req.query as unknown as GetPayments & Pagination;

        const [count, payments] = await Promise.all([
            PropertyPaymentDao.countAll({
                paymentType: PropertyPaymentType.BOOKING_AMOUNT_REFUND,
                company,
                booking,
                financeDeptStatus,
                paymentStatus,
                transactionType,
                paymentMode,
                search,
            }),
            PropertyPaymentDao.getAll({
                paymentType: PropertyPaymentType.BOOKING_AMOUNT_REFUND,
                company,
                booking,
                page,
                perPage,
                financeDeptStatus,
                paymentStatus,
                transactionType,
                paymentMode,
                search,
            }),
        ]);

        return res.success({ count, payments });
    }
}

export default new PaymentService();
