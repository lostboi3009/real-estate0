import {
    ClpContributor,
    commonValidations,
    joi,
    PaymentMode,
    PropertyFinanceDeptStatus,
    PropertyPaymentDueFrom,
    PropertyPaymentStatus,
} from '@homelead-shared-api';

const getAllClpPayments = joi.object().keys({
    booking: commonValidations.id.optional(),
    search: joi.string().trim().optional(),
    paymentStatus: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyPaymentStatus))
        .optional(),
    dueFrom: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyPaymentDueFrom))
        .optional(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const getAllBookingPayments = joi.object().keys({
    booking: commonValidations.id.optional(),
    search: joi.string().trim().optional(),
    financeDeptStatus: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyFinanceDeptStatus))
        .optional(),
    paymentStatus: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyPaymentStatus))
        .optional(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const getAllBookingRefundPayments = joi.object().keys({
    booking: commonValidations.id.optional(),
    search: joi.string().trim().optional(),
    paymentStatus: joi
        .string()
        .trim()
        .valid(...Object.values(PropertyPaymentStatus))
        .optional(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .optional(),
    page: commonValidations.page,
    perPage: commonValidations.perPage,
});

const create = joi.object().keys({
    booking: commonValidations.id,
    ordinals: joi.array().items(joi.number().min(0)).required(),
    contributor: joi.string().trim().valid(ClpContributor.CUSTOMER, ClpContributor.BANK).required(),
    amount: joi.number().positive().required(),
    paymentMode: joi
        .string()
        .trim()
        .valid(...Object.values(PaymentMode))
        .required(),
    referenceNo: joi.string().trim().optional(),
    remarks: joi.string().trim().optional(),
});

export default {
    create,
    getAllClpPayments,
    getAllBookingPayments,
    getAllBookingRefundPayments,
};
