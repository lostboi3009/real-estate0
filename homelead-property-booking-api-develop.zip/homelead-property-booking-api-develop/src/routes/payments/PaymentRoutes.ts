import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import PaymentValidations from './PaymentValidations';
import PaymentService from './PaymentService';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.post(
    '/accept-payments',
    verifyToken(UserPermissions.CLP_ACCEPT_PAYMENT),
    validate(PaymentValidations.create),
    PaymentService.create as RequestHandler
);

router.get(
    '/clp-payments',
    verifyToken(UserPermissions.CLP_PAYMENT_LIST),
    validate(PaymentValidations.getAllClpPayments, 'query'),
    PaymentService.getAllClpPayments as RequestHandler
);

router.get(
    '/booking-payments',
    verifyToken(UserPermissions.BOOKING_PAYMENT_LIST),
    validate(PaymentValidations.getAllBookingPayments, 'query'),
    PaymentService.getAllBookingPayments as RequestHandler
);

router.get(
    '/booking-refund-payments',
    verifyToken(UserPermissions.REFUND_PAYMENT_LIST),
    validate(PaymentValidations.getAllBookingRefundPayments, 'query'),
    PaymentService.getAllBookingRefundPayments as RequestHandler
);

export { router };
