import { joi, commonValidations, ClpContributor } from '@homelead-shared-api';

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

const create = joi.object().keys({
    contributor: joi
        .string()
        .trim()
        .valid(...Object.values(ClpContributor))
        .required(),
    customerAmount: joi.number().min(0).required(),
    bankAmount: joi.number().min(0).required(),
});

export default {
    requiredId,
    create,
};
