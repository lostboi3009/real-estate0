import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import ClpValidations from './ClpValidations';
import ClpService from './ClpService';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.post(
    '/:id',
    verifyToken(UserPermissions.BOOKING_CREATE_CLP),
    validate(ClpValidations.requiredId, 'params'),
    validate(ClpValidations.create),
    ClpService.create as RequestHandler
);

export { router };
