import { Request, Response } from 'express';
import {
    CommonId,
    IBookingClpPhase,
    PropertyBookingPaymentStatus,
    PropertyBookingType,
    PropertyFinanceDeptStatus,
    PropertyPaymentStatus,
    IPropertyPayment,
    ClpStatus,
    PropertyPaymentType,
    TransactionType,
    PropertyPaymentDueFrom,
    PaymentMode,
} from '@homelead-shared-api';
import BookingDao from '../../dao/BookingDao';
import { CreateClp } from '@dto';
import PropertyPaymentDao from '../../dao/PropertyPaymentDao';

class ClpService {
    async create(req: Request, res: Response) {
        const { company } = req.user;
        const { id } = req.params as unknown as CommonId;
        const data: CreateClp = req.body;

        const booking = await BookingDao.getById({ id, company });

        if (!booking) {
            return res.notFound(null, req.__('BOOKING_NOT_FOUND'));
        }

        if (booking.bookingType !== PropertyBookingType.FINAL_BOOKING) {
            return res.notFound(null, req.__('BOOKING_TYPE_MUST_FINAL'));
        }

        if (booking.bookingPaymentStatus !== PropertyBookingPaymentStatus.PAID) {
            return res.notFound(null, req.__('NO_PAYMENT_WAS_MADE'));
        }

        if (booking.financeDeptStatus !== PropertyFinanceDeptStatus.ACCEPTED) {
            return res.notFound(null, req.__('FINANCE_DEPARTMENT_NOT_ACCEPTED'));
        }

        if (booking.clpPhases?.length) {
            return res.notFound(null, req.__('CLP_ALREADY_DEFINED'));
        }

        const property = await BookingDao.getPropertyById({ id: booking.property, company });

        if (!property) {
            return res.notFound(null, req.__('PROPERTY_NOT_FOUND'));
        }

        const project = await BookingDao.getProjectById({ id: booking.project, company });

        if (!project) {
            return res.notFound(null, req.__('PROJECT_NOT_FOUND'));
        }

        const totalAmountClp = data.bankAmount + data.customerAmount;

        if ((booking.saleablePrice || 0) - (booking.bookingAmount || 0) !== totalAmountClp) {
            return res.warn(null, req.__('SALEABLE_AMOUNT_AND_TOTAL_AMOUNT_DOESNT_MATCH'));
        }

        const clpPaymentsPromises: IPropertyPayment[] = [];
        const bookingClpPhase: IBookingClpPhase[] = project.clpPhases.map(clpPhase => {
            const bankAmount = (clpPhase.percentage / 100) * data.bankAmount;
            const customerAmount = (clpPhase.percentage / 100) * data.customerAmount;

            if (clpPhase.status === ClpStatus.COMPLETED) {
                const paymentData = {
                    company,
                    project: booking.project,
                    property: booking.property,
                    booking: booking._id,
                    paymentType: PropertyPaymentType.CLP_PAYMENT,
                    transactionType: TransactionType.CREDIT,
                    paymentStatus: PropertyPaymentStatus.DUE,
                    financeDeptStatus: PropertyFinanceDeptStatus.PENDING,
                    ordinal: clpPhase?.ordinal,
                };

                if (bankAmount) {
                    clpPaymentsPromises.push({
                        ...paymentData,
                        dueFrom: PropertyPaymentDueFrom.BANK,
                        amount: bankAmount,
                        paymentMode: PaymentMode.CHEQUE,
                    });
                }

                if (customerAmount) {
                    clpPaymentsPromises.push({
                        ...paymentData,
                        dueFrom: PropertyPaymentDueFrom.USER,
                        amount: customerAmount,
                        paymentMode: PaymentMode.ONLINE,
                    });
                }
            }

            return {
                name: clpPhase.name,
                percentage: clpPhase.percentage,
                ordinal: clpPhase.ordinal,
                status: clpPhase.status,
                bankAmount,
                bankAmountReceived: 0,
                bankPaymentStatus: PropertyPaymentStatus.DUE,
                customerAmount,
                customerAmountReceived: 0,
                customerPaymentStatus: PropertyPaymentStatus.DUE,
            };
        });

        await BookingDao.updateById({
            id,
            company,
            data: { clpPhases: bookingClpPhase, contributor: data.contributor },
        });

        await PropertyPaymentDao.bulkCreate(clpPaymentsPromises);

        let totalSaleAmountRequired = project.totalSaleAmountRequired || 0;
        const totalSaleRevenue = project.totalSaleRevenue || 0;

        totalSaleAmountRequired += totalAmountClp || 0;

        await PropertyPaymentDao.updateProjectSaleRevenue({
            company,
            project: booking.project,
            totalSaleAmountRequired,
            totalSaleRevenue,
        });

        res.success(null, req.__('CLP_CREATED_SUCCESS'));
    }
}

export default new ClpService();
