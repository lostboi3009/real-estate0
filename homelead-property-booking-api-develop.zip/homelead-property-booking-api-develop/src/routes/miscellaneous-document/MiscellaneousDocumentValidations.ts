import { commonValidations, joi } from '@homelead-shared-api';

const getAll = joi.object().keys({
    project: commonValidations.id,
    property: commonValidations.id,
    booking: commonValidations.id,
});

const create = getAll.keys({
    name: joi.string().trim().min(3).max(50).required(),
    url: commonValidations.fileString,
});

const requiredId = joi.object().keys({
    id: commonValidations.id,
});

export default {
    getAll,
    create,
    requiredId,
};
