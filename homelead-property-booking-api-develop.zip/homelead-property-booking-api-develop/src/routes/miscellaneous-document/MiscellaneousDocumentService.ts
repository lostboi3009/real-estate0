import { GetMiscellaneousDocuments } from '@dto';
import { Request, Response } from 'express';
import { CommonId, CompanyId, IMiscellaneousDocument, Status } from '@homelead-shared-api';
import MiscellaneousDocumentDao from '../../dao/MiscellaneousDocumentDao';

class MiscellaneousDocumentService {
    async getAll(req: Request, res: Response) {
        const { company } = req.user;
        const { project, property, booking } = req.query as unknown as GetMiscellaneousDocuments;

        const miscellaneousDocuments = await MiscellaneousDocumentDao.getAll({
            company,
            project,
            property,
            booking,
        });

        return res.success(miscellaneousDocuments);
    }

    async create(req: Request, res: Response) {
        const { company } = req.user;
        const data: IMiscellaneousDocument = {
            ...req.body,
            company,
        };

        const miscellaneousDocument = await MiscellaneousDocumentDao.create(data);

        return res.success(miscellaneousDocument);
    }

    async getById(req: Request, res: Response) {
        const { company } = req.user as unknown as CompanyId;
        const { id } = req.params as unknown as CommonId;

        const miscellaneousDocument = await MiscellaneousDocumentDao.getById({ id, company });

        return res.success(miscellaneousDocument);
    }

    async updateById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: IMiscellaneousDocument = req.body;
        const miscellaneousDocument = await MiscellaneousDocumentDao.getById({ id, company });

        if (!miscellaneousDocument) {
            return res.notFound(null, req.__('DOCUMENT_NOT_FOUND'));
        }

        await MiscellaneousDocumentDao.updateById({ id, data, company });

        return res.success(null, req.__('DOCUMENT_UPDATE_SUCCESS'));
    }

    async deleteById(req: Request, res: Response) {
        const { id } = req.params as unknown as CommonId;
        const { company } = req.user;
        const data: Partial<IMiscellaneousDocument> = {
            status: Status.ARCHIVED,
        };

        const miscellaneousDocument = await MiscellaneousDocumentDao.getById({ id, company });

        if (!miscellaneousDocument) {
            return res.notFound(null, req.__('DOCUMENT_NOT_FOUND'));
        }

        await MiscellaneousDocumentDao.updateById({ id, data, company });

        return res.success(null, req.__('DOCUMENT_DELETE_SUCCESS'));
    }
}

export default new MiscellaneousDocumentService();
