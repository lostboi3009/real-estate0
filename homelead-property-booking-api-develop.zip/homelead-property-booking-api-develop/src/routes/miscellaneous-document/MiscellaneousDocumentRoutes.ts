import { RequestHandler, Router } from 'express';
import { verifyToken } from '../../utils/auth';
import { validate } from '../../utils/validations';
import MiscellaneousDocumentValidations from './MiscellaneousDocumentValidations';
import MiscellaneousDocumentService from './MiscellaneousDocumentService';
import { UserPermissions } from '@homelead-shared-api';

const router = Router();

router.get(
    '/',
    verifyToken(UserPermissions.DOCUMENTS_MISCELLANEOUS_LIST),
    validate(MiscellaneousDocumentValidations.getAll, 'query'),
    MiscellaneousDocumentService.getAll as RequestHandler
);

router.post(
    '/',
    verifyToken(UserPermissions.DOCUMENTS_MISCELLANEOUS_ADD),
    validate(MiscellaneousDocumentValidations.create),
    MiscellaneousDocumentService.create as RequestHandler
);

router.get(
    '/:id',
    verifyToken(UserPermissions.DOCUMENTS_MISCELLANEOUS_VIEW),
    validate(MiscellaneousDocumentValidations.requiredId, 'params'),
    MiscellaneousDocumentService.getById as RequestHandler
);

router.put(
    '/:id',
    verifyToken(UserPermissions.DOCUMENTS_MISCELLANEOUS_UPDATE),
    validate(MiscellaneousDocumentValidations.requiredId, 'params'),
    validate(MiscellaneousDocumentValidations.create),
    MiscellaneousDocumentService.updateById as RequestHandler
);

router.delete(
    '/:id',
    verifyToken(UserPermissions.DOCUMENTS_MISCELLANEOUS_DELETE),
    validate(MiscellaneousDocumentValidations.requiredId, 'params'),
    MiscellaneousDocumentService.deleteById as RequestHandler
);

export { router };
