export { router } from './MiscellaneousDocumentRoutes';
