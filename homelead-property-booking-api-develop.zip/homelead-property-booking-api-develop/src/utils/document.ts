import { uploadFile } from './fileUpload';
import { DocumentExtensions, DocumentType, PaymentMode, PropertyType, showDate } from '@homelead-shared-api';
import { GenrateDocument } from '@dto';
import { chromium } from 'playwright';

export const htmlToPdfBuffer = async (htmlContent: string): Promise<Buffer> => {
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();

    await page.setContent(htmlContent);

    const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true,
        margin: { top: '1cm', bottom: '1cm', left: '1cm', right: '1cm' },
    });

    await browser.close();

    return pdfBuffer;
};

export const generateDocumentData = ({
    propertyType,
    documentType,
    project,
    lead,
    property,
    propertyBooking,
    propertyPayment,
    company,
}: Omit<GenrateDocument, 'document'>): Record<string, string | number> => {
    let custom = {};

    const formattedDate = showDate();

    if (propertyType == PropertyType.RESIDENTIAL) {
        switch (documentType) {
            case DocumentType.RECEIPT:
                custom = {
                    currentDate: formattedDate,
                    companyName: company?.name.toString() || 'N/A',
                    companyAddress: company?.address || 'N/A',
                    companyPhone:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    companyEmail: company?.primaryEmail || 'N/A',
                    customerName: lead?.name,
                    customerPhone: lead?.phone,
                    customerEmail: lead?.email || 'N/A',
                    propertyName: project?.name,
                    propertyFlatNo: property?.flatNo || 'N/A',
                    bookingAmount: propertyBooking?.bookingAmount || 0,
                    bookingDate: formattedDate,
                };
                break;

            case DocumentType.WELCOME_LETTER:
                custom = {
                    currentDate: formattedDate,
                    companyName: company?.name.toString() || 'N/A',
                    companyAddress: company?.address || 'N/A',
                    companyPhone:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    companyEmail: company?.primaryEmail || 'N/A',
                    customerName: lead?.name,
                    customerPhone: lead?.phone,
                    customerEmail: lead?.email || 'N/A',
                    propertyName: project?.name,
                    propertyFlatNo: property?.flatNo || 'N/A',
                    bookingAmount: propertyBooking?.bookingAmount || 0,
                    bookingDate: formattedDate,
                };
                break;

            case DocumentType.ALLOTMENT_LETTER:
                custom = {
                    date: formattedDate,
                    customerName: lead?.name || 'N/A',
                    bookingAmount: propertyBooking?.bookingAmount || 0,
                    propertyName: project?.name,
                    flatNumber: property?.flatNo || 'N/A',
                    totalAmount: propertyBooking?.saleablePrice || 0,
                    paymentMode: PaymentMode.ONLINE,
                    remainingAmount: (propertyBooking?.saleablePrice || 0) - (propertyBooking?.bookingAmount || 0),
                    companyName: company?.name.toString() || 'N/A',

                    companyAddress: company?.address || 'N/A',
                    companyPhone:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    companyEmail: company?.primaryEmail || 'N/A',
                };
                break;

            case DocumentType.AGREEMENT:
                custom = {
                    date: formattedDate,
                    companyName: company?.name.toString() || 'N/A',
                    companyAddress: company?.address || 'N/A',
                    customerName: lead?.name || 'N/A',
                    propertyType: property?.propertyType,
                    flatNumber: property?.flatNo || 'N/A',
                    totalAmount: propertyBooking?.saleablePrice || 0,
                    paymentMode: PaymentMode.ONLINE,
                    remainingAmount: (propertyBooking?.saleablePrice || 0) - (propertyBooking?.bookingAmount || 0),
                    companyPhone:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    companyEmail: company?.primaryEmail || 'N/A',
                };
                break;

            case DocumentType.CUSTOMER_PAYMENT_RECEIPT:
                custom = {
                    date: formattedDate,
                    companyName: company?.name,
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    customerName: lead?.name || 'N/A',
                    receiptNumber: propertyPayment?._id,
                    propertyAddress: project?.address,
                    propertyType,
                    flatNumber: property?.flatNo || 'N/A',
                    amountPaid: propertyPayment?.amount,
                    paymentMode: propertyPayment?.paymentMode,
                };
                break;

            case DocumentType.BANK_PAYMENT_RECEIPT:
                custom = {
                    date: formattedDate,
                    companyName: company?.name,
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    customerName: lead?.name || 'N/A',
                    receiptNumber: propertyPayment?._id,
                    propertyAddress: project?.address,
                    propertyType,
                    flatNumber: property?.flatNo || 'N/A',
                    amountPaid: propertyPayment?.amount,
                    paymentMode: propertyPayment?.paymentMode,
                };
                break;

            default:
                throw new Error('Invalid Document Type');
        }
    }
    if (propertyType == PropertyType.COMMERCIAL) {
        switch (documentType) {
            case DocumentType.RECEIPT:
                custom = {
                    currentDate: formattedDate,
                    companyName: company?.name.toString() || 'N/A',
                    companyAddress: company?.address || 'N/A',
                    companyPhone:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    companyEmail: company?.primaryEmail || 'N/A',
                    customerName: lead?.name,
                    customerPhone: lead?.phone,
                    customerEmail: lead?.email || 'N/A',
                    propertyName: project?.name,
                    propertyFlatNo: property?.flatNo || 'N/A',
                    bookingAmount: propertyBooking?.bookingAmount || 0,
                    bookingDate: formattedDate,
                };
                break;

            case DocumentType.WELCOME_LETTER:
                custom = {
                    currentDate: formattedDate,
                    companyName: company?.name.toString() || 'N/A',
                    companyAddress: company?.address || 'N/A',
                    companyPhone:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    companyEmail: company?.primaryEmail || 'N/A',
                    customerName: lead?.name,
                    customerPhone: lead?.phone,
                    customerEmail: lead?.email || 'N/A',
                    propertyName: project?.name,
                    propertyFlatNo: property?.flatNo || 'N/A',
                    bookingAmount: propertyBooking?.bookingAmount || 0,
                    bookingDate: formattedDate,
                };
                break;

            case DocumentType.ALLOTMENT_LETTER:
                custom = {
                    date: formattedDate,
                    customerName: lead?.name || 'N/A',
                    bookingAmount: propertyBooking?.bookingAmount || 0,
                    propertyName: project?.name,
                    flatNumber: property?.flatNo || 'N/A',
                    totalAmount: propertyBooking?.saleablePrice || 0,
                    paymentMode: PaymentMode.ONLINE,
                    remainingAmount: (propertyBooking?.saleablePrice || 0) - (propertyBooking?.bookingAmount || 0),
                    companyName: company?.name.toString() || 'N/A',

                    companyAddress: company?.address || 'N/A',
                    companyPhone:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    companyEmail: company?.primaryEmail || 'N/A',
                };
                break;

            case DocumentType.AGREEMENT:
                custom = {
                    date: formattedDate,
                    companyName: company?.name.toString() || 'N/A',
                    companyAddress: company?.address || 'N/A',
                    customerName: lead?.name || 'N/A',
                    propertyType: property?.propertyType,
                    flatNumber: property?.flatNo || 'N/A',
                    totalAmount: propertyBooking?.saleablePrice || 0,
                    paymentMode: PaymentMode.ONLINE,
                    remainingAmount: (propertyBooking?.saleablePrice || 0) - (propertyBooking?.bookingAmount || 0),
                    companyPhone:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    companyEmail: company?.primaryEmail || 'N/A',
                };
                break;

            case DocumentType.CUSTOMER_PAYMENT_RECEIPT:
                custom = {
                    date: formattedDate,
                    companyName: company?.name,
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    customerName: lead?.name || 'N/A',
                    receiptNumber: propertyPayment?._id,
                    propertyAddress: project?.address,
                    propertyType,
                    flatNumber: property?.flatNo || 'N/A',
                    amountPaid: propertyPayment?.amount,
                    paymentMode: propertyPayment?.paymentMode,
                };
                break;

            case DocumentType.BANK_PAYMENT_RECEIPT:
                custom = {
                    date: formattedDate,
                    companyName: company?.name,
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    customerName: lead?.name || 'N/A',
                    receiptNumber: propertyPayment?._id,
                    propertyAddress: project?.address,
                    propertyType,
                    flatNumber: property?.flatNo || 'N/A',
                    amountPaid: propertyPayment?.amount,
                    paymentMode: propertyPayment?.paymentMode,
                };
                break;

            case DocumentType.FULL_AND_FINAL:
                custom = {
                    date: formattedDate,
                    companyName: company?.name,
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    customerName: lead?.name || 'N/A',
                    companyEmail: company?.primaryEmail,
                    receiptNumber: propertyPayment?._id,
                    propertyAddress: project?.address,
                    propertyType,
                    flatNumber: property?.flatNo || 'N/A',
                    totalAmountPaid: propertyBooking?.saleablePrice,
                    paymentMode: propertyPayment?.paymentMode,
                };
                break;

            case DocumentType.POSSESSION_LETTER:
                custom = {
                    date: formattedDate,
                    companyName: company?.name,
                    companyNumber:
                        (company?.primaryCountryCode.toString() || '') + (company?.primaryPhone.toString() || 'N/A'),
                    customerName: lead?.name || 'N/A',
                    companyEmail: company?.primaryEmail,
                    receiptNumber: propertyPayment?._id,
                    propertyAddress: project?.address,
                    propertyType,
                    flatNumber: property?.flatNo || 'N/A',
                    totalAmountPaid: propertyBooking?.saleablePrice,
                    paymentMode: propertyPayment?.paymentMode,
                };
                break;

            default:
                throw new Error('Invalid Document Type');
        }
    }
    return custom;
};

export const generateDocument = async ({
    document,
    propertyType,
    documentType,
    project,
    lead,
    property,
    propertyBooking,
    propertyPayment,
    company,
}: GenrateDocument) => {
    const custom = generateDocumentData({
        propertyType,
        documentType,
        company,
        project,
        lead,
        property,
        propertyBooking,
        propertyPayment,
    });

    for (const key in custom) {
        document = document.replaceAll(`{{${key}}}`, custom[key] as unknown as string);
    }

    const pdfBuffer = await htmlToPdfBuffer(document);

    return uploadFile({
        buffer: pdfBuffer,
        location: 'bookings/documents',
        extension: DocumentExtensions.pdf,
    });
};
