import { CompanyId, TypesObjectId } from '@homelead-shared-api';

export interface GetMiscellaneousDocuments extends CompanyId {
    project: TypesObjectId;
    property: TypesObjectId;
    booking: TypesObjectId;
}
