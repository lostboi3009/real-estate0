import {
    ClpContributor,
    CompanyId,
    DocumentPaymentTerm,
    DocumentType,
    PaymentMode,
    PropertyFinanceDeptStatus,
    PropertyPaymentDueFrom,
    PropertyPaymentStatus,
    PropertyPaymentType,
    PropertyType,
    TransactionType,
    TypesObjectId,
} from '@homelead-shared-api';

export interface GetPayments extends CompanyId {
    booking?: TypesObjectId;
    paymentType: PropertyPaymentType;
    transactionType?: TransactionType;
    dueFrom?: PropertyPaymentDueFrom;
    paymentStatus?: PropertyPaymentStatus;
    financeDeptStatus?: PropertyFinanceDeptStatus;
    paymentMode?: PaymentMode;
    search?: string;
}

export interface CreateClpPayment {
    booking: TypesObjectId;
    ordinals: number[];
    contributor: ClpContributor;
    amount: number;
    paymentMode: PaymentMode;
    referenceNo?: string;
    remarks?: string;
}

export interface DeletePropertyPayment extends CompanyId {
    project: TypesObjectId;
    property: TypesObjectId;
    booking: TypesObjectId;
    ordinals: number[];
    dueFrom: PropertyPaymentDueFrom;
}

export interface IPaymentTerm extends CompanyId {
    documentType?: DocumentType;
    propertyType: PropertyType;
    paymentTerm: DocumentPaymentTerm;
}
