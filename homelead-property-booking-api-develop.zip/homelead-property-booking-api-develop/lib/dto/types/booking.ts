import {
    IPropertyBooking,
    PropertyPaymentStatus,
    PaymentMode,
    PropertyStatus,
    CommonId,
    CompanyId,
    TypesObjectId,
    PropertyType,
    PropertyFinanceDeptStatus,
    IPropertyBookingDoc,
    ClpContributor,
    DocumentType,
    IProject,
    ILead,
    IProperty,
    ICompanyDoc,
    IPropertyPaymentDoc,
} from '@homelead-shared-api';

export interface AvailableBooking {
    project?: TypesObjectId;
    propertyUnitSubType?: TypesObjectId;
    propertyType?: PropertyType;
    bhk?: TypesObjectId;
    bhkType?: TypesObjectId;
}

export interface IPropertyBookingData extends IPropertyBooking {
    paymentStatus: PropertyPaymentStatus;
    paymentMode: PaymentMode;
    referenceNo?: string;
    remarks?: string;
}

export interface UpdatePropertyStatus extends CommonId, CompanyId {
    propertyStatus: PropertyStatus;
    bookingDate?: Date;
}
export interface UpdateProjectFinanceDeptStatus extends CompanyId {
    id: TypesObjectId;
    financeDeptStatus: PropertyFinanceDeptStatus;
}

export interface UpdateProjectSaleRevenue extends CompanyId {
    project: TypesObjectId;
    totalSaleAmountRequired: number;
    totalSaleRevenue: number;
}

export interface UpdateCancelAndRefund extends CompanyId {
    project: TypesObjectId;
    totalRefundedAmount: number;
}

export interface UpdateTenantStatus extends CompanyId {
    property: TypesObjectId;
}

export interface GetBookingAmountPaymentByBookingId extends CompanyId {
    booking: TypesObjectId;
}

export interface CancelRefund {
    paymentMode: PaymentMode;
    amount?: number;
    refundDate: Date;
    remarks?: string;
    referenceNo?: string;
}

export interface RejectPayment {
    paymentMode: PaymentMode;
    remarks?: string;
}

export interface CreateClp {
    contributor: ClpContributor;
    customerAmount: number;
    bankAmount: number;
}

export interface GetBookings {
    project?: TypesObjectId;
    search?: string;
    temporaryBookingPeriod: number;
}

export interface PropertyBookingsGetAndCount {
    count: number;
    bookings: IPropertyBookingDoc[];
}

export interface GenrateDocument {
    document: string;
    propertyType: PropertyType;
    documentType: DocumentType;
    company?: ICompanyDoc;
    project?: IProject;
    lead?: ILead;
    property?: IProperty;
    propertyBooking?: IPropertyBooking;
    propertyPayment?: IPropertyPaymentDoc;
}
