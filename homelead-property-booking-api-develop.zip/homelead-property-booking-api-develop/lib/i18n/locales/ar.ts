import { I18n, ValidationKeys, ValidationMessages, Validations } from '@dto';

const validationKeys: ValidationKeys = Object.freeze({
    name: 'الاسم',
    firstName: 'الاسم الأول',
    lastName: 'الاسم الأخير',
    fullName: 'الاسم الكامل',
    email: 'البريد الإلكتروني',
    countryCode: 'رمز الدولة',
    phone: 'الهاتف',
    emailToken: 'رمز البريد الإلكتروني',
    phoneToken: 'رمز الهاتف',
    emailPattern: 'يجب أن يكون بريد إلكتروني صالح.',
    semanticPattern: 'يجب أن يكون إصداراً صالحاً.',
    countryCodePattern: 'يجب أن يكون رمز دولة صالح.',
    phonePattern: 'يجب أن يكون رقم هاتف صالح.',
    timeIn24Hours: 'يجب أن يكون وقتاً صحيحاً بصيغة 24 ساعة.',
    page: 'الصفحة',
    perPage: 'لكل صفحة',
});

const validationMessages: ValidationMessages = Object.freeze({
    HEALTH_CHECK: 'فحص الصحة',
    NOT_FOUND: 'المورد غير موجود.',
    GENERAL_ERROR: 'حدث خطأ.',
    INVALID_REQUEST: 'طلب غير صالح، فشل التحقق من الطلب.',
    USER_NOT_FOUND: 'المستخدم غير موجود.',
    YOUR_ACCOUNT_SUSPENDED: 'تم تعليق حسابك.',
    UNAUTHORIZED: 'دخول غير مصرح به.',
    SESSION_EXPIRED: 'انتهت الجلسة.',
    INVALID_SESSION: 'جلسة غير صالحة.',
    LEAD_NOT_FOUND: 'الرصاص غير موجود.',
    BOOKING_NOT_FOUND: 'الحجز غير موجود.',
    BOOKING_TYPE_MUST_FINAL: 'يجب أن يكون الحجز نهائيًا ليتم إضافة clps.',
    NO_PAYMENT_WAS_FOUND: 'لم يتم العثور على دفع.',
    NO_PAYMENT_WAS_MADE: 'لم يتم إجراء الدفع.',
    ONLY_FINAL_BOOKING_CAN_BE_ACCEPTED_REJECTED: 'يمكن فقط إلغاء الحجز النهائي.',
    ONLY_FINAL_BOOKING_CAN_HAVE_PAYMENT: 'يمكن فقط للحجز النهائي أن يحتوي على clps.',
    ONLY_BOOKING_AMOUNT_CAN_BE_REJECTED: 'يمكن فقط رفض مبلغ الحجز.',
    BOOKING_CANCELLED: 'تم إلغاء الحجز بنجاح.',
    ONLY_BOOKING_AMOUNT_CAN_BE_ACCEPTED: 'يمكن قبول مبلغ الحجز فقط.',
    BOOKING_DELETE_SUCCESS: 'تم حذف الحجز بنجاح.',
    BOOKING_UPDATE_SUCCESS: 'تم تحديث الحجز بنجاح.',
    PROPERTY_NOT_FOUND: 'العقار غير موجود.',
    PROPERTY_TEMPORARILY_BOOKED: 'العقار محجوز مؤقتًا.',
    PROJECT_NOT_FOUND: 'المشروع غير موجود.',
    BOOKING_ACCEPTED_SUCCESS: 'تم قبول الحجز بنجاح.',
    BOOKING_REJECTED_SUCCESS: 'تم رفض الحجز بنجاح.',
    CLP_ALREADY_DEFINED: 'تم تعريف CLP بالفعل سعر قابل للبيع.',
    SALEABLE_AMOUNT_AND_TOTAL_AMOUNT_DOESNT_MATCH: 'مبلغ قابل البيع والمبلغ الإجمالي لـ clp لا يتطابق.',
    CLP_CREATED_SUCCESS: 'تم إنشاء CLP بنجاح.',
    BOOKING_PAYMENT_CANT_BE_MODIFIED: 'لا يمكن تعديل الحجز بعد قبوله أو رفضه.',
    COMPANY_SUBSCRIPTION_EXPIRED: 'انتهت اشتراك الشركة.',
    FINANCE_DEPARTMENT_NOT_ACCEPTED: 'لم يقبل قسم المالية الدفع.',
    OUT_OF_MIN_BUDGET: 'يجب أن يكون سعر البيع أكبر من أو يساوي الحد الأدنى للميزانية.',
    CLP_NOT_DEFINED: 'لم يتم تعريف CLP.',
    PAID_AMOUNT_IS_MORE_THEN_PAYABLE_AMOUNT: 'المبلغ المدفوع أكثر من المبلغ المستحق.',
    PAYMENT_COMPLETED: 'تم إتمام الدفع.',
    ALREADY_PAID_FOR_ONE_OF_THE_CLP_PHASES: 'تم الدفع بالفعل لأحد مراحل CLP.',
    AMOUNT_EXCEEDS_TOTAL_DUE_AMOUNT: 'المبلغ يتجاوز المبلغ المستحق الإجمالي.',
    PREVIOUS_CLP_PHASE_SHOULD_PAID_FIRST: 'يجب أن تكتمل مرحلة CLP السابقة أولاً.',
    CLP_NOT_FOUND: 'لم يتم العثور على CLP',
    INVALID_SALEABLE_PRICE: 'سعر البيع غير صالح.',
    BOOKING_DOCUMENTS_NOT_FOUND: 'لم يتم العثور على مستندات الحجز',
    BOOKING_RECEIPT: 'إيصال الحجز',
    WELCOME_LETTER: 'رسالة الترحيب',
    ALLOTMENT_LETTER: 'رسالة التخصيص',
    AGREEMENT: 'اتفاقية',
    CUSTOMER_PAYMENT_RECEIPT: 'إيصال الدفع الخاص بالعميل',
    BANK_PAYMENT_RECEIPT: 'إيصال دفع البنك',
    FULL_AND_FINAL_SETTLEMENT: 'لتسوية النهائية والكاملة',
});

const formatKeyName = (keyName: string): string => validationKeys[keyName.replace(/\.\d+/, '')] ?? keyName;

const validations: Validations = {
    'any.required': ({ path }) => `${formatKeyName(path.join('.'))} مطلوب.`,
    'any.unknown': ({ path }) => `${formatKeyName(path.join('.'))} غير مسموح به.`,
    'any.invalid': ({ path }) => `${formatKeyName(path.join('.'))} يحتوي على قيمة غير صالحة.`,
    'any.empty': ({ path }) => `${formatKeyName(path.join('.'))} مطلوب.`,
    'any.allowOnly': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون واحدًا من ${context?.valids?.map((item: string) => formatKeyName(item)).join(', ')}`,
    'string.base': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون نصًا.`,
    'string.min': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون طوله على الأقل ${context?.limit} حرفًا.`,
    'string.max': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون طوله أقل من أو يساوي ${context?.limit} حرفًا.`,
    'string.hex': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يحتوي فقط على أحرف سداسية عشرية.`,
    'string.length': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون طوله 4 أحرف.`,
    'string.pattern.name': ({ path, context }) => `${formatKeyName(path.join('.'))} ${formatKeyName(context?.name)}`,
    'number.base': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون رقمًا.`,
    'number.min': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون أكبر من أو يساوي ${context?.limit}.`,
    'number.max': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} يجب أن يكون أقل من أو يساوي ${context?.limit}.`,
    'number.integer': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون عددًا صحيحًا.`,
    'objectId.isValid': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون معرف كائن صالح.`,
    'object.base': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن يكون كائنًا.`,
    'object.xor': ({ context }) =>
        `يسمح فقط بواحد من ${context?.peers?.map((peer: string) => formatKeyName(peer)).join(', ')}.`,
    'object.with': ({ context }) => `${formatKeyName(context?.peer)} مطلوب مع ${formatKeyName(context?.main)}.`,
    'object.without': ({ context }) => `${formatKeyName(context?.peer)} يجب إزالته مع ${formatKeyName(context?.main)}.`,
    'object.and': ({ context }) =>
        `${context?.missing?.map((peer: string) => formatKeyName(peer)).join(', ')} مطلوب مع ${context?.present
            .map((peer: string) => formatKeyName(peer))
            .join(', ')}.`,
    'object.missing': ({ context }) =>
        `واحد من ${context?.peers?.map((peer: string) => formatKeyName(peer).toLowerCase()).join(', ')} مطلوب.`,
    'array.min': ({ path, context }) =>
        `${formatKeyName(path.join('.'))} يجب أن تحتوي على الأقل على ${context?.limit} عنصر.`,
    'array.max': ({ path, context }) =>
        `${formatKeyName(path.join('.'))} يجب أن تحتوي على الأكثر ${context?.limit} عنصر.`,
    'array.unique': ({ path }) => `${formatKeyName(path.join('.'))} يجب أن تحتوي على قيمة فريدة.`,
};

const i18n: I18n = {
    validationKeys,
    validationMessages,
    validations,
};

export default i18n;
