import { I18n, ValidationKeys, ValidationMessages, Validations } from '@dto';

const validationKeys: ValidationKeys = Object.freeze({
    name: 'Name',
    firstName: 'First name',
    lastName: 'Last name',
    fullName: 'Full name',
    email: 'Email',
    countryCode: 'Country code',
    phone: 'Phone',
    emailToken: 'Email token',
    phoneToken: 'Phone token',
    emailPattern: 'must be a valid email.',
    semanticPattern: 'must be a valid version.',
    countryCodePattern: 'must be a valid country code.',
    phonePattern: 'must be a valid phone.',
    timeIn24Hours: 'must be a valid time.',
    page: 'Page',
    perPage: 'Per page',
});

const validationMessages: ValidationMessages = Object.freeze({
    HEALTH_CHECK: 'Health check',
    NOT_FOUND: 'Resource not found.',
    GENERAL_ERROR: 'Something went wrong.',
    INVALID_REQUEST: 'Invalid request, request validation failed.',
    USER_NOT_FOUND: 'User not found.',
    YOUR_ACCOUNT_SUSPENDED: 'Your account is suspended.',
    UNAUTHORIZED: 'Unauthorized access.',
    SESSION_EXPIRED: 'Session expired.',
    INVALID_SESSION: 'Invalid session.',
    LEAD_NOT_FOUND: 'Lead not found.',
    BOOKING_NOT_FOUND: 'Booking not found.',
    BOOKING_TYPE_MUST_FINAL: 'Only final booking can have clps.',
    NO_PAYMENT_WAS_FOUND: 'No Payment was Found.',
    NO_PAYMENT_WAS_MADE: 'No Payment was made.',
    ONLY_FINAL_BOOKING_CAN_BE_ACCEPTED_REJECTED: 'Only final booking can be cancelled.',
    ONLY_FINAL_BOOKING_CAN_HAVE_PAYMENT: 'Only final booking can have Clps.',
    ONLY_BOOKING_AMOUNT_CAN_BE_REJECTED: 'Only booking amount can be rejected.',
    ONLY_BOOKING_AMOUNT_CAN_BE_ACCEPTED: 'Only booking amount can be accepted.',
    BOOKING_CANCELLED: 'Booking cancelled successfully.',
    BOOKING_DELETE_SUCCESS: 'Booking deleted successfully.',
    BOOKING_UPDATE_SUCCESS: 'Booking updated successfully.',
    PROPERTY_NOT_FOUND: 'Property not found.',
    PROPERTY_TEMPORARILY_BOOKED: 'Property temporarily booked.',
    PROJECT_NOT_FOUND: 'Project not found.',
    BOOKING_ACCEPTED_SUCCESS: 'Booking accepted successfully.',
    BOOKING_REJECTED_SUCCESS: 'Booking rejected successfully.',
    CLP_ALREADY_DEFINED: 'Clp already defined saleablePrice',
    SALEABLE_AMOUNT_AND_TOTAL_AMOUNT_DOESNT_MATCH: 'Saleable amount and total clp amount does not match.',
    CLP_CREATED_SUCCESS: 'Clp created successfully.',
    BOOKING_PAYMENT_CANT_BE_MODIFIED: 'Booking can not be modified once accepted or rejected.',
    COMPANY_SUBSCRIPTION_EXPIRED: 'Company subscription ended.',
    FINANCE_DEPARTMENT_NOT_ACCEPTED: 'Finance department has not accepted payment.',
    OUT_OF_MIN_BUDGET: 'Saleable price needs to be greater than or equal to min budget.',
    CLP_NOT_DEFINED: 'Clp not defined.',
    PAID_AMOUNT_IS_MORE_THEN_PAYABLE_AMOUNT: 'Paid amount is more than payable amount.',
    PAYMENT_COMPLETED: 'Payment Completed.',
    ALREADY_PAID_FOR_ONE_OF_THE_CLP_PHASES: 'Already paid for one of the clps.',
    AMOUNT_EXCEEDS_TOTAL_DUE_AMOUNT: 'Amount exceeds total due amount.',
    PREVIOUS_CLP_PHASE_SHOULD_PAID_FIRST: 'The previous CLP Phase should be paid first.',
    CLP_NOT_FOUND: 'Clp not found.',
    INVALID_SALEABLE_PRICE: 'Invalid saleable price.',
    BOOKING_DOCUMENTS_NOT_FOUND: 'Booking documents not found.',
    BOOKING_RECEIPT: 'Booking Receipt',
    WELCOME_LETTER: 'Welcome Letter',
    ALLOTMENT_LETTER: 'Allotment Letter',
    AGREEMENT: 'Agreement',
    CUSTOMER_PAYMENT_RECEIPT: 'Customer Payment Receipt',
    BANK_PAYMENT_RECEIPT: 'Bank Payment Receipt',
    FULL_AND_FINAL_SETTLEMENT: 'Full & Final Settlement',
});

const formatKeyName = (keyName: string): string => validationKeys[keyName.replace(/\.\d+/, '')] ?? keyName;

const validations: Validations = {
    'any.required': ({ path }) => `${formatKeyName(path.join('.'))} is required.`,
    'any.unknown': ({ path }) => `${formatKeyName(path.join('.'))} is not allowed.`,
    'any.invalid': ({ path }) => `${formatKeyName(path.join('.'))} contains an invalid value.`,
    'any.empty': ({ path }) => `${formatKeyName(path.join('.'))} is required.`,
    'any.allowOnly': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be one of ${context?.valids?.map((item: string) => formatKeyName(item)).join(', ')}`,
    'string.base': ({ path }) => `${formatKeyName(path.join('.'))} must be a string`,
    'string.min': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be at least ${context?.limit} characters in length.`,
    'string.max': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be under ${context?.limit} characters in length.`,
    'string.hex': ({ path }) => `${formatKeyName(path.join('.'))} must only contain hexadecimal characters.`,
    'string.length': ({ path }) => `${formatKeyName(path.join('.'))} length must be 4 characters long.`,
    'string.pattern.name': ({ path, context }) => `${formatKeyName(path.join('.'))} ${formatKeyName(context?.name)}`,
    'number.base': ({ path }) => `${formatKeyName(path.join('.'))} must be a number`,
    'number.min': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be larger than or equal to ${context?.limit}.`,
    'number.max': ({ context, path }) =>
        `${formatKeyName(path.join('.'))} must be less than or equal to ${context?.limit}.`,
    'number.integer': ({ path }) => `${formatKeyName(path.join('.'))} must be an integer number.`,
    'objectId.isValid': ({ path }) => `${formatKeyName(path.join('.'))} needs to be a valid objectId`,
    'object.base': ({ path }) => `${formatKeyName(path.join('.'))} must be an object`,
    'object.xor': ({ context }) =>
        `only one of ${context?.peers?.map((peer: string) => formatKeyName(peer)).join(', ')} is allowed.`,
    'object.with': ({ context }) => `${formatKeyName(context?.peer)} is required with ${formatKeyName(context?.main)}.`,
    'object.without': ({ context }) =>
        `${formatKeyName(context?.peer)} needs to be removed with ${formatKeyName(context?.main)}.`,
    'object.and': ({ context }) =>
        `${context?.missing?.map((peer: string) => formatKeyName(peer)).join(', ')} required with ${context?.present
            .map((peer: string) => formatKeyName(peer))
            .join(', ')}.`,
    'object.missing': ({ context }) =>
        `one of ${context?.peers?.map((peer: string) => formatKeyName(peer).toLowerCase()).join(', ')} is required.`,
    'array.min': ({ path, context }) =>
        `${formatKeyName(path.join('.'))} must contain at least ${context?.limit} items.`,
    'array.max': ({ path, context }) =>
        `${formatKeyName(path.join('.'))} must contain at most ${context?.limit} items.`,
    'array.unique': ({ path }) => `${formatKeyName(path.join('.'))} must contain a unique value.`,
};

const i18n: I18n = {
    validationKeys,
    validationMessages,
    validations,
};

export default i18n;
