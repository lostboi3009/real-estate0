declare module 'express-async-errors' {}

export {};
