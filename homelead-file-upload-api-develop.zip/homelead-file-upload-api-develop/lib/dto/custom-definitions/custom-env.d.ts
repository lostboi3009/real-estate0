declare module 'custom-env' {
    export function env(name: string): void;
}
