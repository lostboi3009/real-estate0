import fs from 'fs';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { DeleteObjectCommand, PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { DocumentExtensions, ImageExtensions, VideoExtensions, logger, randomString } from '@homelead-shared-api';

interface AWSConfig {
    region: string;
    credentials?: {
        accessKeyId: string;
        secretAccessKey: string;
    };
}

interface GetSignedUrl {
    location: string;
    extension: string;
}

interface SignedUrlResponse {
    url: string;
    preview: string;
}

interface RequestFile {
    tempFilePath: string;
}

interface UploadFile {
    file: RequestFile;
    location: string;
    extension: ImageExtensions | VideoExtensions | DocumentExtensions;
}

const accessKeyId = process.env.AWS_S3_ACCESS_KEY_ID;
const secretAccessKey = process.env.AWS_S3_SECRET_ACCESS_KEY;
const region = process.env.AWS_S3_REGION;
const bucket = process.env.AWS_S3_BUCKET;

const awsConfig: AWSConfig = {
    region,
    credentials: {
        accessKeyId,
        secretAccessKey,
    },
};

if (process.env.NODE_ENV === 'production') {
    delete awsConfig.credentials;
}

const s3Client = new S3Client(awsConfig);

const getPreSignedUrl = async ({ location, extension }: GetSignedUrl): Promise<SignedUrlResponse> => {
    const key = `${location}/${randomString()}.${extension}`;
    const command = new PutObjectCommand({
        Bucket: bucket,
        Key: key,
        ACL: 'public-read',
    });
    const url = await getSignedUrl(s3Client, command);

    return {
        url,
        preview: `https://${bucket}.s3.${region}.amazonaws.com/${key}`,
    };
};

const uploadFile = async ({ file, location, extension }: UploadFile): Promise<string> => {
    const key = `${location}/${randomString()}.${extension}`;

    try {
        const buffer = fs.readFileSync(file.tempFilePath);
        const command = new PutObjectCommand({
            Bucket: bucket,
            Key: key,
            Body: buffer,
            ACL: 'public-read',
        });

        await s3Client.send(command);
    } catch (err) {
        if (err) {
            logger.error('UTILS:: uploadFile: error while reading temporary file:', err);
            throw err;
        }
    }

    return `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
};

const deleteFile = (key: string) => {
    const command = new DeleteObjectCommand({
        Bucket: bucket,
        Key: key,
    });

    return s3Client.send(command);
};

export { getPreSignedUrl, uploadFile, deleteFile };
